# Direct spherical-prism forward modelling

This directory contains the direct tesseroid implementation used in the accompanying study. The gravitational drivers evaluate the potential and its spatial derivatives through third order. The magnetic drivers evaluate the magnetic potential, field vector, and field-gradient tensor.

## Requirements

- C++17 compiler
- Eigen 3.4 or a compatible Eigen 3.x release
- MPI implementation
- OpenMP implementation
- MATLAB (optional, for generating parameter files and reading results)

## Entry points

| Source file | Purpose |
|---|---|
| `Work1_GravityEstimateOpenMP.cpp` | OpenMP gravitational forward modelling |
| `Work1_GravityEstimateMPI.cpp` | MPI gravitational forward modelling |
| `Work1_MagneticEstimate.cpp` | Serial magnetic forward modelling |
| `Work1_MagneticEstimateOpenMP.cpp` | OpenMP magnetic forward modelling |
| `Work1_MagneticEstimateMPI.cpp` | MPI magnetic forward modelling |

## Typical workflow

1. Edit and run `Work1_SetGravityParameters.m` or `Work1_SetMagneticParameters.m` in MATLAB. The example scripts write `TFG.ForPar` or `TFM.ForPar` in little-endian binary form.
2. Compile the selected C++ entry point with the user's preferred C++17, Eigen, MPI, and OpenMP toolchain, then run it from the directory containing the parameter file.
3. Read `Result_TFG.dat` or `Result_TFM.dat` with the corresponding `Work2_Read*Results.m` script.

The supplied MATLAB scripts are small reproducible examples. Angles are specified in degrees and radial coordinates in kilometres, consistently with the implementation and manuscript tests.
