# Individual spherical prisms

These files match the current Tesseroid_C++/Tesseroid production sources.

## Entry points

- Work1_GravityEstimateOpenMP.cpp and Work1_GravityEstimateMPI.cpp: potential and all 19 gravitational derivatives through third order.
- Work1_MagneticEstimate.cpp, Work1_MagneticEstimateOpenMP.cpp and Work1_MagneticEstimateMPI.cpp: magnetic potential, vector and gradient tensor.

Each driver includes the local _integral2.h, _tesseroid_estimate.h and _tesseroid_integralkernel.h. Supply Eigen, MPI and OpenMP through the compiler settings. These sources do not require an Analytical package or precomputed tables.

Work1_SetGravityParameters.m and Work1_SetMagneticParameters.m create TFG.ForPar and TFM.ForPar. They begin with absolute and relative integration tolerances, followed by model and coordinate arrays. Work2_Read*ForwardResults.m scripts read the results. See the supplementary document for complete binary layouts and unit conversion.

Cluster-specific MPI copies and build/submission scripts are in ../Tesseroid_Cluster/.
