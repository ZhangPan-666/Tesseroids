
#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

namespace Tesseroid {

using Matrix14 = Eigen::Matrix<double, 14, 14>;

static constexpr double TESSEROID_PI = 3.141592653589793238462643383279502884;
static constexpr double TESSEROID_RAD = TESSEROID_PI / 180.0;

inline int Tesseroid_Binomial(int n, int k) {
    if (k < 0 || k > n) {
        return 0;
    }
    if (k > n - k) {
        k = n - k;
    }

    int value = 1;
    for (int i = 1; i <= k; ++i) {
        value = value * (n - k + i) / i;
    }
    return value;
}

inline double Tesseroid_Clamp(double x, double lo, double hi) { return std::min(hi, std::max(lo, x)); }

inline void Tesseroid_NormalizedRadius(double R2, double R1, double r, double& R2n, double& R1n) {
    const double h2 = r - R2;
    const double h1 = r - R1;

    R2n = 1.0 - h2 / r;
    R1n = 1.0 - h1 / r;
}

inline void Tesseroid_LocalGeometry(const Matrix14& FaiI, const Matrix14& LamdaI, double fai, double lamda,
                                    Matrix14& Tx, Matrix14& Ty, Matrix14& SinPsi, Matrix14& CosPsi) {
    const double faiRad = fai * TESSEROID_RAD;
    const double cosFaiObs = std::cos(faiRad);
    const double sinFaiObs = std::sin(faiRad);

    for (int i = 0; i < 14; ++i) {
        for (int j = 0; j < 14; ++j) {
            const double FaiRad = FaiI(i, j) * TESSEROID_RAD;
            const double dLamdaRad = (LamdaI(i, j) - lamda) * TESSEROID_RAD;

            const double cosFaiSrc = std::cos(FaiRad);
            const double sinFaiSrc = std::sin(FaiRad);
            const double cosDL = std::cos(dLamdaRad);
            const double sinDL = std::sin(dLamdaRad);

            Tx(i, j) = cosFaiObs * sinFaiSrc - sinFaiObs * cosFaiSrc * cosDL;
            Ty(i, j) = cosFaiSrc * sinDL;

            SinPsi(i, j) = std::hypot(Tx(i, j), Ty(i, j));
            CosPsi(i, j) = sinFaiObs * sinFaiSrc + cosFaiObs * cosFaiSrc * cosDL;
            CosPsi(i, j) = Tesseroid_Clamp(CosPsi(i, j), -1.0, 1.0);
        }
    }
}

inline Matrix14 Tesseroid_CosFaiMatrix(const Matrix14& FaiI) {
    Matrix14 C;
    for (int i = 0; i < 14; ++i) {
        for (int j = 0; j < 14; ++j) {
            C(i, j) = std::cos(FaiI(i, j) * TESSEROID_RAD);
        }
    }
    return C;
}

inline double Tesseroid_LogRatio(double a, double b) {
    if (a <= 0.0 || b <= 0.0) {
        throw std::runtime_error("Tesseroid_LogRatio requires positive arguments.");
    }

    const double r = (a - b) / b;
    if (std::abs(r) < 0.25) {
        return std::log1p(r);
    }
    return std::log(a / b);
}

inline double Tesseroid_StablePowerIntegral(int alpha, double q1, double q2) {
    if (q1 <= 0.0 || q2 <= 0.0) {
        throw std::runtime_error("Tesseroid_StablePowerIntegral requires positive limits.");
    }

    if (q1 == q2) {
        return 0.0;
    }

    const double logRatio = Tesseroid_LogRatio(q2, q1);

    if (alpha == -1) {
        return logRatio;
    }

    const int betaInt = alpha + 1;
    const double beta = static_cast<double>(betaInt);
    return std::pow(q1, beta) * std::expm1(beta * logRatio) / beta;
}

inline double Tesseroid_BaseMomentSmallB(double u1, double u2, double b, int n, int k) {
    const double sigma = (u1 >= 0.0) ? 1.0 : -1.0;

    const double q1 = std::min(std::abs(u1), std::abs(u2));
    const double q2 = std::max(std::abs(u1), std::abs(u2));

    const double P0 = Tesseroid_StablePowerIntegral(k - n, q1, q2);
    const double P2 = Tesseroid_StablePowerIntegral(k - n - 2, q1, q2);
    const double P4 = Tesseroid_StablePowerIntegral(k - n - 4, q1, q2);
    const double P6 = Tesseroid_StablePowerIntegral(k - n - 6, q1, q2);
    const double P8 = Tesseroid_StablePowerIntegral(k - n - 8, q1, q2);

    const double signFactor = (k % 2 == 0) ? 1.0 : sigma;

    return signFactor * (P0 - 0.5 * n * b * b * P2 + n * (n + 2.0) / 8.0 * std::pow(b, 4) * P4 -
                         n * (n + 2.0) * (n + 4.0) / 48.0 * std::pow(b, 6) * P6 +
                         n * (n + 2.0) * (n + 4.0) * (n + 6.0) / 384.0 * std::pow(b, 8) * P8);
}

inline double Tesseroid_BaseMomentGauss16(double u1, double u2, double b, int n, int k) {
    const double nodes[16] = {-0.9894009349916499, -0.9445750230732326, -0.8656312023878318, -0.7554044083550030,
                              -0.6178762444026438, -0.4580167776572274, -0.2816035507792589, -0.0950125098376374,
                              0.0950125098376374,  0.2816035507792589,  0.4580167776572274,  0.6178762444026438,
                              0.7554044083550030,  0.8656312023878318,  0.9445750230732326,  0.9894009349916499};

    const double weights[16] = {0.0271524594117541, 0.0622535239386479, 0.0951585116824928, 0.1246289712555339,
                                0.1495959888165767, 0.1691565193950025, 0.1826034150449236, 0.1894506104550685,
                                0.1894506104550685, 0.1826034150449236, 0.1691565193950025, 0.1495959888165767,
                                0.1246289712555339, 0.0951585116824928, 0.0622535239386479, 0.0271524594117541};

    const double um = 0.5 * (u1 + u2);
    const double uh = 0.5 * (u2 - u1);

    double sum = 0.0;
    for (int i = 0; i < 16; ++i) {
        const double u = um + uh * nodes[i];
        const double f = std::pow(u, k) / std::pow(u * u + b * b, 0.5 * n);
        sum += weights[i] * f;
    }

    return uh * sum;
}

inline double Tesseroid_BaseIntegral(double t, double b, int n, int k) {
    const double L = std::sqrt(t * t + b * b);
    const double A = std::asinh(t / b);

    switch (n) {
    case 1:
        switch (k) {
        case 0:
            return A;
        case 1:
            return L;
        case 2:
            return 0.5 * (t * L - b * b * A);
        default:
            throw std::runtime_error("Unsupported k for n=1.");
        }

    case 3: {
        const double I30 = t / (b * b * L);
        const double I31 = -1.0 / L;
        const double I32 = A - b * b * I30;
        const double I33 = L + b * b / L;

        switch (k) {
        case 0:
            return I30;
        case 1:
            return I31;
        case 2:
            return I32;
        case 3:
            return I33;
        default:
            throw std::runtime_error("Unsupported k for n=3.");
        }
    }

    case 5: {
        const double I30 = t / (b * b * L);
        const double I31 = -1.0 / L;
        const double I32 = A - b * b * I30;

        const double L3 = L * L * L;
        const double I50 = t / (3.0 * b * b * L3) + 2.0 / (3.0 * b * b) * I30;
        const double I51 = -1.0 / (3.0 * L3);
        const double I52 = I30 - b * b * I50;
        const double I53 = I31 - b * b * I51;
        const double I54 = I32 - b * b * I52;

        switch (k) {
        case 0:
            return I50;
        case 1:
            return I51;
        case 2:
            return I52;
        case 3:
            return I53;
        case 4:
            return I54;
        default:
            throw std::runtime_error("Unsupported k for n=5.");
        }
    }

    case 7: {
        const double I30 = t / (b * b * L);
        const double I31 = -1.0 / L;
        const double I32 = A - b * b * I30;
        const double I33 = L + b * b / L;

        const double L3 = L * L * L;
        const double I50 = t / (3.0 * b * b * L3) + 2.0 / (3.0 * b * b) * I30;
        const double I51 = -1.0 / (3.0 * L3);
        const double I52 = I30 - b * b * I50;
        const double I53 = I31 - b * b * I51;
        const double I54 = I32 - b * b * I52;

        const double L5 = L3 * L * L;
        const double I70 = t / (5.0 * b * b * L5) + 4.0 / (5.0 * b * b) * I50;
        const double I71 = -1.0 / (5.0 * L5);
        const double I72 = I50 - b * b * I70;
        const double I73 = I51 - b * b * I71;
        const double I74 = I52 - b * b * I72;
        const double I75 = I53 - b * b * I73;

        switch (k) {
        case 0:
            return I70;
        case 1:
            return I71;
        case 2:
            return I72;
        case 3:
            return I73;
        case 4:
            return I74;
        case 5:
            return I75;
        default:
            throw std::runtime_error("Unsupported k for n=7.");
        }
    }

    default:
        throw std::runtime_error("Unsupported n.");
    }
}

inline double Tesseroid_StableSqrtDifference(double u1, double u2, double L1, double L2) {
    return (u2 - u1) * (u2 + u1) / (L2 + L1);
}

inline double Tesseroid_StableUOverPowerDifference(double u1, double u2, double L1, double L2, int power,
                                                   bool& reliable) {
    if (u1 == 0.0 || u2 == 0.0 || u1 * u2 < 0.0) {
        return u2 / std::pow(L2, power) - u1 / std::pow(L1, power);
    }

    const double logU = Tesseroid_LogRatio(std::abs(u2), std::abs(u1));
    const double dL = Tesseroid_StableSqrtDifference(u1, u2, L1, L2);
    const double logL = std::log1p(dL / L1);
    const double deltaLog = logU - static_cast<double>(power) * logL;
    const double logScale = std::abs(logU) + static_cast<double>(power) * std::abs(logL);
    if (std::abs(deltaLog) <= 1.0e-10 * logScale) {
        reliable = false;
    }

    return u1 / std::pow(L1, power) * std::expm1(deltaLog);
}

inline double Tesseroid_StableInversePowerDifference(double u1, double u2, double L1, double L2, int power) {
    const double dL = Tesseroid_StableSqrtDifference(u1, u2, L1, L2);
    const double logL = std::log1p(dL / L1);
    return std::pow(L1, -power) * std::expm1(-static_cast<double>(power) * logL);
}

inline void Tesseroid_StableBaseMomentDiffTable(double u1, double u2, double b, int n, int maxK, double* output,
                                                bool& reliable) {
    reliable = true;
    const double b2 = b * b;
    const double L1 = std::hypot(u1, b);
    const double L2 = std::hypot(u2, b);
    double D[4][6] = {};

    if (u1 > 0.0 && u2 > 0.0) {
        D[0][0] = Tesseroid_LogRatio(u2 + L2, u1 + L1);
    } else if (u1 < 0.0 && u2 < 0.0) {
        D[0][0] = Tesseroid_LogRatio(L1 - u1, L2 - u2);
    } else {
        D[0][0] = std::asinh(u2 / b) - std::asinh(u1 / b);
    }

    if (maxK >= 1) {
        D[0][1] = Tesseroid_StableSqrtDifference(u1, u2, L1, L2);
    }
    if (maxK >= 2) {
        double deltaUL;
        if (u1 * u2 > 0.0) {
            const double denominator = u2 * L2 + u1 * L1;
            if (denominator == 0.0) {
                reliable = false;
                deltaUL = u2 * L2 - u1 * L1;
            } else {
                deltaUL = (u2 - u1) * (u2 + u1) * (u2 * u2 + u1 * u1 + b2) / denominator;
            }
        } else {
            deltaUL = u2 * L2 - u1 * L1;
        }
        D[0][2] = 0.5 * (deltaUL - b2 * D[0][0]);
    }

    const int targetIndex = (n - 1) / 2;
    for (int index = 1; index <= targetIndex; ++index) {
        const int currentN = 2 * index + 1;
        const int power = currentN - 2;
        const double inv = 1.0 / (static_cast<double>(power) * b2);
        bool endpointReliable = true;
        const double endpoint0 = Tesseroid_StableUOverPowerDifference(u1, u2, L1, L2, power, endpointReliable);
        const double term0 = inv * endpoint0;
        const double term1 = static_cast<double>(currentN - 3) * inv * D[index - 1][0];
        D[index][0] = term0 + term1;
        reliable = reliable && endpointReliable;
        if (currentN > 3 && std::abs(D[index][0]) <= 1.0e-10 * (std::abs(term0) + std::abs(term1))) {
            reliable = false;
        }

        if (maxK >= 1) {
            D[index][1] = -Tesseroid_StableInversePowerDifference(u1, u2, L1, L2, power) / static_cast<double>(power);
        }

        const int supportedMaxK = currentN == 3 ? 3 : (currentN == 5 ? 4 : 5);
        for (int currentK = 2; currentK <= std::min(maxK, supportedMaxK); ++currentK) {
            const double first = D[index - 1][currentK - 2];
            const double second = b2 * D[index][currentK - 2];
            D[index][currentK] = std::fma(-b2, D[index][currentK - 2], first);
            if (std::abs(D[index][currentK]) <= 1.0e-10 * (std::abs(first) + std::abs(second))) {
                reliable = false;
            }
        }
    }

    for (int currentK = 0; currentK <= maxK; ++currentK) {
        output[currentK] = D[targetIndex][currentK];
        reliable = reliable && std::isfinite(output[currentK]);
    }
}

inline void Tesseroid_BaseMomentDiffTable(double u1, double u2, double b, int n, int maxK, double* output) {
    if (u1 == u2) {
        std::fill(output, output + maxK + 1, 0.0);
        return;
    }

    double a = u1;
    double bnd = u2;
    double orderSign = 1.0;
    if (bnd < a) {
        std::swap(a, bnd);
        orderSign = -1.0;
    }

    b = std::abs(b);
    if (b == 0.0) {
        b = std::numeric_limits<double>::min();
    }

    if (a * bnd > 0.0) {
        const double qmin = std::min(std::abs(a), std::abs(bnd));
        const double eta = b / std::max(qmin, std::numeric_limits<double>::min());
        if (eta < 1.0e-2) {
            for (int k = 0; k <= maxK; ++k) {
                output[k] = orderSign * Tesseroid_BaseMomentSmallB(a, bnd, b, n, k);
            }
            return;
        }
    }

    bool reliable = true;
    Tesseroid_StableBaseMomentDiffTable(a, bnd, b, n, maxK, output, reliable);
    if (reliable) {
        for (int k = 0; k <= maxK; ++k) {
            output[k] *= orderSign;
        }
        return;
    }

    for (int k = 0; k <= maxK; ++k) {
        output[k] = orderSign * Tesseroid_BaseMomentGauss16(a, bnd, b, n, k);
    }
}

inline double Tesseroid_BaseMomentDiff(double u1, double u2, double b, int n, int k) {
    double moments[6] = {};
    Tesseroid_BaseMomentDiffTable(u1, u2, b, n, k, moments);
    return moments[k];
}

inline Matrix14 Tesseroid_RadialMoment(double R2, double R1, const Matrix14& SinPsi, const Matrix14& CosPsi, int n,
                                       int p) {
    Matrix14 M = Matrix14::Zero();

    for (int i = 0; i < 14; ++i) {
        for (int j = 0; j < 14; ++j) {
            const double b = std::abs(SinPsi(i, j));
            const double c = Tesseroid_Clamp(CosPsi(i, j), -1.0, 1.0);
            const double u1 = R1 - c;
            const double u2 = R2 - c;

            double moments[6] = {};
            Tesseroid_BaseMomentDiffTable(u1, u2, b, n, p, moments);
            double val = 0.0;
            for (int k = 0; k <= p; ++k) {
                const double coef = static_cast<double>(Tesseroid_Binomial(p, k)) * std::pow(c, p - k);
                val += coef * moments[k];
            }
            M(i, j) = val;
        }
    }

    return M;
}

inline Matrix14 Tesseroid_ZMoment(double R2, double R1, const Matrix14& SinPsi, const Matrix14& CosPsi, int n, int p,
                                  int q) {
    Matrix14 Z = Matrix14::Zero();

    for (int i = 0; i < 14; ++i) {
        for (int j = 0; j < 14; ++j) {
            const double b = std::abs(SinPsi(i, j));
            const double c = Tesseroid_Clamp(CosPsi(i, j), -1.0, 1.0);
            const double u1 = R1 - c;
            const double u2 = R2 - c;

            double moments[6] = {};
            Tesseroid_BaseMomentDiffTable(u1, u2, b, n, p + q, moments);
            double val = 0.0;
            for (int k = 0; k <= p; ++k) {
                const double coefR = static_cast<double>(Tesseroid_Binomial(p, k)) * std::pow(c, p - k);

                for (int m = 0; m <= q; ++m) {
                    const double coefZ =
                        static_cast<double>(Tesseroid_Binomial(q, m)) * std::pow(c, m) * std::pow(-b * b, q - m);
                    val += coefR * coefZ * moments[k + m];
                }
            }
            Z(i, j) = val;
        }
    }

    return Z;
}

inline void Tesseroid_LocalGeometryScalar(double Fai, double Lamda, double fai, double lamda, double& Tx, double& Ty,
                                          double& SinPsi, double& CosPsi) {
    const double f = fai * TESSEROID_RAD;
    const double F = Fai * TESSEROID_RAD;
    const double dL = (Lamda - lamda) * TESSEROID_RAD;
    const double cf = std::cos(f);
    const double sf = std::sin(f);
    const double cF = std::cos(F);
    const double sF = std::sin(F);
    Tx = cf * sF - sf * cF * std::cos(dL);
    Ty = cF * std::sin(dL);
    SinPsi = std::hypot(Tx, Ty);
    CosPsi = Tesseroid_Clamp(sf * sF + cf * cF * std::cos(dL), -1.0, 1.0);
}

inline double Tesseroid_RadialMomentScalar(double R2, double R1, double SinPsi, double CosPsi, int n, int p) {
    const double b = std::abs(SinPsi);
    const double c = Tesseroid_Clamp(CosPsi, -1.0, 1.0);
    const double u1 = R1 - c;
    const double u2 = R2 - c;
    double moments[6] = {};
    Tesseroid_BaseMomentDiffTable(u1, u2, b, n, p, moments);
    double value = 0.0;
    for (int k = 0; k <= p; ++k) {
        value += static_cast<double>(Tesseroid_Binomial(p, k)) * std::pow(c, p - k) * moments[k];
    }
    return value;
}

inline double Tesseroid_ZMomentScalar(double R2, double R1, double SinPsi, double CosPsi, int n, int p, int q) {
    const double b = std::abs(SinPsi);
    const double c = Tesseroid_Clamp(CosPsi, -1.0, 1.0);
    const double u1 = R1 - c;
    const double u2 = R2 - c;
    double moments[6] = {};
    Tesseroid_BaseMomentDiffTable(u1, u2, b, n, p + q, moments);
    double value = 0.0;
    for (int k = 0; k <= p; ++k) {
        const double coefR = static_cast<double>(Tesseroid_Binomial(p, k)) * std::pow(c, p - k);
        for (int m = 0; m <= q; ++m) {
            const double coefZ =
                static_cast<double>(Tesseroid_Binomial(q, m)) * std::pow(c, m) * std::pow(-b * b, q - m);
            value += coefR * coefZ * moments[k + m];
        }
    }
    return value;
}

inline double Tesseroid_IntegralkernelScalar(const std::string& component, double R2, double R1, double Fai,
                                             double Lamda, double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);
    double Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometryScalar(Fai, Lamda, fai, lamda, Tx, Ty, SinPsi, CosPsi);
    const double C = std::cos(Fai * TESSEROID_RAD);
    double value = 0.0;

    if (component == "V")
        value = Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 1, 2);
    else if (component == "Vx")
        value = Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 3, 3);
    else if (component == "Vy")
        value = Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 3, 3);
    else if (component == "Vz")
        value = Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 3, 2, 1);
    else if (component == "Vxx") {
        value = 3.0 * Tx * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 4) -
                Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 3, 2);
    } else if (component == "Vxy")
        value = 3.0 * Tx * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 4);
    else if (component == "Vyy") {
        value = 3.0 * Ty * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 4) -
                Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 3, 2);
    } else if (component == "Vzx")
        value = 3.0 * Tx * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3, 1);
    else if (component == "Vzy")
        value = 3.0 * Ty * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3, 1);
    else if (component == "Vzz") {
        value = 3.0 * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 2, 2) -
                Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 3, 2);
    } else if (component == "Vxxx") {
        value = 15.0 * Tx * Tx * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 7, 5) -
                9.0 * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vxxy") {
        value = 15.0 * Tx * Tx * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 7, 5) -
                3.0 * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vxxz") {
        value = 15.0 * Tx * Tx * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 4, 1) -
                3.0 * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    } else if (component == "Vxyz")
        value = 15.0 * Tx * Ty * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 4, 1);
    else if (component == "Vyyx") {
        value = 15.0 * Ty * Ty * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 7, 5) -
                3.0 * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vyyy") {
        value = 15.0 * Ty * Ty * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 7, 5) -
                9.0 * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vyyz") {
        value = 15.0 * Ty * Ty * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 4, 1) -
                3.0 * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    } else if (component == "Vzzx") {
        value = 15.0 * Tx * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 3, 2) -
                3.0 * Tx * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vzzy") {
        value = 15.0 * Ty * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 3, 2) -
                3.0 * Ty * Tesseroid_RadialMomentScalar(R2, R1, SinPsi, CosPsi, 5, 3);
    } else if (component == "Vzzz") {
        value = 15.0 * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 7, 2, 3) -
                9.0 * Tesseroid_ZMomentScalar(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    }

    return C * value;
}

inline Matrix14 Tesseroid_IntegralkernelV(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI, double r,
                                          double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M12 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 1, 2);

    return C.cwiseProduct(M12);
}

inline Matrix14 Tesseroid_IntegralkernelVx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI, double r,
                                           double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M33 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 3, 3);

    return C.cwiseProduct(Tx.cwiseProduct(M33));
}

inline Matrix14 Tesseroid_IntegralkernelVy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI, double r,
                                           double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M33 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 3, 3);

    return C.cwiseProduct(Ty.cwiseProduct(M33));
}

inline Matrix14 Tesseroid_IntegralkernelVz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI, double r,
                                           double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z321 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 3, 2, 1);

    return C.cwiseProduct(Z321);
}

inline Matrix14 Tesseroid_IntegralkernelVxx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M32 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 3, 2);
    const Matrix14 M54 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 4);

    return C.cwiseProduct(3.0 * Tx.cwiseProduct(Tx).cwiseProduct(M54) - M32);
}

inline Matrix14 Tesseroid_IntegralkernelVxy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M54 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 4);

    return C.cwiseProduct(3.0 * Tx.cwiseProduct(Ty).cwiseProduct(M54));
}

inline Matrix14 Tesseroid_IntegralkernelVyy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M32 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 3, 2);
    const Matrix14 M54 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 4);

    return C.cwiseProduct(3.0 * Ty.cwiseProduct(Ty).cwiseProduct(M54) - M32);
}

inline Matrix14 Tesseroid_IntegralkernelVzx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z531 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 3, 1);

    return C.cwiseProduct(3.0 * Tx.cwiseProduct(Z531));
}

inline Matrix14 Tesseroid_IntegralkernelVzy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z531 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 3, 1);

    return C.cwiseProduct(3.0 * Ty.cwiseProduct(Z531));
}

inline Matrix14 Tesseroid_IntegralkernelVzz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                            double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M32 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 3, 2);
    const Matrix14 Z522 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 2, 2);

    return C.cwiseProduct(3.0 * Z522 - M32);
}

inline Matrix14 Tesseroid_IntegralkernelVxxx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 M75 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 7, 5);

    return C.cwiseProduct(15.0 * Tx.cwiseProduct(Tx).cwiseProduct(Tx).cwiseProduct(M75) - 9.0 * Tx.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVxxy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 M75 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 7, 5);

    return C.cwiseProduct(15.0 * Tx.cwiseProduct(Tx).cwiseProduct(Ty).cwiseProduct(M75) - 3.0 * Ty.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVxxz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z521 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    const Matrix14 Z741 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 4, 1);

    return C.cwiseProduct(15.0 * Tx.cwiseProduct(Tx).cwiseProduct(Z741) - 3.0 * Z521);
}

inline Matrix14 Tesseroid_IntegralkernelVxyz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z741 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 4, 1);

    return C.cwiseProduct(15.0 * Tx.cwiseProduct(Ty).cwiseProduct(Z741));
}

inline Matrix14 Tesseroid_IntegralkernelVyyx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 M75 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 7, 5);

    return C.cwiseProduct(15.0 * Ty.cwiseProduct(Ty).cwiseProduct(Tx).cwiseProduct(M75) - 3.0 * Tx.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVyyy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 M75 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 7, 5);

    return C.cwiseProduct(15.0 * Ty.cwiseProduct(Ty).cwiseProduct(Ty).cwiseProduct(M75) - 9.0 * Ty.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVyyz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z521 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    const Matrix14 Z741 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 4, 1);

    return C.cwiseProduct(15.0 * Ty.cwiseProduct(Ty).cwiseProduct(Z741) - 3.0 * Z521);
}

inline Matrix14 Tesseroid_IntegralkernelVzzx(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 Z732 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 3, 2);

    return C.cwiseProduct(15.0 * Tx.cwiseProduct(Z732) - 3.0 * Tx.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVzzy(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 M53 = Tesseroid_RadialMoment(R2, R1, SinPsi, CosPsi, 5, 3);
    const Matrix14 Z732 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 3, 2);

    return C.cwiseProduct(15.0 * Ty.cwiseProduct(Z732) - 3.0 * Ty.cwiseProduct(M53));
}

inline Matrix14 Tesseroid_IntegralkernelVzzz(double R2, double R1, const Matrix14& FaiI, const Matrix14& LamdaI,
                                             double r, double fai, double lamda) {
    Tesseroid_NormalizedRadius(R2, R1, r, R2, R1);

    Matrix14 Tx, Ty, SinPsi, CosPsi;
    Tesseroid_LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);

    const Matrix14 C = Tesseroid_CosFaiMatrix(FaiI);
    const Matrix14 Z521 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 5, 2, 1);
    const Matrix14 Z723 = Tesseroid_ZMoment(R2, R1, SinPsi, CosPsi, 7, 2, 3);

    return C.cwiseProduct(15.0 * Z723 - 9.0 * Z521);
}

}
