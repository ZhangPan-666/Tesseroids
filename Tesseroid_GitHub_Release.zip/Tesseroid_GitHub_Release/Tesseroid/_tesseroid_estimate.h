﻿
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <functional>
#include <iostream>
#include <malloc.h>
#include <memory.h>
#include <mpi.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>

#include "_integral2.h"
#include "_tesseroid_integralkernel.h"

namespace Tesseroid {

inline void MPIDistribute(int Num, int* DataList, int* VectorShiftList) {
    int i, j;
    int rank, nprocs;
    int DataPerBatch, NumRemain;

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    NumRemain = Num % nprocs;
    DataPerBatch = (Num - NumRemain) / nprocs;

    for (i = 1; i <= nprocs; i++) {
        if (i <= NumRemain) {
            DataList[i - 1] = DataPerBatch + 1;
        } else {
            DataList[i - 1] = DataPerBatch;
        }
    }

    for (i = 1; i <= nprocs; i++) {
        VectorShiftList[i - 1] = 0;

        if (i == 1) {
            continue;
        }

        for (j = 1; j <= (i - 1); j++) {
            VectorShiftList[i - 1] += DataList[j - 1];
        }
    }
}

inline std::vector<std::array<double, 4>> splitTesseroid(double Fai1, double Fai2, double Lamda1, double Lamda2,
                                                         double P_Fai, double P_Lamda, double dFai, double dLamda) {
    if (P_Fai < Fai1 || P_Fai > Fai2 || P_Lamda < Lamda1 || P_Lamda > Lamda2) {
        return {{Fai1, Fai2, Lamda1, Lamda2}};
    }

    double half_dFai = dFai / 2.0;
    double half_dLamda = dLamda / 2.0;

    double small_Fai1 = std::max(P_Fai - half_dFai, Fai1);
    double small_Fai2 = std::min(P_Fai + half_dFai, Fai2);
    double small_Lamda1 = std::max(P_Lamda - half_dLamda, Lamda1);
    double small_Lamda2 = std::min(P_Lamda + half_dLamda, Lamda2);

    std::vector<std::array<double, 4>> split_rectangles;

    if (small_Fai2 < Fai2) {
        split_rectangles.push_back({small_Fai2, Fai2, Lamda1, Lamda2});
    }

    if (small_Fai1 > Fai1) {
        split_rectangles.push_back({Fai1, small_Fai1, Lamda1, Lamda2});
    }

    if (small_Lamda1 > Lamda1) {
        split_rectangles.push_back({small_Fai1, small_Fai2, Lamda1, small_Lamda1});
    }

    if (small_Lamda2 < Lamda2) {
        split_rectangles.push_back({small_Fai1, small_Fai2, small_Lamda2, Lamda2});
    }

    return split_rectangles;
}

using TesseroidKernelFunction = std::function<Matrix14(const Matrix14&, const Matrix14&)>;
using TesseroidPeakFunction = std::function<double(double, double)>;

enum class TesseroidPeakPattern { CenterOne, XTwo, YTwo, XThree, YThree, DiagonalFour, XFour, YFour, XXYSix, YYXSix };

inline double Tesseroid_NormalizeLon180Scalar(double lon) {
    lon = std::fmod(lon + 180.0, 360.0);
    if (lon < 0.0) {
        lon += 360.0;
    }
    return lon - 180.0;
}

inline double Tesseroid_KernelScalar(const TesseroidKernelFunction& fun, double lat, double lon) {
    const Matrix14 F = Matrix14::Constant(lat);
    const Matrix14 L = Matrix14::Constant(lon);
    const Matrix14 Z = fun(F, L);
    const double y = Z(0, 0);
    return std::isfinite(y) ? y : 0.0;
}

inline double Tesseroid_KahanSum(const std::vector<double>& values) {
    double sum = 0.0;
    double c = 0.0;
    for (const double value : values) {
        const double y = value - c;
        const double t = sum + y;
        c = (t - sum) - y;
        sum = t;
    }
    return sum;
}

inline std::vector<double> Tesseroid_UniqueFinite(std::vector<double> values) {
    values.erase(std::remove_if(values.begin(), values.end(), [](double x) { return !std::isfinite(x); }),
                 values.end());

    if (values.empty()) {
        return values;
    }

    std::sort(values.begin(), values.end());
    double maxAbs = 1.0;
    for (const double x : values) {
        maxAbs = std::max(maxAbs, std::abs(x));
    }
    const double tol = 1.0e-10 * maxAbs;

    std::vector<double> unique;
    unique.reserve(values.size());
    unique.push_back(values.front());
    for (std::size_t i = 1; i < values.size(); ++i) {
        if (std::abs(values[i] - unique.back()) > tol) {
            unique.push_back(values[i]);
        }
    }
    return unique;
}

inline std::vector<double> Tesseroid_CleanBreaks(std::vector<double> breaks, double a, double b) {
    breaks.erase(std::remove_if(breaks.begin(), breaks.end(), [](double x) { return !std::isfinite(x); }),
                 breaks.end());

    for (double& x : breaks) {
        x = std::min(b, std::max(a, x));
    }
    std::sort(breaks.begin(), breaks.end());

    if (breaks.empty()) {
        return {a, b};
    }

    const double tol = std::max(1.0e-12, 1.0e-10 * std::max(1.0, std::abs(b - a)));
    std::vector<double> clean;
    clean.reserve(breaks.size() + 2);
    clean.push_back(breaks.front());
    for (std::size_t i = 1; i < breaks.size(); ++i) {
        if (std::abs(breaks[i] - clean.back()) > tol) {
            clean.push_back(breaks[i]);
        }
    }

    if (clean.front() > a + tol) {
        clean.insert(clean.begin(), a);
    } else {
        clean.front() = a;
    }

    if (clean.back() < b - tol) {
        clean.push_back(b);
    } else {
        clean.back() = b;
    }

    return clean;
}

inline void Tesseroid_AddBreaksWithEdgeSnap(std::vector<double>& breaks, const std::vector<double>& candidates,
                                            double a, double b, double edgeTol) {
    const double breakTol = std::max(1.0e-12, 1.0e-12 * std::max(1.0, std::abs(b - a)));

    for (double x : candidates) {
        if (!std::isfinite(x)) {
            continue;
        }

        if (std::abs(x - a) <= edgeTol) {
            x = a;
        } else if (std::abs(x - b) <= edgeTol) {
            x = b;
        } else if (x < a - edgeTol || x > b + edgeTol) {
            continue;
        }

        if (x > a + breakTol && x < b - breakTol) {
            breaks.push_back(x);
        }
    }
}

inline TesseroidPeakPattern Tesseroid_PeakPattern(const std::string& componentName) {
    if (componentName == "V" || componentName == "Vz" || componentName == "Vzz" || componentName == "Vzzz") {
        return TesseroidPeakPattern::CenterOne;
    }
    if (componentName == "Vx" || componentName == "Vzx" || componentName == "Vzzx") {
        return TesseroidPeakPattern::XTwo;
    }
    if (componentName == "Vy" || componentName == "Vzy" || componentName == "Vzzy") {
        return TesseroidPeakPattern::YTwo;
    }
    if (componentName == "Vxx" || componentName == "Vxxz") {
        return TesseroidPeakPattern::XThree;
    }
    if (componentName == "Vyy" || componentName == "Vyyz") {
        return TesseroidPeakPattern::YThree;
    }
    if (componentName == "Vxy" || componentName == "Vxyz") {
        return TesseroidPeakPattern::DiagonalFour;
    }
    if (componentName == "Vxxx") {
        return TesseroidPeakPattern::XFour;
    }
    if (componentName == "Vyyy") {
        return TesseroidPeakPattern::YFour;
    }
    if (componentName == "Vxxy") {
        return TesseroidPeakPattern::XXYSix;
    }
    if (componentName == "Vyyx") {
        return TesseroidPeakPattern::YYXSix;
    }
    return TesseroidPeakPattern::CenterOne;
}

inline void Tesseroid_SearchWindowDeg(double fai, double dFaiBase, double dLonBase, double r, double R1, double R2,
                                      double& searchLat, double& searchLon) {
    const double cosF = std::max(std::abs(std::cos(fai * TESSEROID_RAD)), 1.0e-6);

    double h = 0.0;
    if (r > R2) {
        h = r - R2;
    } else if (r < R1) {
        h = R1 - r;
    } else {
        h = std::min(std::abs(r - R1), std::abs(R2 - r));
    }

    const double hDeg = std::atan2(std::max(h, 0.0), std::max(std::abs(r), std::numeric_limits<double>::epsilon())) *
                        180.0 / TESSEROID_PI;
    double basePhys = std::max(std::abs(dFaiBase), std::abs(dLonBase) * cosF);
    if (basePhys <= 0.0 || !std::isfinite(basePhys)) {
        basePhys = 0.1;
    }

    double searchPhys = std::max(12.0 * hDeg, std::min(0.25 * basePhys, 0.2));
    searchPhys = std::max(searchPhys, std::min(0.05, basePhys));
    searchPhys = std::min(searchPhys, std::max(2.0 * basePhys, 0.1));
    searchPhys = std::max(searchPhys, 1.0e-8);

    searchLat = std::min(searchPhys, 180.0);
    searchLon = std::min(searchPhys / cosF, 360.0);
}

inline double Tesseroid_GoldenMaxAbs1D(const std::function<double(double)>& fline, double a, double b) {
    if (!(b > a)) {
        return a;
    }

    const double gr = (std::sqrt(5.0) - 1.0) * 0.5;
    double c = b - gr * (b - a);
    double d = a + gr * (b - a);
    double fc = std::abs(fline(c));
    double fd = std::abs(fline(d));

    if (!std::isfinite(fc))
        fc = 0.0;
    if (!std::isfinite(fd))
        fd = 0.0;

    for (int iter = 0; iter < 80; ++iter) {
        if (std::abs(b - a) <= 1.0e-12 * std::max(1.0, std::abs(a) + std::abs(b))) {
            break;
        }

        if (fc < fd) {
            a = c;
            c = d;
            fc = fd;
            d = a + gr * (b - a);
            fd = std::abs(fline(d));
            if (!std::isfinite(fd))
                fd = 0.0;
        } else {
            b = d;
            d = c;
            fd = fc;
            c = b - gr * (b - a);
            fc = std::abs(fline(c));
            if (!std::isfinite(fc))
                fc = 0.0;
        }
    }

    return 0.5 * (a + b);
}

inline std::vector<double> Tesseroid_FindPeaks1D(const std::function<double(double)>& fline, double a, double b,
                                                 int nPeaks) {
    std::vector<double> peaks;
    if (nPeaks <= 0 || !(b > a)) {
        return peaks;
    }

    const int N = std::max(129, 65 * nPeaks);
    std::vector<double> x(N);
    std::vector<double> z(N);
    for (int i = 0; i < N; ++i) {
        const double t = 0.5 - 0.5 * std::cos(TESSEROID_PI * static_cast<double>(i) / static_cast<double>(N - 1));
        x[i] = a + (b - a) * t;
        z[i] = std::abs(fline(x[i]));
        if (!std::isfinite(z[i])) {
            z[i] = -std::numeric_limits<double>::infinity();
        }
    }

    bool hasFinite = false;
    for (const double zi : z) {
        if (std::isfinite(zi)) {
            hasFinite = true;
            break;
        }
    }
    if (!hasFinite) {
        return peaks;
    }

    std::vector<int> candidateIdx;
    for (int i = 1; i < N - 1; ++i) {
        if (z[i] >= z[i - 1] && z[i] >= z[i + 1]) {
            candidateIdx.push_back(i);
        }
    }

    if (candidateIdx.empty()) {
        int best = 1;
        for (int i = 2; i < N - 1; ++i) {
            if (z[i] > z[best]) {
                best = i;
            }
        }
        candidateIdx.push_back(best);
    }

    std::sort(candidateIdx.begin(), candidateIdx.end(), [&](int lhs, int rhs) { return z[lhs] > z[rhs]; });

    const double minSep = 0.01 * (b - a);
    for (const int idx : candidateIdx) {
        const int i1 = std::max(0, idx - 2);
        const int i2 = std::min(N - 1, idx + 2);
        double pp = x[idx];
        if (x[i2] > x[i1]) {
            pp = Tesseroid_GoldenMaxAbs1D(fline, x[i1], x[i2]);
        }

        bool separated = true;
        for (const double p : peaks) {
            if (std::abs(pp - p) <= minSep) {
                separated = false;
                break;
            }
        }

        if (separated) {
            peaks.push_back(pp);
        }
        if (static_cast<int>(peaks.size()) >= nPeaks) {
            break;
        }
    }

    return peaks;
}

inline void Tesseroid_FindPeaksMeridian(const TesseroidPeakFunction& fun, double fai, double lon0, double searchLat,
                                        int nAbove, int nBelow, std::vector<double>& latPeaks,
                                        std::vector<double>& lonPeaks) {
    const double epsDeg = std::max(1.0e-10, 1.0e-8 * searchLat);
    const double lo = std::max(-90.0, fai - searchLat);
    const double hi = std::min(90.0, fai + searchLat);

    if (nBelow > 0 && fai - epsDeg > lo) {
        auto fline = [&](double lat) { return fun(lat, lon0); };
        const auto peaks = Tesseroid_FindPeaks1D(fline, lo, fai - epsDeg, nBelow);
        for (const double p : peaks) {
            latPeaks.push_back(p);
            lonPeaks.push_back(lon0);
        }
    }

    if (nAbove > 0 && hi > fai + epsDeg) {
        auto fline = [&](double lat) { return fun(lat, lon0); };
        const auto peaks = Tesseroid_FindPeaks1D(fline, fai + epsDeg, hi, nAbove);
        for (const double p : peaks) {
            latPeaks.push_back(p);
            lonPeaks.push_back(lon0);
        }
    }
}

inline void Tesseroid_FindPeaksParallel(const TesseroidPeakFunction& fun, double lat0, double lamda, double searchLon,
                                        int nRight, int nLeft, std::vector<double>& latPeaks,
                                        std::vector<double>& lonPeaks) {
    const double epsDeg = std::max(1.0e-10, 1.0e-8 * searchLon);
    const double lo = std::max(-180.0, lamda - searchLon);
    const double hi = std::min(180.0, lamda + searchLon);

    if (nLeft > 0 && lamda - epsDeg > lo) {
        auto fline = [&](double lon) { return fun(lat0, lon); };
        const auto peaks = Tesseroid_FindPeaks1D(fline, lo, lamda - epsDeg, nLeft);
        for (const double p : peaks) {
            latPeaks.push_back(lat0);
            lonPeaks.push_back(p);
        }
    }

    if (nRight > 0 && hi > lamda + epsDeg) {
        auto fline = [&](double lon) { return fun(lat0, lon); };
        const auto peaks = Tesseroid_FindPeaks1D(fline, lamda + epsDeg, hi, nRight);
        for (const double p : peaks) {
            latPeaks.push_back(lat0);
            lonPeaks.push_back(p);
        }
    }
}

inline void Tesseroid_FindPeaksMeridianFour(const TesseroidPeakFunction& fun, double fai, double lon0, double searchLat,
                                            std::vector<double>& latPeaks, std::vector<double>& lonPeaks) {
    Tesseroid_FindPeaksMeridian(fun, fai, lon0, searchLat, 2, 2, latPeaks, lonPeaks);
}

inline void Tesseroid_FindPeaksParallelFour(const TesseroidPeakFunction& fun, double lat0, double lamda,
                                            double searchLon, std::vector<double>& latPeaks,
                                            std::vector<double>& lonPeaks) {
    Tesseroid_FindPeaksParallel(fun, lat0, lamda, searchLon, 2, 2, latPeaks, lonPeaks);
}

inline void Tesseroid_FindPeaksDiagonal(const TesseroidPeakFunction& fun, double fai, double lamda, double searchLat,
                                        double searchLon, std::vector<double>& latPeaks,
                                        std::vector<double>& lonPeaks) {
    const double cosF = std::abs(std::cos(fai * TESSEROID_RAD));
    if (cosF < 1.0e-8) {
        return;
    }

    const double sMax = std::min(searchLat, searchLon * cosF);
    if (sMax <= 0.0) {
        return;
    }

    const double epsS = std::max(1.0e-10, 1.0e-8 * sMax);
    const int signs[2] = {-1, 1};
    for (const int sx : signs) {
        for (const int sy : signs) {
            auto fline = [&](double s) {
                return fun(fai + sx * s, Tesseroid_NormalizeLon180Scalar(lamda + sy * s / cosF));
            };

            const auto peaks = Tesseroid_FindPeaks1D(fline, epsS, sMax, 1);
            if (!peaks.empty()) {
                const double p = peaks.front();
                latPeaks.push_back(fai + sx * p);
                lonPeaks.push_back(Tesseroid_NormalizeLon180Scalar(lamda + sy * p / cosF));
            }
        }
    }
}

inline void Tesseroid_RemoveDuplicatePeaks(std::vector<double>& latPeaks, std::vector<double>& lonPeaks) {
    std::vector<std::array<double, 2>> peaks;
    peaks.reserve(latPeaks.size());
    for (std::size_t i = 0; i < latPeaks.size() && i < lonPeaks.size(); ++i) {
        if (std::isfinite(latPeaks[i]) && std::isfinite(lonPeaks[i])) {
            peaks.push_back({latPeaks[i], lonPeaks[i]});
        }
    }

    const double tol = 1.0e-8;
    std::vector<std::array<double, 2>> unique;
    for (const auto& p : peaks) {
        bool duplicate = false;
        for (const auto& q : unique) {
            if (std::abs(p[0] - q[0]) < tol && std::abs(p[1] - q[1]) < tol) {
                duplicate = true;
                break;
            }
        }
        if (!duplicate) {
            unique.push_back(p);
        }
    }

    latPeaks.clear();
    lonPeaks.clear();
    latPeaks.reserve(unique.size());
    lonPeaks.reserve(unique.size());
    for (const auto& p : unique) {
        latPeaks.push_back(p[0]);
        lonPeaks.push_back(p[1]);
    }
}

inline void Tesseroid_FindAllKernelPeaks(const TesseroidPeakFunction& fun, const std::string& componentName, double fai,
                                         double lamda, double dFaiBase, double dLonBase, double r, double R1, double R2,
                                         std::vector<double>& latPeaks, std::vector<double>& lonPeaks) {
    latPeaks.clear();
    lonPeaks.clear();

    const TesseroidPeakPattern pattern = Tesseroid_PeakPattern(componentName);
    double searchLat = 0.0;
    double searchLon = 0.0;
    Tesseroid_SearchWindowDeg(fai, dFaiBase, dLonBase, r, R1, R2, searchLat, searchLon);

    switch (pattern) {
    case TesseroidPeakPattern::CenterOne:
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidPeakPattern::XTwo:
        Tesseroid_FindPeaksMeridian(fun, fai, lamda, searchLat, 1, 1, latPeaks, lonPeaks);
        break;

    case TesseroidPeakPattern::YTwo:
        Tesseroid_FindPeaksParallel(fun, fai, lamda, searchLon, 1, 1, latPeaks, lonPeaks);
        break;

    case TesseroidPeakPattern::XThree:
        Tesseroid_FindPeaksMeridian(fun, fai, lamda, searchLat, 1, 1, latPeaks, lonPeaks);
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidPeakPattern::YThree:
        Tesseroid_FindPeaksParallel(fun, fai, lamda, searchLon, 1, 1, latPeaks, lonPeaks);
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidPeakPattern::DiagonalFour:
        Tesseroid_FindPeaksDiagonal(fun, fai, lamda, searchLat, searchLon, latPeaks, lonPeaks);
        break;

    case TesseroidPeakPattern::XFour:
        Tesseroid_FindPeaksMeridianFour(fun, fai, lamda, searchLat, latPeaks, lonPeaks);
        break;

    case TesseroidPeakPattern::YFour:
        Tesseroid_FindPeaksParallelFour(fun, fai, lamda, searchLon, latPeaks, lonPeaks);
        break;

    case TesseroidPeakPattern::XXYSix: {
        std::vector<double> mainLat, mainLon;
        Tesseroid_FindPeaksParallel(fun, fai, lamda, searchLon, 1, 1, mainLat, mainLon);
        latPeaks.insert(latPeaks.end(), mainLat.begin(), mainLat.end());
        lonPeaks.insert(lonPeaks.end(), mainLon.begin(), mainLon.end());
        for (const double lon0 : mainLon) {
            Tesseroid_FindPeaksMeridian(fun, fai, lon0, searchLat, 1, 1, latPeaks, lonPeaks);
        }
        break;
    }

    case TesseroidPeakPattern::YYXSix: {
        std::vector<double> mainLat, mainLon;
        Tesseroid_FindPeaksMeridian(fun, fai, lamda, searchLat, 1, 1, mainLat, mainLon);
        latPeaks.insert(latPeaks.end(), mainLat.begin(), mainLat.end());
        lonPeaks.insert(lonPeaks.end(), mainLon.begin(), mainLon.end());

        const double cosE = std::max(std::abs(std::cos(fai * TESSEROID_RAD)), 1.0e-6);
        for (const double lat0 : mainLat) {
            const double cosAux = std::max(std::abs(std::cos(lat0 * TESSEROID_RAD)), 1.0e-6);
            const double searchLonAux = searchLon * cosE / cosAux;
            Tesseroid_FindPeaksParallel(fun, lat0, lamda, searchLonAux, 1, 1, latPeaks, lonPeaks);
        }
        break;
    }
    }

    Tesseroid_RemoveDuplicatePeaks(latPeaks, lonPeaks);
}

inline void Tesseroid_PeakGroupBreakCandidates(const std::string& componentName, const std::vector<double>& latPeaksIn,
                                               const std::vector<double>& lonPeaksIn, double fai, double lamda,
                                               std::vector<double>& latCuts, std::vector<double>& lonCuts) {
    latCuts.clear();
    lonCuts.clear();

    std::vector<double> latPeaks;
    std::vector<double> lonPeaks;
    for (std::size_t i = 0; i < latPeaksIn.size() && i < lonPeaksIn.size(); ++i) {
        if (std::isfinite(latPeaksIn[i]) && std::isfinite(lonPeaksIn[i])) {
            latPeaks.push_back(latPeaksIn[i]);
            lonPeaks.push_back(lonPeaksIn[i]);
        }
    }

    const TesseroidPeakPattern pattern = Tesseroid_PeakPattern(componentName);
    auto minmax = [](const std::vector<double>& v) { return std::minmax_element(v.begin(), v.end()); };

    switch (pattern) {
    case TesseroidPeakPattern::CenterOne:
        latCuts.push_back(fai);
        lonCuts.push_back(lamda);
        break;

    case TesseroidPeakPattern::XTwo:
    case TesseroidPeakPattern::XThree:
    case TesseroidPeakPattern::XFour:
        if (!latPeaks.empty()) {
            latCuts = latPeaks;
            lonCuts.push_back(lamda);
        }
        break;

    case TesseroidPeakPattern::YTwo:
    case TesseroidPeakPattern::YThree:
    case TesseroidPeakPattern::YFour:
        if (!lonPeaks.empty()) {
            latCuts.push_back(fai);
            lonCuts = lonPeaks;
        }
        break;

    case TesseroidPeakPattern::DiagonalFour:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(*lonMM.second);
        } else if (latPeaks.size() == 1 && lonPeaks.size() == 1) {
            latCuts.push_back(latPeaks.front());
            lonCuts.push_back(lonPeaks.front());
        }
        break;

    case TesseroidPeakPattern::XXYSix:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(fai);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(*lonMM.second);
        } else if (!lonPeaks.empty()) {
            latCuts.push_back(fai);
            lonCuts = lonPeaks;
        }
        break;

    case TesseroidPeakPattern::YYXSix:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(lamda);
            lonCuts.push_back(*lonMM.second);
        } else if (!latPeaks.empty()) {
            latCuts = latPeaks;
            lonCuts.push_back(lamda);
        }
        break;
    }

    latCuts = Tesseroid_UniqueFinite(latCuts);
    lonCuts = Tesseroid_UniqueFinite(lonCuts);
}

inline double Tesseroid_GroupPeakIntegral(const TesseroidKernelFunction& fun, const std::string& componentName,
                                          double Fai1, double Fai2, double Lamda1, double Lamda2, double AbsTol,
                                          double RelTol, double fai, double lamda, double r, double R1, double R2) {
    if (!(Fai2 > Fai1 && Lamda2 > Lamda1)) {
        return 0.0;
    }

    if (std::abs(fai) == 90.0) {
        return integral2t(fun, Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol);
    }

    const double dFaiBase = std::abs(Fai2 - Fai1);
    const double dLonBase = std::abs(Lamda2 - Lamda1);

    std::vector<double> latPeaks;
    std::vector<double> lonPeaks;
    const TesseroidPeakFunction peakFun = [&](double lat, double lon) {
        return Tesseroid_IntegralkernelScalar(componentName, R2, R1, lat, lon, r, fai, lamda);
    };
    Tesseroid_FindAllKernelPeaks(peakFun, componentName, fai, lamda, dFaiBase, dLonBase, r, R1, R2, latPeaks, lonPeaks);

    std::vector<double> latCuts;
    std::vector<double> lonCuts;
    Tesseroid_PeakGroupBreakCandidates(componentName, latPeaks, lonPeaks, fai, lamda, latCuts, lonCuts);

    std::vector<double> latBreaks = {Fai1, Fai2};
    std::vector<double> lonBreaks = {Lamda1, Lamda2};

    const double edgeTolLat = std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(Fai2 - Fai1))));
    const double edgeTolLon = std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(Lamda2 - Lamda1))));

    std::vector<double> latCandidates = latCuts;
    latCandidates.insert(latCandidates.end(), latPeaks.begin(), latPeaks.end());
    std::vector<double> lonCandidates = lonCuts;
    lonCandidates.insert(lonCandidates.end(), lonPeaks.begin(), lonPeaks.end());

    Tesseroid_AddBreaksWithEdgeSnap(latBreaks, latCandidates, Fai1, Fai2, edgeTolLat);
    Tesseroid_AddBreaksWithEdgeSnap(lonBreaks, lonCandidates, Lamda1, Lamda2, edgeTolLon);

    latBreaks = Tesseroid_CleanBreaks(latBreaks, Fai1, Fai2);
    lonBreaks = Tesseroid_CleanBreaks(lonBreaks, Lamda1, Lamda2);

    if (latBreaks.size() == 2 && lonBreaks.size() == 2) {
        return integral2t(fun, Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol);
    }

    const std::size_t nSubMax = (latBreaks.size() - 1) * (lonBreaks.size() - 1);
    const double ATloc = AbsTol / std::max<std::size_t>(nSubMax, 1);
    const double RTloc = RelTol;

    std::vector<double> subQ;
    subQ.reserve(nSubMax);

    for (std::size_t i = 0; i + 1 < latBreaks.size(); ++i) {
        const double a = latBreaks[i];
        const double b = latBreaks[i + 1];
        if (!(b > a)) {
            continue;
        }

        for (std::size_t j = 0; j + 1 < lonBreaks.size(); ++j) {
            const double c = lonBreaks[j];
            const double d = lonBreaks[j + 1];
            if (!(d > c)) {
                continue;
            }

            subQ.push_back(integral2t(fun, a, b, c, d, ATloc, RTloc));
        }
    }

    return Tesseroid_KahanSum(subQ);
}

inline void Tesseroid_GravityPointEstimate(double Fai1, double Fai2, double Lamda1, double Lamda2, double R1, double R2,
                                           double fai, double lamda, double r, double AbsTol, double RelTol, double* V,
                                           double* Vx, double* Vy, double* Vz, double* Vxx, double* Vxy, double* Vyy,
                                           double* Vzx, double* Vzy, double* Vzz, double* Vxxx, double* Vxxy,
                                           double* Vxxz, double* Vxyz, double* Vyyx, double* Vyyy, double* Vyyz,
                                           double* Vzzx, double* Vzzy, double* Vzzz, bool computePotential = true) {
    int i;

    double pi, RadianCorrection;
    double VSphericalShell, VxSphericalShell, VySphericalShell, VzSphericalShell, VxxSphericalShell, VxySphericalShell,
        VyySphericalShell, VzxSphericalShell, VzySphericalShell, VzzSphericalShell, VxxxSphericalShell,
        VxxySphericalShell, VxxzSphericalShell, VxyzSphericalShell, VyyxSphericalShell, VyyySphericalShell,
        VyyzSphericalShell, VzzxSphericalShell, VzzySphericalShell, VzzzSphericalShell;
    double VSplit, VxSplit, VySplit, VzSplit, VxxSplit, VxySplit, VyySplit, VzxSplit, VzySplit, VzzSplit, VxxxSplit,
        VxxySplit, VxxzSplit, VxyzSplit, VyyxSplit, VyyySplit, VyyzSplit, VzzxSplit, VzzySplit, VzzzSplit;

    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_V;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vx, func_Vy, func_Vz;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vxx, func_Vxy, func_Vyy, func_Vzx, func_Vzy, func_Vzz;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vxxx, func_Vxxy, func_Vxxz, func_Vxyz, func_Vyyx, func_Vyyy, func_Vyyz, func_Vzzx, func_Vzzy, func_Vzzz;

    pi = 4.0 * atan(1.0);
    RadianCorrection = (2.0 * pi * pi) / (180.0 * 360.0);

    if (lamda < -180.0) {
        lamda = 360.0 + lamda;
    } else if (lamda > 180.0) {
        lamda = -360.0 + lamda;
    }

    func_V = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelV(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVyy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxxx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxxy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxxz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxxz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vxyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVxyz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vyyx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVyyx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vyyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVyyy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vyyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVyyz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzzx(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzzy(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };
    func_Vzzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_IntegralkernelVzzz(R2, R1, FaiI, LamdaI, r, fai, lamda);
    };

    if (abs(fai) == 90.0) {

        *V = computePotential ? Tesseroid_GroupPeakIntegral(func_V, "V", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol,
                                                            fai, lamda, r, R1, R2)
                              : 0.0;
        *Vx = Tesseroid_GroupPeakIntegral(func_Vx, "Vx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1,
                                          R2);
        *Vy = Tesseroid_GroupPeakIntegral(func_Vy, "Vy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1,
                                          R2);
        *Vz = Tesseroid_GroupPeakIntegral(func_Vz, "Vz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1,
                                          R2);
        *Vxx = Tesseroid_GroupPeakIntegral(func_Vxx, "Vxx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vxy = Tesseroid_GroupPeakIntegral(func_Vxy, "Vxy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vyy = Tesseroid_GroupPeakIntegral(func_Vyy, "Vyy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vzx = Tesseroid_GroupPeakIntegral(func_Vzx, "Vzx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vzy = Tesseroid_GroupPeakIntegral(func_Vzy, "Vzy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vzz = Tesseroid_GroupPeakIntegral(func_Vzz, "Vzz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                           R1, R2);
        *Vxxx = Tesseroid_GroupPeakIntegral(func_Vxxx, "Vxxx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vxxy = Tesseroid_GroupPeakIntegral(func_Vxxy, "Vxxy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vxxz = Tesseroid_GroupPeakIntegral(func_Vxxz, "Vxxz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vxyz = Tesseroid_GroupPeakIntegral(func_Vxyz, "Vxyz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vyyx = Tesseroid_GroupPeakIntegral(func_Vyyx, "Vyyx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vyyy = Tesseroid_GroupPeakIntegral(func_Vyyy, "Vyyy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vyyz = Tesseroid_GroupPeakIntegral(func_Vyyz, "Vyyz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vzzx = Tesseroid_GroupPeakIntegral(func_Vzzx, "Vzzx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vzzy = Tesseroid_GroupPeakIntegral(func_Vzzy, "Vzzy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);
        *Vzzz = Tesseroid_GroupPeakIntegral(func_Vzzz, "Vzzz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda,
                                            r, R1, R2);

        return;
    }

    if ((fai > Fai1) && (fai < Fai2) && (lamda > Lamda1) && (lamda < Lamda2)) {

        std::vector<std::array<double, 4>> subTesseroids;

        subTesseroids = splitTesseroid(-90.0, 90.0, -180.0, 180.0, (Fai1 + Fai2) / 2.0, (Lamda1 + Lamda2) / 2.0,
                                       Fai2 - Fai1, Lamda2 - Lamda1);

        int NumDensityModel = subTesseroids.size();

        if (r >= R2) {
            const double radialVolume = (R2 - R1) * (R2 * R2 + R2 * R1 + R1 * R1);
            double M0 = 4.0 * pi / 3.0 * radialVolume;
            VSphericalShell = M0 / r;
            VzSphericalShell = -M0 / (r * r);
            VxxSphericalShell = -M0 / (r * r * r);
            VyySphericalShell = -M0 / (r * r * r);
            VzzSphericalShell = 2 * M0 / (r * r * r);
            VxxzSphericalShell = 3 * M0 / (r * r * r * r);
            VyyzSphericalShell = 3 * M0 / (r * r * r * r);
            VzzzSphericalShell = -6 * M0 / (r * r * r * r);
        } else if (r <= R1) {
            VSphericalShell = 2 * pi * (R2 - R1) * (R2 + R1);
            VzSphericalShell = 0;
            VxxSphericalShell = 0;
            VyySphericalShell = 0;
            VzzSphericalShell = 0;
            VxxzSphericalShell = 0;
            VyyzSphericalShell = 0;
            VzzzSphericalShell = 0;
        } else {
            const double h = r - R1;
            const double radialDifference = h * (r * r + r * R1 + R1 * R1);
            VSphericalShell = 2 * pi * ((R2 - R1) * (R2 + R1) - h * h * (r + 2 * R1) / (3.0 * r));
            VzSphericalShell = -4 * pi / 3.0 * radialDifference / (r * r);
            VxxSphericalShell = -4 * pi / 3.0 * radialDifference / (r * r * r);
            VyySphericalShell = VxxSphericalShell;
            VzzSphericalShell = -4 * pi / 3.0 * (1 + 2 * pow(R1, 3) / (r * r * r));
            VxxzSphericalShell = -4 * pi * pow(R1, 3) / (r * r * r * r);
            VyyzSphericalShell = VxxzSphericalShell;
            VzzzSphericalShell = 8 * pi * pow(R1, 3) / (r * r * r * r);
        }

        VxSphericalShell = 0;
        VySphericalShell = 0;

        VxySphericalShell = 0;
        VzxSphericalShell = 0;
        VzySphericalShell = 0;

        VxxxSphericalShell = 0;
        VxxySphericalShell = 0;
        VxyzSphericalShell = 0;
        VyyxSphericalShell = 0;
        VyyySphericalShell = 0;
        VzzxSphericalShell = 0;
        VzzySphericalShell = 0;

        VSphericalShell /= (r * r * RadianCorrection);
        VzSphericalShell /= (r * RadianCorrection);
        VxxSphericalShell /= RadianCorrection;
        VyySphericalShell /= RadianCorrection;
        VzzSphericalShell /= RadianCorrection;
        VxxzSphericalShell *= (r / RadianCorrection);
        VyyzSphericalShell *= (r / RadianCorrection);
        VzzzSphericalShell *= (r / RadianCorrection);

        VSplit = 0;

        VxSplit = 0;
        VySplit = 0;
        VzSplit = 0;

        VxxSplit = 0;
        VxySplit = 0;
        VyySplit = 0;
        VzxSplit = 0;
        VzySplit = 0;
        VzzSplit = 0;

        VxxxSplit = 0;
        VxxySplit = 0;
        VxxzSplit = 0;
        VxyzSplit = 0;
        VyyxSplit = 0;
        VyyySplit = 0;
        VyyzSplit = 0;
        VzzxSplit = 0;
        VzzySplit = 0;
        VzzzSplit = 0;

        for (i = 0; i < NumDensityModel; i++) {

            if (computePotential) {
                VSplit = VSplit + Tesseroid_GroupPeakIntegral(func_V, "V", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            }

            VxSplit = VxSplit + Tesseroid_GroupPeakIntegral(func_Vx, "Vx", subTesseroids[i][0], subTesseroids[i][1],
                                                            subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                            fai, lamda, r, R1, R2);
            VySplit = VySplit + Tesseroid_GroupPeakIntegral(func_Vy, "Vy", subTesseroids[i][0], subTesseroids[i][1],
                                                            subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                            fai, lamda, r, R1, R2);
            VzSplit = VzSplit + Tesseroid_GroupPeakIntegral(func_Vz, "Vz", subTesseroids[i][0], subTesseroids[i][1],
                                                            subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                            fai, lamda, r, R1, R2);

            VxxSplit = VxxSplit + Tesseroid_GroupPeakIntegral(func_Vxx, "Vxx", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            VxySplit = VxySplit + Tesseroid_GroupPeakIntegral(func_Vxy, "Vxy", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            VyySplit = VyySplit + Tesseroid_GroupPeakIntegral(func_Vyy, "Vyy", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            VzxSplit = VzxSplit + Tesseroid_GroupPeakIntegral(func_Vzx, "Vzx", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            VzySplit = VzySplit + Tesseroid_GroupPeakIntegral(func_Vzy, "Vzy", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);
            VzzSplit = VzzSplit + Tesseroid_GroupPeakIntegral(func_Vzz, "Vzz", subTesseroids[i][0], subTesseroids[i][1],
                                                              subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol,
                                                              fai, lamda, r, R1, R2);

            VxxxSplit =
                VxxxSplit + Tesseroid_GroupPeakIntegral(func_Vxxx, "Vxxx", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VxxySplit =
                VxxySplit + Tesseroid_GroupPeakIntegral(func_Vxxy, "Vxxy", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VxxzSplit =
                VxxzSplit + Tesseroid_GroupPeakIntegral(func_Vxxz, "Vxxz", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VxyzSplit =
                VxyzSplit + Tesseroid_GroupPeakIntegral(func_Vxyz, "Vxyz", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VyyxSplit =
                VyyxSplit + Tesseroid_GroupPeakIntegral(func_Vyyx, "Vyyx", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VyyySplit =
                VyyySplit + Tesseroid_GroupPeakIntegral(func_Vyyy, "Vyyy", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VyyzSplit =
                VyyzSplit + Tesseroid_GroupPeakIntegral(func_Vyyz, "Vyyz", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VzzxSplit =
                VzzxSplit + Tesseroid_GroupPeakIntegral(func_Vzzx, "Vzzx", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VzzySplit =
                VzzySplit + Tesseroid_GroupPeakIntegral(func_Vzzy, "Vzzy", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
            VzzzSplit =
                VzzzSplit + Tesseroid_GroupPeakIntegral(func_Vzzz, "Vzzz", subTesseroids[i][0], subTesseroids[i][1],
                                                        subTesseroids[i][2], subTesseroids[i][3], AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2);
        }

        *V = computePotential ? VSphericalShell - VSplit : 0.0;

        *Vx = VxSphericalShell - VxSplit;
        *Vy = VySphericalShell - VySplit;
        *Vz = VzSphericalShell - VzSplit;

        *Vxx = VxxSphericalShell - VxxSplit;
        *Vxy = VxySphericalShell - VxySplit;
        *Vyy = VyySphericalShell - VyySplit;
        *Vzx = VzxSphericalShell - VzxSplit;
        *Vzy = VzySphericalShell - VzySplit;
        *Vzz = VzzSphericalShell - VzzSplit;

        *Vxxx = VxxxSphericalShell - VxxxSplit;
        *Vxxy = VxxySphericalShell - VxxySplit;
        *Vxxz = VxxzSphericalShell - VxxzSplit;
        *Vxyz = VxyzSphericalShell - VxyzSplit;
        *Vyyx = VyyxSphericalShell - VyyxSplit;
        *Vyyy = VyyySphericalShell - VyyySplit;
        *Vyyz = VyyzSphericalShell - VyyzSplit;
        *Vzzx = VzzxSphericalShell - VzzxSplit;
        *Vzzy = VzzySphericalShell - VzzySplit;
        *Vzzz = VzzzSphericalShell - VzzzSplit;

        return;
    }

    *V = computePotential ? Tesseroid_GroupPeakIntegral(func_V, "V", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai,
                                                        lamda, r, R1, R2)
                          : 0.0;
    *Vx = Tesseroid_GroupPeakIntegral(func_Vx, "Vx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vy = Tesseroid_GroupPeakIntegral(func_Vy, "Vy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vz = Tesseroid_GroupPeakIntegral(func_Vz, "Vz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vxx =
        Tesseroid_GroupPeakIntegral(func_Vxx, "Vxx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vxy =
        Tesseroid_GroupPeakIntegral(func_Vxy, "Vxy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vyy =
        Tesseroid_GroupPeakIntegral(func_Vyy, "Vyy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vzx =
        Tesseroid_GroupPeakIntegral(func_Vzx, "Vzx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vzy =
        Tesseroid_GroupPeakIntegral(func_Vzy, "Vzy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vzz =
        Tesseroid_GroupPeakIntegral(func_Vzz, "Vzz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r, R1, R2);
    *Vxxx = Tesseroid_GroupPeakIntegral(func_Vxxx, "Vxxx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vxxy = Tesseroid_GroupPeakIntegral(func_Vxxy, "Vxxy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vxxz = Tesseroid_GroupPeakIntegral(func_Vxxz, "Vxxz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vxyz = Tesseroid_GroupPeakIntegral(func_Vxyz, "Vxyz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vyyx = Tesseroid_GroupPeakIntegral(func_Vyyx, "Vyyx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vyyy = Tesseroid_GroupPeakIntegral(func_Vyyy, "Vyyy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vyyz = Tesseroid_GroupPeakIntegral(func_Vyyz, "Vyyz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vzzx = Tesseroid_GroupPeakIntegral(func_Vzzx, "Vzzx", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vzzy = Tesseroid_GroupPeakIntegral(func_Vzzy, "Vzzy", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);
    *Vzzz = Tesseroid_GroupPeakIntegral(func_Vzzz, "Vzzz", Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol, fai, lamda, r,
                                        R1, R2);

    return;
}

inline void Tesseroid_GravityEstimate(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1, double* Lamda2,
                                      double* R1, double* R2, double* rho, int NumPoint, double* Latitude,
                                      double* Longitude, double* Radius, double AbsTol, double RelTol, double* V,
                                      double* Vx, double* Vy, double* Vz, double* Vxx, double* Vxy, double* Vyy,
                                      double* Vzx, double* Vzy, double* Vzz, double* Vxxx, double* Vxxy, double* Vxxz,
                                      double* Vxyz, double* Vyyx, double* Vyyy, double* Vyyz, double* Vzzx,
                                      double* Vzzy, double* Vzzz) {
    int i, j;
    double pi, RadianCorrection;
    double Reportbar;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;

    time_t start, end;

    printf("\nEstimating 0-, 1-, 2- and 3- gradient tensor components of the tesseroid(s)  \n");
    printf("Serial computing mode \n\n");

    printf("\n%i tesseroid(s) included.\n", NumTesseroid);
    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    Reportbar = 0.05;

    time(&start);

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");
    for (i = 0; i < NumPoint; i++) {
        for (j = 0; j < NumTesseroid; j++) {

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp);

            V[i] = V[i] + VTemp * rho[j];

            Vx[i] = Vx[i] + VxTemp * rho[j];
            Vy[i] = Vy[i] + VyTemp * rho[j];
            Vz[i] = Vz[i] + VzTemp * rho[j];

            Vxx[i] = Vxx[i] + VxxTemp * rho[j];
            Vxy[i] = Vxy[i] + VxyTemp * rho[j];
            Vyy[i] = Vyy[i] + VyyTemp * rho[j];
            Vzx[i] = Vzx[i] + VzxTemp * rho[j];
            Vzy[i] = Vzy[i] + VzyTemp * rho[j];
            Vzz[i] = Vzz[i] + VzzTemp * rho[j];

            Vxxx[i] = Vxxx[i] + VxxxTemp * rho[j];
            Vxxy[i] = Vxxy[i] + VxxyTemp * rho[j];
            Vxxz[i] = Vxxz[i] + VxxzTemp * rho[j];
            Vxyz[i] = Vxyz[i] + VxyzTemp * rho[j];
            Vyyx[i] = Vyyx[i] + VyyxTemp * rho[j];
            Vyyy[i] = Vyyy[i] + VyyyTemp * rho[j];
            Vyyz[i] = Vyyz[i] + VyyzTemp * rho[j];
            Vzzx[i] = Vzzx[i] + VzzxTemp * rho[j];
            Vzzy[i] = Vzzy[i] + VzzyTemp * rho[j];
            Vzzz[i] = Vzzz[i] + VzzzTemp * rho[j];
        }

        if ((double)i / (double)NumPoint >= Reportbar) {
            printf("|");
            Reportbar = Reportbar + 0.05;
        }
    }

    printf("|");

    time(&end);

    printf("\nTime for calculation: %.15lf seconds\n\n", difftime(end, start));

    for (i = 0; i < NumPoint; i++) {

        V[i] = V[i] * Radius[i] * Radius[i] * RadianCorrection;

        Vx[i] = Vx[i] * Radius[i] * RadianCorrection;
        Vy[i] = Vy[i] * Radius[i] * RadianCorrection;
        Vz[i] = Vz[i] * Radius[i] * RadianCorrection;

        Vxx[i] = Vxx[i] * RadianCorrection;
        Vxy[i] = Vxy[i] * RadianCorrection;
        Vyy[i] = Vyy[i] * RadianCorrection;
        Vzx[i] = Vzx[i] * RadianCorrection;
        Vzy[i] = Vzy[i] * RadianCorrection;
        Vzz[i] = Vzz[i] * RadianCorrection;

        Vxxx[i] = Vxxx[i] / Radius[i] * RadianCorrection;
        Vxxy[i] = Vxxy[i] / Radius[i] * RadianCorrection;
        Vxxz[i] = Vxxz[i] / Radius[i] * RadianCorrection;
        Vxyz[i] = Vxyz[i] / Radius[i] * RadianCorrection;
        Vyyx[i] = Vyyx[i] / Radius[i] * RadianCorrection;
        Vyyy[i] = Vyyy[i] / Radius[i] * RadianCorrection;
        Vyyz[i] = Vyyz[i] / Radius[i] * RadianCorrection;
        Vzzx[i] = Vzzx[i] / Radius[i] * RadianCorrection;
        Vzzy[i] = Vzzy[i] / Radius[i] * RadianCorrection;
        Vzzz[i] = Vzzz[i] / Radius[i] * RadianCorrection;
    }

    printf("\nCalculation finished: Tesseroid_GravityEstimate.\n\n");
}

inline void Tesseroid_MagneticEstimate(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1, double* Lamda2,
                                       double* R1, double* R2, double* Mx, double* My, double* Mz, int NumPoint,
                                       double* Latitude, double* Longitude, double* Radius, double AbsTol,
                                       double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                       double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz) {
    int i, j;
    double pi, RadianCorrection;
    double Reportbar;
    double Beita, cosBeita, sinBeita, cosDataLat, sinDataLat, cosLat, sinLat;
    double MxLocal, MyLocal, MzLocal;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;

    time_t start, end;

    printf("\nEstimating 0-, 1- and 2- gradient tensor components of the tesseroid(s)  \n");
    printf("Serial computing mode \n\n");

    printf("\n%i tesseroid(s) included.\n", NumTesseroid);
    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    Reportbar = 0.05;

    time(&start);

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");
    for (i = 0; i < NumPoint; i++) {
        for (j = 0; j < NumTesseroid; j++) {

            Beita = (Lamda2[j] + Lamda1[j]) / 2 - Longitude[i];
            cosBeita = cos(Beita / 180 * pi);
            sinBeita = sin(Beita / 180 * pi);
            cosDataLat = cos(Latitude[i] / 180 * pi);
            sinDataLat = sin(Latitude[i] / 180 * pi);
            cosLat = cos((Fai2[j] + Fai1[j]) / 2 / 180 * pi);
            sinLat = sin((Fai2[j] + Fai1[j]) / 2 / 180 * pi);

            MxLocal = (cosBeita * sinDataLat * sinLat + cosDataLat * cosLat) * Mx[j] + (sinBeita * sinDataLat) * My[j] -
                      (cosBeita * sinDataLat * cosLat - cosDataLat * sinLat) * Mz[j];
            MyLocal = (-sinBeita * sinLat) * Mx[j] + cosBeita * My[j] + sinBeita * cosLat * Mz[j];
            MzLocal = -(cosBeita * cosDataLat * sinLat - sinDataLat * cosLat) * Mx[j] -
                      (sinBeita * cosDataLat) * My[j] + (cosBeita * cosDataLat * cosLat + sinDataLat * sinLat) * Mz[j];

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp, false);

            V[i] = V[i] + MxLocal * VxTemp + MyLocal * VyTemp + MzLocal * VzTemp;

            Vx[i] = Vx[i] + MxLocal * VxxTemp + MyLocal * VxyTemp + MzLocal * VzxTemp;
            Vy[i] = Vy[i] + MxLocal * VxyTemp + MyLocal * VyyTemp + MzLocal * VzyTemp;
            Vz[i] = Vz[i] + MxLocal * VzxTemp + MyLocal * VzyTemp + MzLocal * VzzTemp;

            Vxx[i] = Vxx[i] + MxLocal * VxxxTemp + MyLocal * VxxyTemp + MzLocal * VxxzTemp;
            Vxy[i] = Vxy[i] + MxLocal * VxxyTemp + MyLocal * VyyxTemp + MzLocal * VxyzTemp;
            Vyy[i] = Vyy[i] + MxLocal * VyyxTemp + MyLocal * VyyyTemp + MzLocal * VyyzTemp;
            Vzx[i] = Vzx[i] + MxLocal * VxxzTemp + MyLocal * VxyzTemp + MzLocal * VzzxTemp;
            Vzy[i] = Vzy[i] + MxLocal * VxyzTemp + MyLocal * VyyzTemp + MzLocal * VzzyTemp;
            Vzz[i] = Vzz[i] + MxLocal * VzzxTemp + MyLocal * VzzyTemp + MzLocal * VzzzTemp;
        }

        if ((double)i / (double)NumPoint >= Reportbar) {
            printf("|");
            Reportbar = Reportbar + 0.05;
        }
    }

    printf("|");

    time(&end);

    printf("\nTime for calculation: %.15lf seconds\n\n", difftime(end, start));

    for (i = 0; i < NumPoint; i++) {

        V[i] = V[i] * Radius[i] * RadianCorrection;

        Vx[i] = Vx[i] * RadianCorrection;
        Vy[i] = Vy[i] * RadianCorrection;
        Vz[i] = Vz[i] * RadianCorrection;

        Vxx[i] = Vxx[i] / Radius[i] * RadianCorrection;
        Vxy[i] = Vxy[i] / Radius[i] * RadianCorrection;
        Vyy[i] = Vyy[i] / Radius[i] * RadianCorrection;
        Vzx[i] = Vzx[i] / Radius[i] * RadianCorrection;
        Vzy[i] = Vzy[i] / Radius[i] * RadianCorrection;
        Vzz[i] = Vzz[i] / Radius[i] * RadianCorrection;
    }

    printf("\nCalculation finished: Tesseroid_MagneticEstimate.\n\n");
}

inline void Tesseroid_GravityEstimateOpenMP(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1,
                                            double* Lamda2, double* R1, double* R2, double* rho, int NumPoint,
                                            double* Latitude, double* Longitude, double* Radius, double AbsTol,
                                            double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                            double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz,
                                            double* Vxxx, double* Vxxy, double* Vxxz, double* Vxyz, double* Vyyx,
                                            double* Vyyy, double* Vyyz, double* Vzzx, double* Vzzy, double* Vzzz) {
    int i, j;
    double pi, RadianCorrection;
    double Reportbar;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;

    time_t start, end;

    printf("\nEstimating 0-, 1-, 2- and 3- gradient tensor components of the tesseroid(s)  \n");
    printf("OpenMP parallel computing mode \n\n");

    printf("\n%i tesseroid(s) included.\n", NumTesseroid);
    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    Reportbar = 0.1;

    time(&start);

#pragma omp parallel for default(shared) private(                                                                      \
        i, j, VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp, \
            VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp)
    for (i = 0; i < NumPoint; i++) {
        for (j = 0; j < NumTesseroid; j++) {

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp);
#pragma omp atomic
            V[i] += VTemp * rho[j];
#pragma omp atomic
            Vx[i] += VxTemp * rho[j];
#pragma omp atomic
            Vy[i] += VyTemp * rho[j];
#pragma omp atomic
            Vz[i] += VzTemp * rho[j];

#pragma omp atomic
            Vxx[i] += VxxTemp * rho[j];
#pragma omp atomic
            Vxy[i] += VxyTemp * rho[j];
#pragma omp atomic
            Vyy[i] += VyyTemp * rho[j];
#pragma omp atomic
            Vzx[i] += VzxTemp * rho[j];
#pragma omp atomic
            Vzy[i] += VzyTemp * rho[j];
#pragma omp atomic
            Vzz[i] += VzzTemp * rho[j];

#pragma omp atomic
            Vxxx[i] += VxxxTemp * rho[j];
#pragma omp atomic
            Vxxy[i] += VxxyTemp * rho[j];
#pragma omp atomic
            Vxxz[i] += VxxzTemp * rho[j];
#pragma omp atomic
            Vxyz[i] += VxyzTemp * rho[j];
#pragma omp atomic
            Vyyx[i] += VyyxTemp * rho[j];
#pragma omp atomic
            Vyyy[i] += VyyyTemp * rho[j];
#pragma omp atomic
            Vyyz[i] += VyyzTemp * rho[j];
#pragma omp atomic
            Vzzx[i] += VzzxTemp * rho[j];
#pragma omp atomic
            Vzzy[i] += VzzyTemp * rho[j];
#pragma omp atomic
            Vzzz[i] += VzzzTemp * rho[j];
        }
    }

    time(&end);

    printf("\nTime for calculation: %.15lf seconds\n\n", difftime(end, start));
#pragma omp parallel for default(shared) private(i)
    for (i = 0; i < NumPoint; i++) {

        V[i] = V[i] * Radius[i] * Radius[i] * RadianCorrection;

        Vx[i] = Vx[i] * Radius[i] * RadianCorrection;
        Vy[i] = Vy[i] * Radius[i] * RadianCorrection;
        Vz[i] = Vz[i] * Radius[i] * RadianCorrection;

        Vxx[i] = Vxx[i] * RadianCorrection;
        Vxy[i] = Vxy[i] * RadianCorrection;
        Vyy[i] = Vyy[i] * RadianCorrection;
        Vzx[i] = Vzx[i] * RadianCorrection;
        Vzy[i] = Vzy[i] * RadianCorrection;
        Vzz[i] = Vzz[i] * RadianCorrection;

        Vxxx[i] = Vxxx[i] / Radius[i] * RadianCorrection;
        Vxxy[i] = Vxxy[i] / Radius[i] * RadianCorrection;
        Vxxz[i] = Vxxz[i] / Radius[i] * RadianCorrection;
        Vxyz[i] = Vxyz[i] / Radius[i] * RadianCorrection;
        Vyyx[i] = Vyyx[i] / Radius[i] * RadianCorrection;
        Vyyy[i] = Vyyy[i] / Radius[i] * RadianCorrection;
        Vyyz[i] = Vyyz[i] / Radius[i] * RadianCorrection;
        Vzzx[i] = Vzzx[i] / Radius[i] * RadianCorrection;
        Vzzy[i] = Vzzy[i] / Radius[i] * RadianCorrection;
        Vzzz[i] = Vzzz[i] / Radius[i] * RadianCorrection;
    }

    printf("\nCalculation finished: Tesseroid_GravityEstimateOpenMP.\n\n");
}

inline void Tesseroid_MagneticEstimateOpenMP(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1,
                                             double* Lamda2, double* R1, double* R2, double* Mx, double* My, double* Mz,
                                             int NumPoint, double* Latitude, double* Longitude, double* Radius,
                                             double AbsTol, double RelTol, double* V, double* Vx, double* Vy,
                                             double* Vz, double* Vxx, double* Vxy, double* Vyy, double* Vzx,
                                             double* Vzy, double* Vzz) {
    int i, j;
    double pi, RadianCorrection;
    double Reportbar;
    double Beita, cosBeita, sinBeita, cosDataLat, sinDataLat, cosLat, sinLat;
    double MxLocal, MyLocal, MzLocal;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;

    time_t start, end;

    printf("\nEstimating 0-, 1- and 2- gradient tensor components of the tesseroid(s)  \n");
    printf("OpenMP parallel computing mode \n\n");

    printf("\n%i tesseroid(s) included.\n", NumTesseroid);
    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    Reportbar = 0.1;

    time(&start);

#pragma omp parallel for default(shared) private(                                                                      \
        i, j, Beita, cosBeita, sinBeita, cosDataLat, sinDataLat, cosLat, sinLat, MxLocal, MyLocal, MzLocal, VTemp,     \
            VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,          \
            VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp)
    for (i = 0; i < NumPoint; i++) {
        for (j = 0; j < NumTesseroid; j++) {

            Beita = (Lamda2[j] + Lamda1[j]) / 2 - Longitude[i];
            cosBeita = cos(Beita / 180 * pi);
            sinBeita = sin(Beita / 180 * pi);
            cosDataLat = cos(Latitude[i] / 180 * pi);
            sinDataLat = sin(Latitude[i] / 180 * pi);
            cosLat = cos((Fai2[j] + Fai1[j]) / 2 / 180 * pi);
            sinLat = sin((Fai2[j] + Fai1[j]) / 2 / 180 * pi);

            MxLocal = (cosBeita * sinDataLat * sinLat + cosDataLat * cosLat) * Mx[j] + (sinBeita * sinDataLat) * My[j] -
                      (cosBeita * sinDataLat * cosLat - cosDataLat * sinLat) * Mz[j];
            MyLocal = (-sinBeita * sinLat) * Mx[j] + cosBeita * My[j] + sinBeita * cosLat * Mz[j];
            MzLocal = -(cosBeita * cosDataLat * sinLat - sinDataLat * cosLat) * Mx[j] -
                      (sinBeita * cosDataLat) * My[j] + (cosBeita * cosDataLat * cosLat + sinDataLat * sinLat) * Mz[j];

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp, false);

#pragma omp atomic
            V[i] += MxLocal * VxTemp + MyLocal * VyTemp + MzLocal * VzTemp;

#pragma omp atomic
            Vx[i] += MxLocal * VxxTemp + MyLocal * VxyTemp + MzLocal * VzxTemp;
#pragma omp atomic
            Vy[i] += MxLocal * VxyTemp + MyLocal * VyyTemp + MzLocal * VzyTemp;
#pragma omp atomic
            Vz[i] += MxLocal * VzxTemp + MyLocal * VzyTemp + MzLocal * VzzTemp;

#pragma omp atomic
            Vxx[i] += MxLocal * VxxxTemp + MyLocal * VxxyTemp + MzLocal * VxxzTemp;
#pragma omp atomic
            Vxy[i] += MxLocal * VxxyTemp + MyLocal * VyyxTemp + MzLocal * VxyzTemp;
#pragma omp atomic
            Vyy[i] += MxLocal * VyyxTemp + MyLocal * VyyyTemp + MzLocal * VyyzTemp;
#pragma omp atomic
            Vzx[i] += MxLocal * VxxzTemp + MyLocal * VxyzTemp + MzLocal * VzzxTemp;
#pragma omp atomic
            Vzy[i] += MxLocal * VxyzTemp + MyLocal * VyyzTemp + MzLocal * VzzyTemp;
#pragma omp atomic
            Vzz[i] += MxLocal * VzzxTemp + MyLocal * VzzyTemp + MzLocal * VzzzTemp;
        }
    }

    time(&end);

    printf("\nTime for calculation: %.15lf seconds\n\n", difftime(end, start));
#pragma omp parallel for default(shared) private(i)
    for (i = 0; i < NumPoint; i++) {

        V[i] = V[i] * Radius[i] * RadianCorrection;

        Vx[i] = Vx[i] * RadianCorrection;
        Vy[i] = Vy[i] * RadianCorrection;
        Vz[i] = Vz[i] * RadianCorrection;

        Vxx[i] = Vxx[i] / Radius[i] * RadianCorrection;
        Vxy[i] = Vxy[i] / Radius[i] * RadianCorrection;
        Vyy[i] = Vyy[i] / Radius[i] * RadianCorrection;
        Vzx[i] = Vzx[i] / Radius[i] * RadianCorrection;
        Vzy[i] = Vzy[i] / Radius[i] * RadianCorrection;
        Vzz[i] = Vzz[i] / Radius[i] * RadianCorrection;
    }

    printf("\nCalculation finished: Tesseroid_MagneticEstimateOpenMP.\n\n");
}

inline void Tesseroid_GravityEstimateMPI(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1, double* Lamda2,
                                         double* R1, double* R2, double* rho, int NumPoint, double* Latitude,
                                         double* Longitude, double* Radius, double AbsTol, double RelTol, double* V,
                                         double* Vx, double* Vy, double* Vz, double* Vxx, double* Vxy, double* Vyy,
                                         double* Vzx, double* Vzy, double* Vzz, double* Vxxx, double* Vxxy,
                                         double* Vxxz, double* Vxyz, double* Vyyx, double* Vyyy, double* Vyyz,
                                         double* Vzzx, double* Vzzy, double* Vzzz) {
    int i, j;
    int rank, nprocs;
    int Locals, Locale;
    int Position;

    int *DataList, *VectorShiftList;

    double pi, RadianCorrection;
    double t_Start, t_End;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;
    double *VLocal, *VxLocal, *VyLocal, *VzLocal, *VxxLocal, *VxyLocal, *VyyLocal, *VzxLocal, *VzyLocal, *VzzLocal,
        *VxxxLocal, *VxxyLocal, *VxxzLocal, *VxyzLocal, *VyyxLocal, *VyyyLocal, *VyyzLocal, *VzzxLocal, *VzzyLocal,
        *VzzzLocal;

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {

        printf("\nEstimating 0-, 1-, 2- and 3- gradient tensor components of the tesseroid(s)  \n");
        printf("MPI parallel computing mode \n");

        printf("\n%i tesseroid(s) included.\n", NumTesseroid);
        printf("%i coordinate(s) included.\n", NumPoint);
        printf("Absolute tolerance is set to: %e\n", AbsTol);
        printf("Relative tolerance is set to: %e\n\n", RelTol);
    }

    t_Start = MPI_Wtime();

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    DataList = (int*)malloc(sizeof(int) * nprocs);
    VectorShiftList = (int*)malloc(sizeof(int) * nprocs);

    MPIDistribute(NumPoint, DataList, VectorShiftList);

    MPI_Barrier(MPI_COMM_WORLD);

    Locals = VectorShiftList[rank];
    Locale = VectorShiftList[rank] + DataList[rank] - 1;

    VLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    VxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    VxxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VxyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzzLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    VxxxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VxxyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VxxzLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VxyzLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyyxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyyyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyyzLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzzxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzzyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzzzLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    MPI_Barrier(MPI_COMM_WORLD);

    for (i = Locals; i <= Locale; i++) {

        Position = i - VectorShiftList[rank];

        VLocal[Position] = VxLocal[Position] = VyLocal[Position] = VzLocal[Position] = VxxLocal[Position] =
            VxyLocal[Position] = VyyLocal[Position] = VzxLocal[Position] = VzyLocal[Position] = VzzLocal[Position] =
                VxxxLocal[Position] = VxxyLocal[Position] = VxxzLocal[Position] = VxyzLocal[Position] =
                    VyyxLocal[Position] = VyyyLocal[Position] = VyyzLocal[Position] = VzzxLocal[Position] =
                        VzzyLocal[Position] = VzzzLocal[Position] = 0;

        for (j = 0; j < NumTesseroid; j++) {

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp);

            VLocal[Position] += VTemp * rho[j];

            VxLocal[Position] += VxTemp * rho[j];
            VyLocal[Position] += VyTemp * rho[j];
            VzLocal[Position] += VzTemp * rho[j];

            VxxLocal[Position] += VxxTemp * rho[j];
            VxyLocal[Position] += VxyTemp * rho[j];
            VyyLocal[Position] += VyyTemp * rho[j];
            VzxLocal[Position] += VzxTemp * rho[j];
            VzyLocal[Position] += VzyTemp * rho[j];
            VzzLocal[Position] += VzzTemp * rho[j];

            VxxxLocal[Position] += VxxxTemp * rho[j];
            VxxyLocal[Position] += VxxyTemp * rho[j];
            VxxzLocal[Position] += VxxzTemp * rho[j];
            VxyzLocal[Position] += VxyzTemp * rho[j];
            VyyxLocal[Position] += VyyxTemp * rho[j];
            VyyyLocal[Position] += VyyyTemp * rho[j];
            VyyzLocal[Position] += VyyzTemp * rho[j];
            VzzxLocal[Position] += VzzxTemp * rho[j];
            VzzyLocal[Position] += VzzyTemp * rho[j];
            VzzzLocal[Position] += VzzzTemp * rho[j];
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);

    MPI_Gatherv(VLocal, DataList[rank], MPI_DOUBLE, V, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Gatherv(VxLocal, DataList[rank], MPI_DOUBLE, Vx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyLocal, DataList[rank], MPI_DOUBLE, Vy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzLocal, DataList[rank], MPI_DOUBLE, Vz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Gatherv(VxxLocal, DataList[rank], MPI_DOUBLE, Vxx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VxyLocal, DataList[rank], MPI_DOUBLE, Vxy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyLocal, DataList[rank], MPI_DOUBLE, Vyy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzxLocal, DataList[rank], MPI_DOUBLE, Vzx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzyLocal, DataList[rank], MPI_DOUBLE, Vzy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzLocal, DataList[rank], MPI_DOUBLE, Vzz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Gatherv(VxxxLocal, DataList[rank], MPI_DOUBLE, Vxxx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VxxyLocal, DataList[rank], MPI_DOUBLE, Vxxy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VxxzLocal, DataList[rank], MPI_DOUBLE, Vxxz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VxyzLocal, DataList[rank], MPI_DOUBLE, Vxyz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyxLocal, DataList[rank], MPI_DOUBLE, Vyyx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyyLocal, DataList[rank], MPI_DOUBLE, Vyyy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyzLocal, DataList[rank], MPI_DOUBLE, Vyyz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzxLocal, DataList[rank], MPI_DOUBLE, Vzzx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzyLocal, DataList[rank], MPI_DOUBLE, Vzzy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzzLocal, DataList[rank], MPI_DOUBLE, Vzzz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {

        for (i = 0; i < NumPoint; i++) {

            V[i] = V[i] * Radius[i] * Radius[i] * RadianCorrection;

            Vx[i] = Vx[i] * Radius[i] * RadianCorrection;
            Vy[i] = Vy[i] * Radius[i] * RadianCorrection;
            Vz[i] = Vz[i] * Radius[i] * RadianCorrection;

            Vxx[i] = Vxx[i] * RadianCorrection;
            Vxy[i] = Vxy[i] * RadianCorrection;
            Vyy[i] = Vyy[i] * RadianCorrection;
            Vzx[i] = Vzx[i] * RadianCorrection;
            Vzy[i] = Vzy[i] * RadianCorrection;
            Vzz[i] = Vzz[i] * RadianCorrection;

            Vxxx[i] = Vxxx[i] / Radius[i] * RadianCorrection;
            Vxxy[i] = Vxxy[i] / Radius[i] * RadianCorrection;
            Vxxz[i] = Vxxz[i] / Radius[i] * RadianCorrection;
            Vxyz[i] = Vxyz[i] / Radius[i] * RadianCorrection;
            Vyyx[i] = Vyyx[i] / Radius[i] * RadianCorrection;
            Vyyy[i] = Vyyy[i] / Radius[i] * RadianCorrection;
            Vyyz[i] = Vyyz[i] / Radius[i] * RadianCorrection;
            Vzzx[i] = Vzzx[i] / Radius[i] * RadianCorrection;
            Vzzy[i] = Vzzy[i] / Radius[i] * RadianCorrection;
            Vzzz[i] = Vzzz[i] / Radius[i] * RadianCorrection;
        }
    }

    t_End = MPI_Wtime();

    if (rank == 0) {
        printf("Computation Time (Units in Second) : %.2f", (t_End - t_Start));
        printf("\nCalculation finished: Tesseroid_GravityEstimateMPI.\n\n");
    }

    MPI_Barrier(MPI_COMM_WORLD);

    free(DataList);
    free(VectorShiftList);

    free(VLocal);
    free(VxLocal);
    free(VyLocal);
    free(VzLocal);
    free(VxxLocal);
    free(VxyLocal);
    free(VyyLocal);
    free(VzxLocal);
    free(VzyLocal);
    free(VzzLocal);
    free(VxxxLocal);
    free(VxxyLocal);
    free(VxxzLocal);
    free(VxyzLocal);
    free(VyyxLocal);
    free(VyyyLocal);
    free(VyyzLocal);
    free(VzzxLocal);
    free(VzzyLocal);
    free(VzzzLocal);
}

inline void Tesseroid_MagneticEstimateMPI(int NumTesseroid, double* Fai1, double* Fai2, double* Lamda1, double* Lamda2,
                                          double* R1, double* R2, double* Mx, double* My, double* Mz, int NumPoint,
                                          double* Latitude, double* Longitude, double* Radius, double AbsTol,
                                          double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                          double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz) {
    int i, j;
    int rank, nprocs;
    int Locals, Locale;
    int Position;

    int *DataList, *VectorShiftList;

    double pi, RadianCorrection;
    double t_Start, t_End;
    double Beita, cosBeita, sinBeita, cosDataLat, sinDataLat, cosLat, sinLat;
    double MxLocal, MyLocal, MzLocal;
    double VTemp, VxTemp, VyTemp, VzTemp, VxxTemp, VxyTemp, VyyTemp, VzxTemp, VzyTemp, VzzTemp, VxxxTemp, VxxyTemp,
        VxxzTemp, VxyzTemp, VyyxTemp, VyyyTemp, VyyzTemp, VzzxTemp, VzzyTemp, VzzzTemp;
    double *VLocal, *VxLocal, *VyLocal, *VzLocal, *VxxLocal, *VxyLocal, *VyyLocal, *VzxLocal, *VzyLocal, *VzzLocal;

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0) {

        printf("\nEstimating 0-, 1- and 2- gradient tensor components of the tesseroid(s)  \n");
        printf("MPI parallel computing mode \n");

        printf("\n%i tesseroid(s) included.\n", NumTesseroid);
        printf("%i coordinate(s) included.\n", NumPoint);
        printf("Absolute tolerance is set to: %e\n", AbsTol);
        printf("Relative tolerance is set to: %e\n\n", RelTol);
    }

    t_Start = MPI_Wtime();

    pi = 4 * atan(1);
    RadianCorrection = (2 * pi * pi) / (180 * 360);

    DataList = (int*)malloc(sizeof(int) * nprocs);
    VectorShiftList = (int*)malloc(sizeof(int) * nprocs);

    MPIDistribute(NumPoint, DataList, VectorShiftList);

    MPI_Barrier(MPI_COMM_WORLD);

    Locals = VectorShiftList[rank];
    Locale = VectorShiftList[rank] + DataList[rank] - 1;

    VLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    VxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    VxxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VxyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VyyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzxLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzyLocal = (double*)malloc(sizeof(double) * DataList[rank]);
    VzzLocal = (double*)malloc(sizeof(double) * DataList[rank]);

    MPI_Barrier(MPI_COMM_WORLD);

    for (i = Locals; i <= Locale; i++) {

        Position = i - VectorShiftList[rank];

        VLocal[Position] = VxLocal[Position] = VyLocal[Position] = VzLocal[Position] = VxxLocal[Position] =
            VxyLocal[Position] = VyyLocal[Position] = VzxLocal[Position] = VzyLocal[Position] = VzzLocal[Position] = 0;

        for (j = 0; j < NumTesseroid; j++) {

            Beita = (Lamda2[j] + Lamda1[j]) / 2 - Longitude[i];
            cosBeita = cos(Beita / 180 * pi);
            sinBeita = sin(Beita / 180 * pi);
            cosDataLat = cos(Latitude[i] / 180 * pi);
            sinDataLat = sin(Latitude[i] / 180 * pi);
            cosLat = cos((Fai2[j] + Fai1[j]) / 2 / 180 * pi);
            sinLat = sin((Fai2[j] + Fai1[j]) / 2 / 180 * pi);

            MxLocal = (cosBeita * sinDataLat * sinLat + cosDataLat * cosLat) * Mx[j] + (sinBeita * sinDataLat) * My[j] -
                      (cosBeita * sinDataLat * cosLat - cosDataLat * sinLat) * Mz[j];
            MyLocal = (-sinBeita * sinLat) * Mx[j] + cosBeita * My[j] + sinBeita * cosLat * Mz[j];
            MzLocal = -(cosBeita * cosDataLat * sinLat - sinDataLat * cosLat) * Mx[j] -
                      (sinBeita * cosDataLat) * My[j] + (cosBeita * cosDataLat * cosLat + sinDataLat * sinLat) * Mz[j];

            Tesseroid_GravityPointEstimate(Fai1[j], Fai2[j], Lamda1[j], Lamda2[j], R1[j], R2[j], Latitude[i],
                                           Longitude[i], Radius[i], AbsTol, RelTol, &VTemp, &VxTemp, &VyTemp, &VzTemp,
                                           &VxxTemp, &VxyTemp, &VyyTemp, &VzxTemp, &VzyTemp, &VzzTemp, &VxxxTemp,
                                           &VxxyTemp, &VxxzTemp, &VxyzTemp, &VyyxTemp, &VyyyTemp, &VyyzTemp, &VzzxTemp,
                                           &VzzyTemp, &VzzzTemp, false);

            VLocal[Position] += MxLocal * VxTemp + MyLocal * VyTemp + MzLocal * VzTemp;

            VxLocal[Position] += MxLocal * VxxTemp + MyLocal * VxyTemp + MzLocal * VzxTemp;
            VyLocal[Position] += MxLocal * VxyTemp + MyLocal * VyyTemp + MzLocal * VzyTemp;
            VzLocal[Position] += MxLocal * VzxTemp + MyLocal * VzyTemp + MzLocal * VzzTemp;

            VxxLocal[Position] += MxLocal * VxxxTemp + MyLocal * VxxyTemp + MzLocal * VxxzTemp;
            VxyLocal[Position] += MxLocal * VxxyTemp + MyLocal * VyyxTemp + MzLocal * VxyzTemp;
            VyyLocal[Position] += MxLocal * VyyxTemp + MyLocal * VyyyTemp + MzLocal * VyyzTemp;
            VzxLocal[Position] += MxLocal * VxxzTemp + MyLocal * VxyzTemp + MzLocal * VzzxTemp;
            VzyLocal[Position] += MxLocal * VxyzTemp + MyLocal * VyyzTemp + MzLocal * VzzyTemp;
            VzzLocal[Position] += MxLocal * VzzxTemp + MyLocal * VzzyTemp + MzLocal * VzzzTemp;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);

    MPI_Gatherv(VLocal, DataList[rank], MPI_DOUBLE, V, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Gatherv(VxLocal, DataList[rank], MPI_DOUBLE, Vx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyLocal, DataList[rank], MPI_DOUBLE, Vy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzLocal, DataList[rank], MPI_DOUBLE, Vz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Gatherv(VxxLocal, DataList[rank], MPI_DOUBLE, Vxx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VxyLocal, DataList[rank], MPI_DOUBLE, Vxy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyLocal, DataList[rank], MPI_DOUBLE, Vyy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzxLocal, DataList[rank], MPI_DOUBLE, Vzx, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzyLocal, DataList[rank], MPI_DOUBLE, Vzy, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzLocal, DataList[rank], MPI_DOUBLE, Vzz, DataList, VectorShiftList, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {

        for (i = 0; i < NumPoint; i++) {

            V[i] = V[i] * Radius[i] * RadianCorrection;

            Vx[i] = Vx[i] * RadianCorrection;
            Vy[i] = Vy[i] * RadianCorrection;
            Vz[i] = Vz[i] * RadianCorrection;

            Vxx[i] = Vxx[i] / Radius[i] * RadianCorrection;
            Vxy[i] = Vxy[i] / Radius[i] * RadianCorrection;
            Vyy[i] = Vyy[i] / Radius[i] * RadianCorrection;
            Vzx[i] = Vzx[i] / Radius[i] * RadianCorrection;
            Vzy[i] = Vzy[i] / Radius[i] * RadianCorrection;
            Vzz[i] = Vzz[i] / Radius[i] * RadianCorrection;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);

    t_End = MPI_Wtime();

    if (rank == 0) {
        printf("Computation Time (Units in Second) : %.2f", (t_End - t_Start));
        printf("\nCalculation finished: Tesseroid_MagneticEstimateMPI.\n\n");
    }

    free(DataList);
    free(VectorShiftList);

    free(VLocal);
    free(VxLocal);
    free(VyLocal);
    free(VzLocal);
    free(VxxLocal);
    free(VxyLocal);
    free(VyyLocal);
    free(VzxLocal);
    free(VzyLocal);
    free(VzzLocal);
}

}
