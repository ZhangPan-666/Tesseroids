% Create MSIM.ForPar for magnetization-shell integration.

clear; clc;
VIMModel=readmatrix('E:\OneDrive\学习\Tesseroid\Applications\Magnetic\7-VIMModel.dat');

outFile = 'MSIM.ForPar';
AbsTol  = 1e-16;
RelTol  = 1e-16;

Lons = -180.0;
Lone =  180.0;
Lats = -90.0;
Late =  90.0;
dLon =  0.25;
dLat =  0.25;

Lons=Lons+dLon/2;
Lone=Lone-dLon/2;
Lats=Lats+dLat/2;
Late=Late-dLat/2;

NumLon = round((Lone - Lons) / dLon) + 1;
NumLat = round((Late - Lats) / dLat) + 1;

R1 = reshape(VIMModel(:,5),NumLat,NumLon);
R2 = reshape(VIMModel(:,3),NumLat,NumLon);
Mx = reshape(VIMModel(:,7),NumLat,NumLon);
My = reshape(VIMModel(:,8),NumLat,NumLon);
Mz = reshape(VIMModel(:,9),NumLat,NumLon);

[Longitude,Latitude]=meshgrid(130:0.2:150,10:0.2:10);
Longitude=Longitude(:);
Latitude=Latitude(:);
Radius=(6371.2+15).*ones(size(Longitude));

assert(all(size(R1) == [NumLat, NumLon]), 'R1 must be NumLat-by-NumLon.');
assert(all(size(R2) == [NumLat, NumLon]), 'R2 must be NumLat-by-NumLon.');
assert(all(size(Mx) == [NumLat, NumLon]), 'Mx must be NumLat-by-NumLon.');
assert(all(size(My) == [NumLat, NumLon]), 'My must be NumLat-by-NumLon.');
assert(all(size(Mz) == [NumLat, NumLon]), 'Mz must be NumLat-by-NumLon.');

Longitude = Longitude(:);
Latitude  = Latitude(:);
Radius    = Radius(:);
NumCoordinates = numel(Longitude);
assert(numel(Latitude) == NumCoordinates && numel(Radius) == NumCoordinates, ...
    'Longitude, Latitude, Radius must have the same length.');

fid = fopen(outFile, 'w', 'ieee-le');
assert(fid ~= -1, 'Failed to open output file: %s', outFile);
cleaner = onCleanup(@() fclose(fid));

fwrite(fid, double(AbsTol), 'double');
fwrite(fid, double(RelTol), 'double');

fwrite(fid, double(Lons), 'double');
fwrite(fid, double(Lone), 'double');
fwrite(fid, double(Lats), 'double');
fwrite(fid, double(Late), 'double');
fwrite(fid, double(dLon), 'double');
fwrite(fid, double(dLat), 'double');

fwrite(fid, int32(NumLon), 'int32');
fwrite(fid, int32(NumLat), 'int32');

fwrite(fid, double(R2(:)), 'double');
fwrite(fid, double(R1(:)), 'double');
fwrite(fid, double(Mx(:)), 'double');
fwrite(fid, double(My(:)), 'double');
fwrite(fid, double(Mz(:)), 'double');

fwrite(fid, int32(NumCoordinates), 'int32');
fwrite(fid, double(Longitude), 'double');
fwrite(fid, double(Latitude),  'double');
fwrite(fid, double(Radius),    'double');

disp(['Magnetization-shell parameter file written: ', outFile]);
