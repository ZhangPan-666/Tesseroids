﻿// Run Work2 magnetization-shell integration for Vx, Vy, and Vz with MPI.
// The result file keeps the Work1 magnetic-result binary layout.

#include "_tesseroid_MSI.h"

#include <mpi.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>

namespace Work2MagVector {
using TesseroidMSIKernelFunction = Tesseroid::TesseroidMSIKernelFunction;
using TesseroidMSIPeakFunction = Tesseroid::TesseroidMSIPeakFunction;
using KernelFunction = TesseroidMSIKernelFunction;

enum class Work2MagPeakPattern { CenterOne, XTwo, YTwo, XThree, YThree, DiagonalFour };

class Work2MagTimer {
  public:
    void start() { start_ = Clock::now(); }
    double seconds() const { return std::chrono::duration<double>(Clock::now() - start_).count(); }

  private:
    using Clock = std::chrono::high_resolution_clock;
    std::chrono::time_point<Clock> start_;
};

inline void Work2MagDistribute(int count, std::vector<int>& counts, std::vector<int>& displacements) {
    int nprocs = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    counts.assign(nprocs, count / nprocs);
    for (int i = 0; i < count % nprocs; ++i)
        ++counts[i];
    displacements.assign(nprocs, 0);
    for (int i = 1; i < nprocs; ++i) {
        displacements[i] = displacements[i - 1] + counts[i - 1];
    }
}

inline double Work2MagNormalizeLongitude(double longitude) {
    longitude = std::fmod(longitude + 180.0, 360.0);
    if (longitude < 0.0)
        longitude += 360.0;
    return longitude - 180.0;
}

inline double Work2MagKahanSum(const std::vector<double>& values) {
    double sum = 0.0;
    double correction = 0.0;
    for (double value : values) {
        const double adjusted = value - correction;
        const double next = sum + adjusted;
        correction = (next - sum) - adjusted;
        sum = next;
    }
    return sum;
}

inline std::vector<double> Work2MagUniqueFinite(std::vector<double> values) {
    values.erase(std::remove_if(values.begin(), values.end(), [](double value) { return !std::isfinite(value); }),
                 values.end());
    std::sort(values.begin(), values.end());
    if (values.empty())
        return values;

    double scale = 1.0;
    for (double value : values)
        scale = std::max(scale, std::abs(value));
    const double tolerance = 1.0e-10 * scale;

    std::vector<double> unique{values.front()};
    for (std::size_t i = 1; i < values.size(); ++i) {
        if (std::abs(values[i] - unique.back()) > tolerance) {
            unique.push_back(values[i]);
        }
    }
    return unique;
}

inline std::vector<double> Work2MagCleanBreaks(std::vector<double> breaks, double lower, double upper) {
    for (double& value : breaks) {
        value = std::min(upper, std::max(lower, value));
    }
    breaks = Work2MagUniqueFinite(std::move(breaks));
    const double tolerance = std::max(1.0e-12, 1.0e-10 * std::max(1.0, std::abs(upper - lower)));
    if (breaks.empty())
        return {lower, upper};
    if (breaks.front() > lower + tolerance)
        breaks.insert(breaks.begin(), lower);
    else
        breaks.front() = lower;
    if (breaks.back() < upper - tolerance)
        breaks.push_back(upper);
    else
        breaks.back() = upper;
    return breaks;
}

inline Work2MagPeakPattern Work2MagPattern(const std::string& component) {
    if (component == "Vzx")
        return Work2MagPeakPattern::XTwo;
    if (component == "Vzy")
        return Work2MagPeakPattern::YTwo;
    if (component == "Vxx")
        return Work2MagPeakPattern::XThree;
    if (component == "Vyy")
        return Work2MagPeakPattern::YThree;
    if (component == "Vxy")
        return Work2MagPeakPattern::DiagonalFour;
    return Work2MagPeakPattern::CenterOne;
}

inline void Work2MagSearchWindow(double latitude, double baseLatitudeSpan, double baseLongitudeSpan, double radius,
                                 double innerRadius, double outerRadius, double& latitudeWindow,
                                 double& longitudeWindow) {
    const double pi = 4.0 * std::atan(1.0);
    const double cosineLatitude = std::max(std::abs(std::cos(latitude * pi / 180.0)), 1.0e-6);

    double height = 0.0;
    if (radius > outerRadius)
        height = radius - outerRadius;
    else if (radius < innerRadius)
        height = innerRadius - radius;
    else
        height = std::min(std::abs(radius - innerRadius), std::abs(outerRadius - radius));

    const double heightDegrees =
        std::atan2(std::max(height, 0.0), std::max(std::abs(radius), std::numeric_limits<double>::epsilon())) * 180.0 /
        pi;
    double basePhysicalSpan = std::max(std::abs(baseLatitudeSpan), std::abs(baseLongitudeSpan) * cosineLatitude);
    if (!(basePhysicalSpan > 0.0) || !std::isfinite(basePhysicalSpan)) {
        basePhysicalSpan = 0.1;
    }

    double physicalWindow = std::max(12.0 * heightDegrees, std::min(0.25 * basePhysicalSpan, 0.2));
    physicalWindow = std::max(physicalWindow, std::min(0.05, basePhysicalSpan));
    physicalWindow = std::min(physicalWindow, std::max(2.0 * basePhysicalSpan, 0.1));
    physicalWindow = std::max(physicalWindow, 1.0e-8);

    latitudeWindow = std::min(physicalWindow, 180.0);
    longitudeWindow = std::min(physicalWindow / cosineLatitude, 360.0);
}

inline double Work2MagGoldenMaximum(const std::function<double(double)>& function, double lower, double upper) {
    const double ratio = (std::sqrt(5.0) - 1.0) * 0.5;
    double left = upper - ratio * (upper - lower);
    double right = lower + ratio * (upper - lower);
    double leftValue = std::abs(function(left));
    double rightValue = std::abs(function(right));
    if (!std::isfinite(leftValue))
        leftValue = 0.0;
    if (!std::isfinite(rightValue))
        rightValue = 0.0;

    for (int iteration = 0; iteration < 80; ++iteration) {
        if (std::abs(upper - lower) <= 1.0e-12 * std::max(1.0, std::abs(lower) + std::abs(upper)))
            break;
        if (leftValue < rightValue) {
            lower = left;
            left = right;
            leftValue = rightValue;
            right = lower + ratio * (upper - lower);
            rightValue = std::abs(function(right));
            if (!std::isfinite(rightValue))
                rightValue = 0.0;
        } else {
            upper = right;
            right = left;
            rightValue = leftValue;
            left = upper - ratio * (upper - lower);
            leftValue = std::abs(function(left));
            if (!std::isfinite(leftValue))
                leftValue = 0.0;
        }
    }
    return 0.5 * (lower + upper);
}

inline std::vector<double> Work2MagFindPeaks1D(const std::function<double(double)>& function, double lower,
                                               double upper, int requestedPeakCount) {
    std::vector<double> peaks;
    if (requestedPeakCount <= 0 || !(upper > lower))
        return peaks;

    const int sampleCount = std::max(129, 65 * requestedPeakCount);
    const double pi = 4.0 * std::atan(1.0);
    std::vector<double> coordinates(sampleCount);
    std::vector<double> magnitudes(sampleCount);
    for (int i = 0; i < sampleCount; ++i) {
        const double t = 0.5 - 0.5 * std::cos(pi * static_cast<double>(i) / (sampleCount - 1));
        coordinates[i] = lower + (upper - lower) * t;
        magnitudes[i] = std::abs(function(coordinates[i]));
        if (!std::isfinite(magnitudes[i])) {
            magnitudes[i] = -std::numeric_limits<double>::infinity();
        }
    }

    std::vector<int> candidates;
    for (int i = 1; i + 1 < sampleCount; ++i) {
        if (magnitudes[i] >= magnitudes[i - 1] && magnitudes[i] >= magnitudes[i + 1])
            candidates.push_back(i);
    }
    if (candidates.empty()) {
        int best = 1;
        for (int i = 2; i + 1 < sampleCount; ++i) {
            if (magnitudes[i] > magnitudes[best])
                best = i;
        }
        candidates.push_back(best);
    }
    std::sort(candidates.begin(), candidates.end(),
              [&](int lhs, int rhs) { return magnitudes[lhs] > magnitudes[rhs]; });

    const double minimumSeparation = 0.01 * (upper - lower);
    for (int index : candidates) {
        const int first = std::max(0, index - 2);
        const int last = std::min(sampleCount - 1, index + 2);
        double peak = coordinates[index];
        if (coordinates[last] > coordinates[first]) {
            peak = Work2MagGoldenMaximum(function, coordinates[first], coordinates[last]);
        }
        bool separated = true;
        for (double existing : peaks) {
            if (std::abs(existing - peak) <= minimumSeparation) {
                separated = false;
                break;
            }
        }
        if (separated)
            peaks.push_back(peak);
        if (static_cast<int>(peaks.size()) >= requestedPeakCount)
            break;
    }
    return peaks;
}

inline void Work2MagFindMeridianPeaks(const TesseroidMSIPeakFunction& function, double latitude, double longitude,
                                      double latitudeWindow, int aboveCount, int belowCount,
                                      std::vector<double>& peakLatitudes, std::vector<double>& peakLongitudes) {
    const double epsilon = std::max(1.0e-10, 1.0e-8 * latitudeWindow);
    const double lower = std::max(-90.0, latitude - latitudeWindow);
    const double upper = std::min(90.0, latitude + latitudeWindow);
    auto line = [&](double sourceLatitude) { return function(sourceLatitude, longitude); };
    if (belowCount > 0 && latitude - epsilon > lower) {
        for (double peak : Work2MagFindPeaks1D(line, lower, latitude - epsilon, belowCount)) {
            peakLatitudes.push_back(peak);
            peakLongitudes.push_back(longitude);
        }
    }
    if (aboveCount > 0 && upper > latitude + epsilon) {
        for (double peak : Work2MagFindPeaks1D(line, latitude + epsilon, upper, aboveCount)) {
            peakLatitudes.push_back(peak);
            peakLongitudes.push_back(longitude);
        }
    }
}

inline void Work2MagFindParallelPeaks(const TesseroidMSIPeakFunction& function, double latitude, double longitude,
                                      double longitudeWindow, int rightCount, int leftCount,
                                      std::vector<double>& peakLatitudes, std::vector<double>& peakLongitudes) {
    const double epsilon = std::max(1.0e-10, 1.0e-8 * longitudeWindow);
    const double lower = std::max(-180.0, longitude - longitudeWindow);
    const double upper = std::min(180.0, longitude + longitudeWindow);
    auto line = [&](double sourceLongitude) { return function(latitude, sourceLongitude); };
    if (leftCount > 0 && longitude - epsilon > lower) {
        for (double peak : Work2MagFindPeaks1D(line, lower, longitude - epsilon, leftCount)) {
            peakLatitudes.push_back(latitude);
            peakLongitudes.push_back(peak);
        }
    }
    if (rightCount > 0 && upper > longitude + epsilon) {
        for (double peak : Work2MagFindPeaks1D(line, longitude + epsilon, upper, rightCount)) {
            peakLatitudes.push_back(latitude);
            peakLongitudes.push_back(peak);
        }
    }
}

inline void Work2MagFindDiagonalPeaks(const TesseroidMSIPeakFunction& function, double latitude, double longitude,
                                      double latitudeWindow, double longitudeWindow, std::vector<double>& peakLatitudes,
                                      std::vector<double>& peakLongitudes) {
    const double pi = 4.0 * std::atan(1.0);
    const double cosineLatitude = std::abs(std::cos(latitude * pi / 180.0));
    if (cosineLatitude < 1.0e-8)
        return;
    const double maximumDistance = std::min(latitudeWindow, longitudeWindow * cosineLatitude);
    if (!(maximumDistance > 0.0))
        return;

    const double epsilon = std::max(1.0e-10, 1.0e-8 * maximumDistance);
    const int signs[2] = {-1, 1};
    for (int latitudeSign : signs) {
        for (int longitudeSign : signs) {
            auto line = [&](double distance) {
                return function(latitude + latitudeSign * distance,
                                Work2MagNormalizeLongitude(longitude + longitudeSign * distance / cosineLatitude));
            };
            const auto peaks = Work2MagFindPeaks1D(line, epsilon, maximumDistance, 1);
            if (!peaks.empty()) {
                peakLatitudes.push_back(latitude + latitudeSign * peaks.front());
                peakLongitudes.push_back(
                    Work2MagNormalizeLongitude(longitude + longitudeSign * peaks.front() / cosineLatitude));
            }
        }
    }
}

inline void Work2MagFindKernelPeaks(const TesseroidMSIPeakFunction& peakFunction, const std::string& component,
                                    double latitude, double longitude, double baseLatitudeSpan,
                                    double baseLongitudeSpan, double radius, double innerRadius, double outerRadius,
                                    std::vector<double>& peakLatitudes, std::vector<double>& peakLongitudes) {
    peakLatitudes.clear();
    peakLongitudes.clear();
    double latitudeWindow = 0.0;
    double longitudeWindow = 0.0;
    Work2MagSearchWindow(latitude, baseLatitudeSpan, baseLongitudeSpan, radius, innerRadius, outerRadius,
                         latitudeWindow, longitudeWindow);

    switch (Work2MagPattern(component)) {
    case Work2MagPeakPattern::CenterOne:
        peakLatitudes.push_back(latitude);
        peakLongitudes.push_back(longitude);
        break;
    case Work2MagPeakPattern::XTwo:
        Work2MagFindMeridianPeaks(peakFunction, latitude, longitude, latitudeWindow, 1, 1, peakLatitudes,
                                  peakLongitudes);
        break;
    case Work2MagPeakPattern::YTwo:
        Work2MagFindParallelPeaks(peakFunction, latitude, longitude, longitudeWindow, 1, 1, peakLatitudes,
                                  peakLongitudes);
        break;
    case Work2MagPeakPattern::XThree:
        Work2MagFindMeridianPeaks(peakFunction, latitude, longitude, latitudeWindow, 1, 1, peakLatitudes,
                                  peakLongitudes);
        peakLatitudes.push_back(latitude);
        peakLongitudes.push_back(longitude);
        break;
    case Work2MagPeakPattern::YThree:
        Work2MagFindParallelPeaks(peakFunction, latitude, longitude, longitudeWindow, 1, 1, peakLatitudes,
                                  peakLongitudes);
        peakLatitudes.push_back(latitude);
        peakLongitudes.push_back(longitude);
        break;
    case Work2MagPeakPattern::DiagonalFour:
        Work2MagFindDiagonalPeaks(peakFunction, latitude, longitude, latitudeWindow, longitudeWindow, peakLatitudes,
                                  peakLongitudes);
        break;
    }

    std::vector<std::array<double, 2>> unique;
    for (std::size_t i = 0; i < peakLatitudes.size() && i < peakLongitudes.size(); ++i) {
        bool duplicate = false;
        for (const auto& existing : unique) {
            if (std::abs(existing[0] - peakLatitudes[i]) < 1.0e-8 &&
                std::abs(existing[1] - peakLongitudes[i]) < 1.0e-8) {
                duplicate = true;
                break;
            }
        }
        if (!duplicate && std::isfinite(peakLatitudes[i]) && std::isfinite(peakLongitudes[i])) {
            unique.push_back({peakLatitudes[i], peakLongitudes[i]});
        }
    }
    peakLatitudes.clear();
    peakLongitudes.clear();
    for (const auto& peak : unique) {
        peakLatitudes.push_back(peak[0]);
        peakLongitudes.push_back(peak[1]);
    }
}

inline double Work2MagGroupPeakIntegral(const KernelFunction& function, const TesseroidMSIPeakFunction& peakFunction,
                                        const std::string& component, double lat1, double lat2, double lon1,
                                        double lon2, double absoluteTolerance, double relativeTolerance,
                                        double observationLatitude, double observationLongitude, double radius,
                                        double innerRadius, double outerRadius) {
    if (!(lat2 > lat1 && lon2 > lon1))
        return 0.0;
    if (std::abs(observationLatitude) == 90.0) {
        return Tesseroid::integral2t(function, lat1, lat2, lon1, lon2, absoluteTolerance, relativeTolerance);
    }

    std::vector<double> peakLatitudes;
    std::vector<double> peakLongitudes;
    Work2MagFindKernelPeaks(peakFunction, component, observationLatitude, observationLongitude, std::abs(lat2 - lat1),
                            std::abs(lon2 - lon1), radius, innerRadius, outerRadius, peakLatitudes, peakLongitudes);

    std::vector<double> latitudeBreaks{lat1, lat2};
    std::vector<double> longitudeBreaks{lon1, lon2};
    const double edgeToleranceLatitude =
        std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(lat2 - lat1))));
    const double edgeToleranceLongitude =
        std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(lon2 - lon1))));

    for (double value : peakLatitudes) {
        if (std::abs(value - lat1) <= edgeToleranceLatitude)
            value = lat1;
        else if (std::abs(value - lat2) <= edgeToleranceLatitude)
            value = lat2;
        if (value > lat1 && value < lat2)
            latitudeBreaks.push_back(value);
    }
    for (double value : peakLongitudes) {
        if (std::abs(value - lon1) <= edgeToleranceLongitude)
            value = lon1;
        else if (std::abs(value - lon2) <= edgeToleranceLongitude)
            value = lon2;
        if (value > lon1 && value < lon2)
            longitudeBreaks.push_back(value);
    }

    latitudeBreaks = Work2MagCleanBreaks(std::move(latitudeBreaks), lat1, lat2);
    longitudeBreaks = Work2MagCleanBreaks(std::move(longitudeBreaks), lon1, lon2);

    const std::size_t subdomainCount = (latitudeBreaks.size() - 1) * (longitudeBreaks.size() - 1);
    const double localAbsoluteTolerance = absoluteTolerance / std::max<std::size_t>(subdomainCount, 1);
    std::vector<double> pieces;
    pieces.reserve(subdomainCount);
    for (std::size_t i = 0; i + 1 < latitudeBreaks.size(); ++i) {
        for (std::size_t j = 0; j + 1 < longitudeBreaks.size(); ++j) {
            pieces.push_back(Tesseroid::integral2t(function, latitudeBreaks[i], latitudeBreaks[i + 1],
                                                   longitudeBreaks[j], longitudeBreaks[j + 1], localAbsoluteTolerance,
                                                   relativeTolerance));
        }
    }
    return Work2MagKahanSum(pieces);
}

inline double Work2MagIntegrateOutsideHole(const KernelFunction& function, const TesseroidMSIPeakFunction& peakFunction,
                                           const std::string& component, double latA, double latB, double lonA,
                                           double lonB, double holeLat1, double holeLat2, double holeLon1,
                                           double holeLon2, double absoluteTolerance, double relativeTolerance,
                                           double observationLatitude, double observationLongitude, double radius,
                                           double innerRadius, double outerRadius) {
    auto integrate = [&](double lat1, double lat2, double lon1, double lon2) {
        return Work2MagGroupPeakIntegral(function, peakFunction, component, lat1, lat2, lon1, lon2, absoluteTolerance,
                                         relativeTolerance, observationLatitude, observationLongitude, radius,
                                         innerRadius, outerRadius);
    };
    if (!(latB > latA && lonB > lonA))
        return 0.0;

    const double middleLat1 = std::max(latA, holeLat1);
    const double middleLat2 = std::min(latB, holeLat2);
    if (!(middleLat2 > middleLat1)) {
        return integrate(latA, latB, lonA, lonB);
    }

    std::vector<std::pair<double, double>> holeLongitudeIntervals;
    if (holeLon1 <= holeLon2) {
        holeLongitudeIntervals.push_back({holeLon1, holeLon2});
    } else {
        holeLongitudeIntervals.push_back({lonA, holeLon2});
        holeLongitudeIntervals.push_back({holeLon1, lonB});
    }

    std::vector<std::pair<double, double>> remaining{{lonA, lonB}};
    for (const auto& hole : holeLongitudeIntervals) {
        const double clipped1 = std::max(lonA, hole.first);
        const double clipped2 = std::min(lonB, hole.second);
        if (!(clipped2 > clipped1))
            continue;
        std::vector<std::pair<double, double>> next;
        for (const auto& segment : remaining) {
            if (clipped2 <= segment.first || clipped1 >= segment.second) {
                next.push_back(segment);
                continue;
            }
            if (clipped1 > segment.first)
                next.push_back({segment.first, clipped1});
            if (clipped2 < segment.second)
                next.push_back({clipped2, segment.second});
        }
        remaining.swap(next);
    }

    std::vector<double> pieces;
    pieces.reserve(2 + remaining.size());
    pieces.push_back(integrate(latA, middleLat1, lonA, lonB));
    pieces.push_back(integrate(middleLat2, latB, lonA, lonB));
    for (const auto& segment : remaining) {
        pieces.push_back(integrate(middleLat1, middleLat2, segment.first, segment.second));
    }
    return Work2MagKahanSum(pieces);
}

struct Work2MagHessian {
    double xx = 0.0;
    double xy = 0.0;
    double yy = 0.0;
    double zx = 0.0;
    double zy = 0.0;
    double zz = 0.0;
};

inline std::array<KernelFunction, 6>
Work2MagMakeHessianKernels(const std::vector<double>& outerRadius, const std::vector<double>& innerRadius,
                           const std::vector<double>& sourceWeight, double radius, double observationLatitude,
                           double observationLongitude, double lons, double lone, double lats, double late, double dLon,
                           double dLat, double holeLon1, double holeLon2, double holeLat1, double holeLat2) {
    auto make = [&](auto surfaceKernel) -> KernelFunction {
        return [&outerRadius, &innerRadius, &sourceWeight, radius, observationLatitude, observationLongitude, lons,
                lone, lats, late, dLon, dLat, holeLon1, holeLon2, holeLat1, holeLat2,
                surfaceKernel](const Eigen::Matrix<double, 14, 14>& sourceLatitudes,
                               const Eigen::Matrix<double, 14, 14>& sourceLongitudes) {
            return surfaceKernel(outerRadius, innerRadius, sourceWeight, sourceLatitudes, sourceLongitudes, radius,
                                 observationLatitude, observationLongitude, lons, lone, lats, late, dLon, dLat,
                                 holeLon1, holeLon2, holeLat1, holeLat2);
        };
    };

    return {make(Tesseroid::Tesseroid_SurfaceKernelVxx), make(Tesseroid::Tesseroid_SurfaceKernelVxy),
            make(Tesseroid::Tesseroid_SurfaceKernelVyy), make(Tesseroid::Tesseroid_SurfaceKernelVzx),
            make(Tesseroid::Tesseroid_SurfaceKernelVzy), make(Tesseroid::Tesseroid_SurfaceKernelVzz)};
}

inline Work2MagHessian
Work2MagGravityHessianPointEstimate(double lons, double lone, double lats, double late, double dLon, double dLat,
                                    const std::vector<double>& outerRadius, const std::vector<double>& innerRadius,
                                    const std::vector<double>& sourceWeight, double latitude, double longitude,
                                    double radius, double absoluteTolerance, double relativeTolerance) {
    const double pi = 4.0 * std::atan(1.0);
    const double degreeAreaCorrection = pi * pi / (180.0 * 180.0);
    longitude = Work2MagNormalizeLongitude(longitude);

    double holeLon1 = 0.0;
    double holeLon2 = 0.0;
    double holeLat1 = 0.0;
    double holeLat2 = 0.0;
    if (std::abs(latitude - 90.0) < dLat) {
        holeLon1 = -180.0;
        holeLon2 = 180.0;
        holeLat1 = 90.0 - dLat;
        holeLat2 = 90.0;
    } else if (std::abs(latitude + 90.0) < dLat) {
        holeLon1 = -180.0;
        holeLon2 = 180.0;
        holeLat1 = -90.0;
        holeLat2 = -90.0 + dLat;
    } else {
        holeLat1 = latitude - 0.5 * dLat;
        holeLat2 = latitude + 0.5 * dLat;
        if (holeLat1 < -90.0) {
            holeLat1 = -90.0;
            holeLat2 = -90.0 + dLat;
        }
        if (holeLat2 > 90.0) {
            holeLat2 = 90.0;
            holeLat1 = 90.0 - dLat;
        }
        holeLon1 = Work2MagNormalizeLongitude(longitude - 0.5 * dLon);
        holeLon2 = Work2MagNormalizeLongitude(longitude + 0.5 * dLon);
    }

    const double localOuterRadius =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, outerRadius, longitude, latitude);
    const double localInnerRadius =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, innerRadius, longitude, latitude);
    const double localSourceWeight =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, sourceWeight, longitude, latitude);

    const auto actualKernels =
        Work2MagMakeHessianKernels(outerRadius, innerRadius, sourceWeight, radius, latitude, longitude, lons, lone,
                                   lats, late, dLon, dLat, holeLon1, holeLon2, holeLat1, holeLat2);

    auto makePeakFun = [&](auto kernel) -> TesseroidMSIPeakFunction {
        return [=](double FaiI, double LamdaI) {
            double Tx, Ty, SinPsi, CosPsi;
            Tesseroid::surfacekernel_detail::LocalGeometry(FaiI, LamdaI, latitude, longitude, Tx, Ty, SinPsi, CosPsi);
            return std::cos(FaiI * Phithreshold::Deg2Rad) *
                   kernel(localOuterRadius / radius, localInnerRadius / radius, Tx, Ty, SinPsi, CosPsi);
        };
    };
    const std::array<TesseroidMSIPeakFunction, 6> peakKernels{
        makePeakFun(Tesseroid::surfacekernel_detail::KVxx), makePeakFun(Tesseroid::surfacekernel_detail::KVxy),
        makePeakFun(Tesseroid::surfacekernel_detail::KVyy), makePeakFun(Tesseroid::surfacekernel_detail::KVzx),
        makePeakFun(Tesseroid::surfacekernel_detail::KVzy), makePeakFun(Tesseroid::surfacekernel_detail::KVzz)};

    static const std::array<std::string, 6> componentNames{"Vxx", "Vxy", "Vyy", "Vzx", "Vzy", "Vzz"};
    std::array<double, 6> target1{};
    for (std::size_t i = 0; i < target1.size(); ++i) {
        target1[i] =
            Tesseroid::integral2t_MMSI_Peak(actualKernels[i], peakKernels[i], componentNames[i], lats - 0.5 * dLat,
                                            late + 0.5 * dLat, lons - 0.5 * dLon, lone + 0.5 * dLon, holeLat1, holeLat2,
                                            holeLon1, holeLon2, absoluteTolerance, relativeTolerance, latitude,
                                            longitude, radius, localInnerRadius, localOuterRadius) *
            degreeAreaCorrection;
    }

    Work2MagHessian result{target1[0], target1[1], target1[2], target1[3], target1[4], target1[5]};

    const bool insideAngularModel = longitude >= lons - 0.5 * dLon && longitude <= lone + 0.5 * dLon &&
                                    latitude >= lats - 0.5 * dLat && latitude <= late + 0.5 * dLat;
    if (!insideAngularModel)
        return result;

    auto makeDummyKernel = [&](auto kernel) -> KernelFunction {
        return [=](const Eigen::Matrix<double, 14, 14>& sourceLatitudes,
                   const Eigen::Matrix<double, 14, 14>& sourceLongitudes) {
            return Tesseroid::surfacekernel_detail::EvaluateSurfaceKernelConstant(
                localOuterRadius, localInnerRadius, localSourceWeight, sourceLatitudes, sourceLongitudes, radius,
                latitude, longitude, holeLon1, holeLon2, holeLat1, holeLat2, kernel);
        };
    };
    const std::array<KernelFunction, 6> dummyKernels{
        makeDummyKernel(Tesseroid::surfacekernel_detail::KVxx), makeDummyKernel(Tesseroid::surfacekernel_detail::KVxy),
        makeDummyKernel(Tesseroid::surfacekernel_detail::KVyy), makeDummyKernel(Tesseroid::surfacekernel_detail::KVzx),
        makeDummyKernel(Tesseroid::surfacekernel_detail::KVzy), makeDummyKernel(Tesseroid::surfacekernel_detail::KVzz)};

    std::array<double, 6> target2{};
    for (std::size_t i = 0; i < target2.size(); ++i) {
        target2[i] = Tesseroid::integral2t_MMSI_Peak(dummyKernels[i], peakKernels[i], componentNames[i], -90.0, 90.0,
                                                     -180.0, 180.0, holeLat1, holeLat2, holeLon1, holeLon2,
                                                     absoluteTolerance, relativeTolerance, latitude, longitude, radius,
                                                     localInnerRadius, localOuterRadius) *
                     degreeAreaCorrection;
    }

    double shellXX = 0.0;
    double shellYY = 0.0;
    double shellZZ = 0.0;
    if (radius >= localOuterRadius) {
        const double massFactor = 4.0 * pi / 3.0 * (std::pow(localOuterRadius, 3) - std::pow(localInnerRadius, 3));
        shellXX = -massFactor / std::pow(radius, 3);
        shellYY = shellXX;
        shellZZ = 2.0 * massFactor / std::pow(radius, 3);
    } else if (radius > localInnerRadius) {
        shellXX = -4.0 * pi / 3.0 * (1.0 - std::pow(localInnerRadius, 3) / std::pow(radius, 3));
        shellYY = shellXX;
        shellZZ = -4.0 * pi / 3.0 * (1.0 + 2.0 * std::pow(localInnerRadius, 3) / std::pow(radius, 3));
    }
    shellXX *= localSourceWeight;
    shellYY *= localSourceWeight;
    shellZZ *= localSourceWeight;

    result.xx += shellXX - target2[0];
    result.xy -= target2[1];
    result.yy += shellYY - target2[2];
    result.zx -= target2[3];
    result.zy -= target2[4];
    result.zz += shellZZ - target2[5];
    return result;
}

inline void Work2MagVectorPointEstimate(double lons, double lone, double lats, double late, double dLon, double dLat,
                                        const std::vector<double>& outerRadius, const std::vector<double>& innerRadius,
                                        const std::vector<double>& magnetizationX,
                                        const std::vector<double>& magnetizationY,
                                        const std::vector<double>& magnetizationZ, double latitude, double longitude,
                                        double radius, double absoluteTolerance, double relativeTolerance, double* vx,
                                        double* vy, double* vz) {
    const long long latitudeCount = static_cast<long long>(std::llround((late - lats) / dLat)) + 1;
    const long long longitudeCount = static_cast<long long>(std::llround((lone - lons) / dLon)) + 1;
    const long long sourceCount = latitudeCount * longitudeCount;
    const double pi = 4.0 * std::atan(1.0);

    std::vector<double> localX(sourceCount);
    std::vector<double> localY(sourceCount);
    std::vector<double> localZ(sourceCount);

    const double deg2rad = pi / 180.0;
    const double cosineObservationLatitude = std::cos(latitude * deg2rad);
    const double sineObservationLatitude = std::sin(latitude * deg2rad);
    long long index = 0;
    for (long long i = 0; i < longitudeCount; ++i) {
        const double sourceLongitude = lons + i * dLon;
        const double beta = (sourceLongitude - longitude) * deg2rad;
        const double cosineBeta = std::cos(beta);
        const double sineBeta = std::sin(beta);
        for (long long j = 0; j < latitudeCount; ++j, ++index) {
            const double sourceLatitude = lats + j * dLat;
            const double latitudeRadians = sourceLatitude * deg2rad;
            const double cosineSourceLatitude = std::cos(latitudeRadians);
            const double sineSourceLatitude = std::sin(latitudeRadians);

            localX[index] = (cosineBeta * sineObservationLatitude * sineSourceLatitude +
                             cosineObservationLatitude * cosineSourceLatitude) *
                                magnetizationX[index] +
                            sineBeta * sineObservationLatitude * magnetizationY[index] +
                            (cosineObservationLatitude * sineSourceLatitude -
                             cosineBeta * sineObservationLatitude * cosineSourceLatitude) *
                                magnetizationZ[index];

            localY[index] = -sineBeta * sineSourceLatitude * magnetizationX[index] +
                            cosineBeta * magnetizationY[index] +
                            sineBeta * cosineSourceLatitude * magnetizationZ[index];

            localZ[index] = (sineObservationLatitude * cosineSourceLatitude -
                             cosineBeta * cosineObservationLatitude * sineSourceLatitude) *
                                magnetizationX[index] -
                            sineBeta * cosineObservationLatitude * magnetizationY[index] +
                            (cosineBeta * cosineObservationLatitude * cosineSourceLatitude +
                             sineObservationLatitude * sineSourceLatitude) *
                                magnetizationZ[index];
        }
    }

    const Work2MagHessian hessianX =
        Work2MagGravityHessianPointEstimate(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, localX,
                                            latitude, longitude, radius, absoluteTolerance, relativeTolerance);
    const Work2MagHessian hessianY =
        Work2MagGravityHessianPointEstimate(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, localY,
                                            latitude, longitude, radius, absoluteTolerance, relativeTolerance);
    const Work2MagHessian hessianZ =
        Work2MagGravityHessianPointEstimate(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, localZ,
                                            latitude, longitude, radius, absoluteTolerance, relativeTolerance);

    *vx = hessianX.xx + hessianY.xy + hessianZ.zx;
    *vy = hessianX.xy + hessianY.yy + hessianZ.zy;
    *vz = hessianX.zx + hessianY.zy + hessianZ.zz;
}

inline void Work2MagVectorComputeMPI(double lons, double lone, double lats, double late, double dLon, double dLat,
                                     std::vector<double>& outerRadius, std::vector<double>& innerRadius,
                                     std::vector<double>& magnetizationX, std::vector<double>& magnetizationY,
                                     std::vector<double>& magnetizationZ, std::vector<double>& latitude,
                                     std::vector<double>& longitude, std::vector<double>& radius,
                                     double absoluteTolerance, double relativeTolerance, std::vector<double>& vx,
                                     std::vector<double>& vy, std::vector<double>& vz) {
    int rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    const int pointCount = static_cast<int>(latitude.size());
    const long long modelCount = static_cast<long long>(outerRadius.size());
    if (modelCount > std::numeric_limits<int>::max()) {
        if (rank == 0)
            std::cerr << "Error: model is too large for a single MPI_Bcast count.\n";
        MPI_Abort(MPI_COMM_WORLD, 30);
    }

    MPI_Bcast(outerRadius.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(innerRadius.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(magnetizationX.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(magnetizationY.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(magnetizationZ.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(latitude.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(longitude.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(radius.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    std::vector<int> counts;
    std::vector<int> displacements;
    Work2MagDistribute(pointCount, counts, displacements);

    const int localCount = counts[rank];
    const int offset = displacements[rank];
    std::vector<double> localVx(localCount);
    std::vector<double> localVy(localCount);
    std::vector<double> localVz(localCount);

    Work2MagTimer timer;
    if (rank == 0)
        timer.start();

    for (int i = 0; i < localCount; ++i) {
        const int globalIndex = offset + i;
        Work2MagVectorPointEstimate(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, magnetizationX,
                                    magnetizationY, magnetizationZ, latitude[globalIndex], longitude[globalIndex],
                                    radius[globalIndex], absoluteTolerance, relativeTolerance, &localVx[i], &localVy[i],
                                    &localVz[i]);
    }

    if (rank == 0) {
        vx.resize(pointCount);
        vy.resize(pointCount);
        vz.resize(pointCount);
    }
    MPI_Gatherv(localVx.data(), localCount, MPI_DOUBLE, rank == 0 ? vx.data() : nullptr, counts.data(),
                displacements.data(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(localVy.data(), localCount, MPI_DOUBLE, rank == 0 ? vy.data() : nullptr, counts.data(),
                displacements.data(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Gatherv(localVz.data(), localCount, MPI_DOUBLE, rank == 0 ? vz.data() : nullptr, counts.data(),
                displacements.data(), MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        std::cout << "Work2 magnetic vector elapsed time: " << timer.seconds() << " seconds\n";
    }
}
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank = 0;
    int nprocs = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    const char* parameterFile = "MSIM.ForPar";
    const char* resultFile = "ResultM.dat";

    double absoluteTolerance = 0.0;
    double relativeTolerance = 0.0;
    double lons = 0.0;
    double lone = 0.0;
    double lats = 0.0;
    double late = 0.0;
    double dLon = 0.0;
    double dLat = 0.0;
    int numLon = 0;
    int numLat = 0;
    int pointCount = 0;
    int readOK = 1;

    std::vector<double> outerRadius;
    std::vector<double> innerRadius;
    std::vector<double> magnetizationX;
    std::vector<double> magnetizationY;
    std::vector<double> magnetizationZ;
    std::vector<double> longitude;
    std::vector<double> latitude;
    std::vector<double> radius;

    if (rank == 0) {
        FILE* file = std::fopen(parameterFile, "rb");
        if (file == nullptr) {
            std::cerr << "Error: failed to open " << parameterFile << "\n";
            readOK = 0;
        }
        if (readOK) {
            readOK =
                std::fread(&absoluteTolerance, sizeof(double), 1, file) == 1 &&
                std::fread(&relativeTolerance, sizeof(double), 1, file) == 1 &&
                std::fread(&lons, sizeof(double), 1, file) == 1 && std::fread(&lone, sizeof(double), 1, file) == 1 &&
                std::fread(&lats, sizeof(double), 1, file) == 1 && std::fread(&late, sizeof(double), 1, file) == 1 &&
                std::fread(&dLon, sizeof(double), 1, file) == 1 && std::fread(&dLat, sizeof(double), 1, file) == 1 &&
                std::fread(&numLon, sizeof(int), 1, file) == 1 && std::fread(&numLat, sizeof(int), 1, file) == 1;
        }
        if (readOK && (numLon < 2 || numLat < 2 || dLon <= 0.0 || dLat <= 0.0)) {
            std::cerr << "Error: invalid model dimensions or grid spacing.\n";
            readOK = 0;
        }
        if (readOK) {
            const std::size_t modelCount = static_cast<std::size_t>(numLon) * static_cast<std::size_t>(numLat);
            outerRadius.resize(modelCount);
            innerRadius.resize(modelCount);
            magnetizationX.resize(modelCount);
            magnetizationY.resize(modelCount);
            magnetizationZ.resize(modelCount);
            readOK = std::fread(outerRadius.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(innerRadius.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(magnetizationX.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(magnetizationY.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(magnetizationZ.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(&pointCount, sizeof(int), 1, file) == 1;
        }
        if (readOK && pointCount > 0) {
            longitude.resize(pointCount);
            latitude.resize(pointCount);
            radius.resize(pointCount);
            readOK =
                std::fread(longitude.data(), sizeof(double), pointCount, file) ==
                    static_cast<std::size_t>(pointCount) &&
                std::fread(latitude.data(), sizeof(double), pointCount, file) == static_cast<std::size_t>(pointCount) &&
                std::fread(radius.data(), sizeof(double), pointCount, file) == static_cast<std::size_t>(pointCount);
        } else if (readOK) {
            std::cerr << "Error: no observation points were supplied.\n";
            readOK = 0;
        }
        if (file != nullptr)
            std::fclose(file);
    }

    if (rank == 0 && readOK) {
        const auto outer = std::minmax_element(outerRadius.begin(), outerRadius.end());
        const auto inner = std::minmax_element(innerRadius.begin(), innerRadius.end());
        const auto mx = std::minmax_element(magnetizationX.begin(), magnetizationX.end());
        const auto my = std::minmax_element(magnetizationY.begin(), magnetizationY.end());
        const auto mz = std::minmax_element(magnetizationZ.begin(), magnetizationZ.end());
        const auto obsLon = std::minmax_element(longitude.begin(), longitude.end());
        const auto obsLat = std::minmax_element(latitude.begin(), latitude.end());
        const auto obsRad = std::minmax_element(radius.begin(), radius.end());
        std::cout << "\n======= Work2 magnetization-shell parameters =======\n"
                  << "Files: " << parameterFile << " -> " << resultFile << " | MPI processes: " << nprocs << '\n'
                  << "Grid: lon [" << lons << ", " << lone << "], step " << dLon << " deg; lat [" << lats << ", "
                  << late << "], step " << dLat << " deg\n"
                  << "Grid size: " << numLon << " x " << numLat << " = " << outerRadius.size() << " nodes\n"
                  << "Outer radius: [" << *outer.first << ", " << *outer.second << "]; inner radius: [" << *inner.first
                  << ", " << *inner.second << "]\n"
                  << "Magnetization: Mx [" << *mx.first << ", " << *mx.second << "], My [" << *my.first << ", "
                  << *my.second << "], Mz [" << *mz.first << ", " << *mz.second << "]\n"
                  << "Observations: " << pointCount << "; lon [" << *obsLon.first << ", " << *obsLon.second
                  << "] deg; lat [" << *obsLat.first << ", " << *obsLat.second << "] deg; radius [" << *obsRad.first
                  << ", " << *obsRad.second << "]\n"
                  << "Tolerance: abs " << absoluteTolerance << ", rel " << relativeTolerance << '\n'
                  << "Components: Vx, Vy, Vz only; other Work1-layout fields are NaN\n"
                  << "====================================================\n\n"
                  << std::flush;
        std::cout << "Starting Work2 magnetization-shell vector integration...\n\n";
    }

    MPI_Bcast(&readOK, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (!readOK) {
        MPI_Finalize();
        return EXIT_FAILURE;
    }

    MPI_Bcast(&absoluteTolerance, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&relativeTolerance, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lons, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lone, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lats, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&late, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dLon, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dLat, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numLon, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numLat, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&pointCount, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank != 0) {
        const std::size_t modelCount = static_cast<std::size_t>(numLon) * static_cast<std::size_t>(numLat);
        outerRadius.resize(modelCount);
        innerRadius.resize(modelCount);
        magnetizationX.resize(modelCount);
        magnetizationY.resize(modelCount);
        magnetizationZ.resize(modelCount);
        longitude.resize(pointCount);
        latitude.resize(pointCount);
        radius.resize(pointCount);
    }

    std::vector<double> vx;
    std::vector<double> vy;
    std::vector<double> vz;
    Work2MagVector::Work2MagVectorComputeMPI(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius,
                                             magnetizationX, magnetizationY, magnetizationZ, latitude, longitude,
                                             radius, absoluteTolerance, relativeTolerance, vx, vy, vz);

    int writeOK = 1;
    if (rank == 0) {
        const std::vector<double> notComputed(pointCount, std::numeric_limits<double>::quiet_NaN());
        auto writeArray = [](FILE* file, const std::vector<double>& values, int count) {
            return std::fwrite(values.data(), sizeof(double), count, file) == static_cast<std::size_t>(count);
        };

        FILE* file = std::fopen(resultFile, "wb");
        if (file == nullptr) {
            std::cerr << "Error: failed to open " << resultFile << "\n";
            writeOK = 0;
        }
        if (writeOK) {
            writeOK = std::fwrite(&pointCount, sizeof(int), 1, file) == 1 && writeArray(file, longitude, pointCount) &&
                      writeArray(file, latitude, pointCount) && writeArray(file, radius, pointCount) &&

                      writeArray(file, notComputed, pointCount) && writeArray(file, vx, pointCount) &&
                      writeArray(file, vy, pointCount) && writeArray(file, vz, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount);
        }
        if (file != nullptr)
            std::fclose(file);
    }

    MPI_Bcast(&writeOK, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Finalize();
    return writeOK ? EXIT_SUCCESS : EXIT_FAILURE;
}
