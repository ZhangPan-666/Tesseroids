﻿
#pragma once
#include <Eigen/Dense>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <mpi.h>
#include <omp.h>
#include <string>
#include <utility>
#include <vector>

#include "_integral2.h"
#include "_tesseroid_surfacekernel.h"

namespace Tesseroid {
enum TesseroidMSIComponent : std::uint32_t {
    MSI_V = 1u << 0,
    MSI_Vx = 1u << 1,
    MSI_Vy = 1u << 2,
    MSI_Vz = 1u << 3,
    MSI_Vxx = 1u << 4,
    MSI_Vxy = 1u << 5,
    MSI_Vyy = 1u << 6,
    MSI_Vzx = 1u << 7,
    MSI_Vzy = 1u << 8,
    MSI_Vzz = 1u << 9,
    MSI_Vxxx = 1u << 10,
    MSI_Vxxy = 1u << 11,
    MSI_Vxxz = 1u << 12,
    MSI_Vxyz = 1u << 13,
    MSI_Vyyx = 1u << 14,
    MSI_Vyyy = 1u << 15,
    MSI_Vyyz = 1u << 16,
    MSI_Vzzx = 1u << 17,
    MSI_Vzzy = 1u << 18,
    MSI_Vzzz = 1u << 19,
    MSI_All = (1u << 20) - 1u
};

inline std::uint32_t Tesseroid_MSI_ComponentMask(const std::string& name) {
    if (name == "V")
        return MSI_V;
    if (name == "Vx")
        return MSI_Vx;
    if (name == "Vy")
        return MSI_Vy;
    if (name == "Vz")
        return MSI_Vz;
    if (name == "Vxx")
        return MSI_Vxx;
    if (name == "Vxy")
        return MSI_Vxy;
    if (name == "Vyy")
        return MSI_Vyy;
    if (name == "Vzx")
        return MSI_Vzx;
    if (name == "Vzy")
        return MSI_Vzy;
    if (name == "Vzz")
        return MSI_Vzz;
    if (name == "Vxxx")
        return MSI_Vxxx;
    if (name == "Vxxy")
        return MSI_Vxxy;
    if (name == "Vxxz")
        return MSI_Vxxz;
    if (name == "Vxyz")
        return MSI_Vxyz;
    if (name == "Vyyx")
        return MSI_Vyyx;
    if (name == "Vyyy")
        return MSI_Vyyy;
    if (name == "Vyyz")
        return MSI_Vyyz;
    if (name == "Vzzx")
        return MSI_Vzzx;
    if (name == "Vzzy")
        return MSI_Vzzy;
    if (name == "Vzzz")
        return MSI_Vzzz;
    return MSI_All;
}

inline thread_local std::uint32_t Tesseroid_MSI_ActiveComponents = MSI_All;

class TesseroidMSIComponentScope {
  public:
    explicit TesseroidMSIComponentScope(std::uint32_t mask) : previous_(Tesseroid_MSI_ActiveComponents) {
        Tesseroid_MSI_ActiveComponents = mask;
    }
    ~TesseroidMSIComponentScope() { Tesseroid_MSI_ActiveComponents = previous_; }

  private:
    std::uint32_t previous_;
};

class TicToc {
  public:
    void tic() { t0 = Clock::now(); }

    double toc() const { return std::chrono::duration<double>(Clock::now() - t0).count(); }

  private:
    using Clock = std::chrono::high_resolution_clock;
    std::chrono::time_point<Clock> t0;
};

inline void MPIDistribute(int Num, int* DataList, int* VectorShiftList) {
    int i, j;
    int rank, nprocs;
    int DataPerBatch, NumRemain;

    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    NumRemain = Num % nprocs;
    DataPerBatch = (Num - NumRemain) / nprocs;

    for (i = 1; i <= nprocs; i++) {
        if (i <= NumRemain) {
            DataList[i - 1] = DataPerBatch + 1;
        } else {
            DataList[i - 1] = DataPerBatch;
        }
    }

    for (i = 1; i <= nprocs; i++) {
        VectorShiftList[i - 1] = 0;
        if (i == 1) {
            continue;
        }
        for (j = 1; j <= (i - 1); j++) {
            VectorShiftList[i - 1] += DataList[j - 1];
        }
    }
}

template <class Func>
inline double integral2t_MMSI(const Func& FUN, double LatA, double LatB, double LonA, double LonB, double Lat0s,
                              double Lat0e, double Lon0s, double Lon0e, double AbsTol, double RelTol) {
    auto integrate = [&](double lat1, double lat2, double lon1, double lon2) -> double {
        if (!(lat2 > lat1 && lon2 > lon1)) {
            return 0.0;
        }
        return integral2t(FUN, lat1, lat2, lon1, lon2, AbsTol, RelTol);
    };

    if (!(LatB > LatA && LonB > LonA)) {
        return 0.0;
    }

    const double hLat1 = std::max(LatA, Lat0s);
    const double hLat2 = std::min(LatB, Lat0e);

    if (!(hLat2 > hLat1)) {
        return integrate(LatA, LatB, LonA, LonB);
    }

    std::vector<std::pair<double, double>> holeLonIntervals;

    if (Lon0s <= Lon0e) {
        holeLonIntervals.push_back({Lon0s, Lon0e});
    } else {

        holeLonIntervals.push_back({LonA, Lon0e});
        holeLonIntervals.push_back({Lon0s, LonB});
    }

    std::vector<std::pair<double, double>> remainLonIntervals;
    remainLonIntervals.push_back({LonA, LonB});

    for (const auto& h0 : holeLonIntervals) {
        const double hLon1 = std::max(LonA, h0.first);
        const double hLon2 = std::min(LonB, h0.second);

        if (!(hLon2 > hLon1)) {
            continue;
        }

        std::vector<std::pair<double, double>> nextIntervals;
        for (const auto& seg : remainLonIntervals) {
            const double a = seg.first;
            const double b = seg.second;

            if (hLon2 <= a || hLon1 >= b) {
                nextIntervals.push_back(seg);
                continue;
            }

            if (hLon1 > a) {
                nextIntervals.push_back({a, hLon1});
            }
            if (hLon2 < b) {
                nextIntervals.push_back({hLon2, b});
            }
        }
        remainLonIntervals.swap(nextIntervals);
    }

    double Q = 0.0;

    Q += integrate(LatA, hLat1, LonA, LonB);
    Q += integrate(hLat2, LatB, LonA, LonB);

    for (const auto& seg : remainLonIntervals) {
        Q += integrate(hLat1, hLat2, seg.first, seg.second);
    }

    return Q;
}

using TesseroidMSIKernelFunction = std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                                               const Eigen::Matrix<double, 14, 14>&)>;
using TesseroidMSIPeakFunction = std::function<double(double, double)>;

enum class TesseroidMSIPeakPattern {
    CenterOne,
    XTwo,
    YTwo,
    XThree,
    YThree,
    DiagonalFour,
    XFour,
    YFour,
    XXYSix,
    YYXSix
};

inline double Tesseroid_MSI_NormalizeLon180(double lon) {
    lon = std::fmod(lon + 180.0, 360.0);
    if (lon < 0.0) {
        lon += 360.0;
    }
    return lon - 180.0;
}

inline double Tesseroid_MSI_KernelScalar(const TesseroidMSIKernelFunction& fun, double lat, double lon) {
    const Eigen::Matrix<double, 14, 14> F = Eigen::Matrix<double, 14, 14>::Constant(lat);
    const Eigen::Matrix<double, 14, 14> L = Eigen::Matrix<double, 14, 14>::Constant(lon);
    const Eigen::Matrix<double, 14, 14> Z = fun(F, L);
    const double y = Z(0, 0);
    return std::isfinite(y) ? y : 0.0;
}

inline double Tesseroid_MSI_KahanSum(const std::vector<double>& values) {
    double sum = 0.0;
    double c = 0.0;
    for (const double value : values) {
        const double y = value - c;
        const double t = sum + y;
        c = (t - sum) - y;
        sum = t;
    }
    return sum;
}

inline std::vector<double> Tesseroid_MSI_UniqueFinite(std::vector<double> values) {
    values.erase(std::remove_if(values.begin(), values.end(), [](double x) { return !std::isfinite(x); }),
                 values.end());

    if (values.empty()) {
        return values;
    }

    std::sort(values.begin(), values.end());
    double maxAbs = 1.0;
    for (const double x : values) {
        maxAbs = std::max(maxAbs, std::abs(x));
    }
    const double tol = 1.0e-10 * maxAbs;

    std::vector<double> unique;
    unique.reserve(values.size());
    unique.push_back(values.front());
    for (std::size_t i = 1; i < values.size(); ++i) {
        if (std::abs(values[i] - unique.back()) > tol) {
            unique.push_back(values[i]);
        }
    }
    return unique;
}

inline std::vector<double> Tesseroid_MSI_CleanBreaks(std::vector<double> breaks, double a, double b) {
    breaks.erase(std::remove_if(breaks.begin(), breaks.end(), [](double x) { return !std::isfinite(x); }),
                 breaks.end());

    for (double& x : breaks) {
        x = std::min(b, std::max(a, x));
    }
    std::sort(breaks.begin(), breaks.end());

    if (breaks.empty()) {
        return {a, b};
    }

    const double tol = std::max(1.0e-12, 1.0e-10 * std::max(1.0, std::abs(b - a)));
    std::vector<double> clean;
    clean.reserve(breaks.size() + 2);
    clean.push_back(breaks.front());
    for (std::size_t i = 1; i < breaks.size(); ++i) {
        if (std::abs(breaks[i] - clean.back()) > tol) {
            clean.push_back(breaks[i]);
        }
    }

    if (clean.front() > a + tol) {
        clean.insert(clean.begin(), a);
    } else {
        clean.front() = a;
    }

    if (clean.back() < b - tol) {
        clean.push_back(b);
    } else {
        clean.back() = b;
    }

    return clean;
}

inline void Tesseroid_MSI_AddBreaksWithEdgeSnap(std::vector<double>& breaks, const std::vector<double>& candidates,
                                                double a, double b, double edgeTol) {
    const double breakTol = std::max(1.0e-12, 1.0e-12 * std::max(1.0, std::abs(b - a)));

    for (double x : candidates) {
        if (!std::isfinite(x)) {
            continue;
        }

        if (std::abs(x - a) <= edgeTol) {
            x = a;
        } else if (std::abs(x - b) <= edgeTol) {
            x = b;
        } else if (x < a - edgeTol || x > b + edgeTol) {
            continue;
        }

        if (x > a + breakTol && x < b - breakTol) {
            breaks.push_back(x);
        }
    }
}

inline TesseroidMSIPeakPattern Tesseroid_MSI_PeakPattern(const std::string& componentName) {
    if (componentName == "V" || componentName == "Vz" || componentName == "Vzz" || componentName == "Vzzz") {
        return TesseroidMSIPeakPattern::CenterOne;
    }
    if (componentName == "Vx" || componentName == "Vzx" || componentName == "Vzzx") {
        return TesseroidMSIPeakPattern::XTwo;
    }
    if (componentName == "Vy" || componentName == "Vzy" || componentName == "Vzzy") {
        return TesseroidMSIPeakPattern::YTwo;
    }
    if (componentName == "Vxx" || componentName == "Vxxz") {
        return TesseroidMSIPeakPattern::XThree;
    }
    if (componentName == "Vyy" || componentName == "Vyyz") {
        return TesseroidMSIPeakPattern::YThree;
    }
    if (componentName == "Vxy" || componentName == "Vxyz") {
        return TesseroidMSIPeakPattern::DiagonalFour;
    }
    if (componentName == "Vxxx") {
        return TesseroidMSIPeakPattern::XFour;
    }
    if (componentName == "Vyyy") {
        return TesseroidMSIPeakPattern::YFour;
    }
    if (componentName == "Vxxy") {
        return TesseroidMSIPeakPattern::XXYSix;
    }
    if (componentName == "Vyyx") {
        return TesseroidMSIPeakPattern::YYXSix;
    }
    return TesseroidMSIPeakPattern::CenterOne;
}

inline void Tesseroid_MSI_SearchWindowDeg(double fai, double dFaiBase, double dLonBase, double r, double R1Peak,
                                          double R2Peak, double& searchLat, double& searchLon) {
    const double pi = 4.0 * std::atan(1.0);
    const double rad = pi / 180.0;
    const double cosF = std::max(std::abs(std::cos(fai * rad)), 1.0e-6);

    double h = 0.0;
    if (r > R2Peak) {
        h = r - R2Peak;
    } else if (r < R1Peak) {
        h = R1Peak - r;
    } else {
        h = std::min(std::abs(r - R1Peak), std::abs(R2Peak - r));
    }

    const double hDeg =
        std::atan2(std::max(h, 0.0), std::max(std::abs(r), std::numeric_limits<double>::epsilon())) * 180.0 / pi;
    double basePhys = std::max(std::abs(dFaiBase), std::abs(dLonBase) * cosF);
    if (basePhys <= 0.0 || !std::isfinite(basePhys)) {
        basePhys = 0.1;
    }

    double searchPhys = std::max(12.0 * hDeg, std::min(0.25 * basePhys, 0.2));
    searchPhys = std::max(searchPhys, std::min(0.05, basePhys));
    searchPhys = std::min(searchPhys, std::max(2.0 * basePhys, 0.1));
    searchPhys = std::max(searchPhys, 1.0e-8);

    searchLat = std::min(searchPhys, 180.0);
    searchLon = std::min(searchPhys / cosF, 360.0);
}

inline double Tesseroid_MSI_GoldenMaxAbs1D(const std::function<double(double)>& fline, double a, double b) {
    if (!(b > a)) {
        return a;
    }

    const double gr = (std::sqrt(5.0) - 1.0) * 0.5;
    double c = b - gr * (b - a);
    double d = a + gr * (b - a);
    double fc = std::abs(fline(c));
    double fd = std::abs(fline(d));
    if (!std::isfinite(fc))
        fc = 0.0;
    if (!std::isfinite(fd))
        fd = 0.0;

    for (int iter = 0; iter < 80; ++iter) {
        if (std::abs(b - a) <= 1.0e-12 * std::max(1.0, std::abs(a) + std::abs(b))) {
            break;
        }
        if (fc < fd) {
            a = c;
            c = d;
            fc = fd;
            d = a + gr * (b - a);
            fd = std::abs(fline(d));
            if (!std::isfinite(fd))
                fd = 0.0;
        } else {
            b = d;
            d = c;
            fd = fc;
            c = b - gr * (b - a);
            fc = std::abs(fline(c));
            if (!std::isfinite(fc))
                fc = 0.0;
        }
    }
    return 0.5 * (a + b);
}

inline std::vector<double> Tesseroid_MSI_FindPeaks1D(const std::function<double(double)>& fline, double a, double b,
                                                     int nPeaks) {
    std::vector<double> peaks;
    if (nPeaks <= 0 || !(b > a)) {
        return peaks;
    }

    const int N = std::max(129, 65 * nPeaks);
    std::vector<double> x(N);
    std::vector<double> z(N);
    const double pi = 4.0 * std::atan(1.0);
    for (int i = 0; i < N; ++i) {
        const double t = 0.5 - 0.5 * std::cos(pi * static_cast<double>(i) / static_cast<double>(N - 1));
        x[i] = a + (b - a) * t;
        z[i] = std::abs(fline(x[i]));
        if (!std::isfinite(z[i])) {
            z[i] = -std::numeric_limits<double>::infinity();
        }
    }

    bool hasFinite = false;
    for (const double zi : z) {
        if (std::isfinite(zi)) {
            hasFinite = true;
            break;
        }
    }
    if (!hasFinite) {
        return peaks;
    }

    std::vector<int> candidateIdx;
    for (int i = 1; i < N - 1; ++i) {
        if (z[i] >= z[i - 1] && z[i] >= z[i + 1]) {
            candidateIdx.push_back(i);
        }
    }

    if (candidateIdx.empty()) {
        int best = 1;
        for (int i = 2; i < N - 1; ++i) {
            if (z[i] > z[best]) {
                best = i;
            }
        }
        candidateIdx.push_back(best);
    }

    std::sort(candidateIdx.begin(), candidateIdx.end(), [&](int lhs, int rhs) { return z[lhs] > z[rhs]; });

    const double minSep = 0.01 * (b - a);
    for (const int idx : candidateIdx) {
        const int i1 = std::max(0, idx - 2);
        const int i2 = std::min(N - 1, idx + 2);
        double pp = x[idx];
        if (x[i2] > x[i1]) {
            pp = Tesseroid_MSI_GoldenMaxAbs1D(fline, x[i1], x[i2]);
        }

        bool separated = true;
        for (const double p : peaks) {
            if (std::abs(pp - p) <= minSep) {
                separated = false;
                break;
            }
        }
        if (separated) {
            peaks.push_back(pp);
        }
        if (static_cast<int>(peaks.size()) >= nPeaks) {
            break;
        }
    }
    return peaks;
}

inline void Tesseroid_MSI_FindPeaksMeridian(const TesseroidMSIPeakFunction& fun, double fai, double lon0,
                                            double searchLat, int nAbove, int nBelow, std::vector<double>& latPeaks,
                                            std::vector<double>& lonPeaks) {
    const double epsDeg = std::max(1.0e-10, 1.0e-8 * searchLat);
    const double lo = std::max(-90.0, fai - searchLat);
    const double hi = std::min(90.0, fai + searchLat);

    if (nBelow > 0 && fai - epsDeg > lo) {
        auto fline = [&](double lat) { return fun(lat, lon0); };
        const auto peaks = Tesseroid_MSI_FindPeaks1D(fline, lo, fai - epsDeg, nBelow);
        for (const double p : peaks) {
            latPeaks.push_back(p);
            lonPeaks.push_back(lon0);
        }
    }

    if (nAbove > 0 && hi > fai + epsDeg) {
        auto fline = [&](double lat) { return fun(lat, lon0); };
        const auto peaks = Tesseroid_MSI_FindPeaks1D(fline, fai + epsDeg, hi, nAbove);
        for (const double p : peaks) {
            latPeaks.push_back(p);
            lonPeaks.push_back(lon0);
        }
    }
}

inline void Tesseroid_MSI_FindPeaksParallel(const TesseroidMSIPeakFunction& fun, double lat0, double lamda,
                                            double searchLon, int nRight, int nLeft, std::vector<double>& latPeaks,
                                            std::vector<double>& lonPeaks) {
    const double epsDeg = std::max(1.0e-10, 1.0e-8 * searchLon);
    const double lo = std::max(-180.0, lamda - searchLon);
    const double hi = std::min(180.0, lamda + searchLon);

    if (nLeft > 0 && lamda - epsDeg > lo) {
        auto fline = [&](double lon) { return fun(lat0, lon); };
        const auto peaks = Tesseroid_MSI_FindPeaks1D(fline, lo, lamda - epsDeg, nLeft);
        for (const double p : peaks) {
            latPeaks.push_back(lat0);
            lonPeaks.push_back(p);
        }
    }

    if (nRight > 0 && hi > lamda + epsDeg) {
        auto fline = [&](double lon) { return fun(lat0, lon); };
        const auto peaks = Tesseroid_MSI_FindPeaks1D(fline, lamda + epsDeg, hi, nRight);
        for (const double p : peaks) {
            latPeaks.push_back(lat0);
            lonPeaks.push_back(p);
        }
    }
}

inline void Tesseroid_MSI_FindPeaksDiagonal(const TesseroidMSIPeakFunction& fun, double fai, double lamda,
                                            double searchLat, double searchLon, std::vector<double>& latPeaks,
                                            std::vector<double>& lonPeaks) {
    const double pi = 4.0 * std::atan(1.0);
    const double rad = pi / 180.0;
    const double cosF = std::abs(std::cos(fai * rad));
    if (cosF < 1.0e-8) {
        return;
    }

    const double sMax = std::min(searchLat, searchLon * cosF);
    if (sMax <= 0.0) {
        return;
    }

    const double epsS = std::max(1.0e-10, 1.0e-8 * sMax);
    const int signs[2] = {-1, 1};
    for (const int sx : signs) {
        for (const int sy : signs) {
            auto fline = [&](double s) {
                return fun(fai + sx * s, Tesseroid_MSI_NormalizeLon180(lamda + sy * s / cosF));
            };
            const auto peaks = Tesseroid_MSI_FindPeaks1D(fline, epsS, sMax, 1);
            if (!peaks.empty()) {
                const double p = peaks.front();
                latPeaks.push_back(fai + sx * p);
                lonPeaks.push_back(Tesseroid_MSI_NormalizeLon180(lamda + sy * p / cosF));
            }
        }
    }
}

inline void Tesseroid_MSI_RemoveDuplicatePeaks(std::vector<double>& latPeaks, std::vector<double>& lonPeaks) {
    std::vector<std::array<double, 2>> peaks;
    peaks.reserve(latPeaks.size());
    for (std::size_t i = 0; i < latPeaks.size() && i < lonPeaks.size(); ++i) {
        if (std::isfinite(latPeaks[i]) && std::isfinite(lonPeaks[i])) {
            peaks.push_back({latPeaks[i], lonPeaks[i]});
        }
    }

    const double tol = 1.0e-8;
    std::vector<std::array<double, 2>> unique;
    for (const auto& p : peaks) {
        bool duplicate = false;
        for (const auto& q : unique) {
            if (std::abs(p[0] - q[0]) < tol && std::abs(p[1] - q[1]) < tol) {
                duplicate = true;
                break;
            }
        }
        if (!duplicate) {
            unique.push_back(p);
        }
    }

    latPeaks.clear();
    lonPeaks.clear();
    latPeaks.reserve(unique.size());
    lonPeaks.reserve(unique.size());
    for (const auto& p : unique) {
        latPeaks.push_back(p[0]);
        lonPeaks.push_back(p[1]);
    }
}

inline void Tesseroid_MSI_FindAllKernelPeaks(const TesseroidMSIPeakFunction& peakFun, const std::string& componentName,
                                             double fai, double lamda, double dFaiBase, double dLonBase, double r,
                                             double R1Peak, double R2Peak, std::vector<double>& latPeaks,
                                             std::vector<double>& lonPeaks) {
    latPeaks.clear();
    lonPeaks.clear();

    const TesseroidMSIPeakPattern pattern = Tesseroid_MSI_PeakPattern(componentName);
    double searchLat = 0.0;
    double searchLon = 0.0;
    Tesseroid_MSI_SearchWindowDeg(fai, dFaiBase, dLonBase, r, R1Peak, R2Peak, searchLat, searchLon);

    switch (pattern) {
    case TesseroidMSIPeakPattern::CenterOne:
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidMSIPeakPattern::XTwo:
        Tesseroid_MSI_FindPeaksMeridian(peakFun, fai, lamda, searchLat, 1, 1, latPeaks, lonPeaks);
        break;

    case TesseroidMSIPeakPattern::YTwo:
        Tesseroid_MSI_FindPeaksParallel(peakFun, fai, lamda, searchLon, 1, 1, latPeaks, lonPeaks);
        break;

    case TesseroidMSIPeakPattern::XThree:
        Tesseroid_MSI_FindPeaksMeridian(peakFun, fai, lamda, searchLat, 1, 1, latPeaks, lonPeaks);
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidMSIPeakPattern::YThree:
        Tesseroid_MSI_FindPeaksParallel(peakFun, fai, lamda, searchLon, 1, 1, latPeaks, lonPeaks);
        latPeaks.push_back(fai);
        lonPeaks.push_back(lamda);
        break;

    case TesseroidMSIPeakPattern::DiagonalFour:
        Tesseroid_MSI_FindPeaksDiagonal(peakFun, fai, lamda, searchLat, searchLon, latPeaks, lonPeaks);
        break;

    case TesseroidMSIPeakPattern::XFour:
        Tesseroid_MSI_FindPeaksMeridian(peakFun, fai, lamda, searchLat, 2, 2, latPeaks, lonPeaks);
        break;

    case TesseroidMSIPeakPattern::YFour:
        Tesseroid_MSI_FindPeaksParallel(peakFun, fai, lamda, searchLon, 2, 2, latPeaks, lonPeaks);
        break;

    case TesseroidMSIPeakPattern::XXYSix: {
        std::vector<double> mainLat, mainLon;
        Tesseroid_MSI_FindPeaksParallel(peakFun, fai, lamda, searchLon, 1, 1, mainLat, mainLon);
        latPeaks.insert(latPeaks.end(), mainLat.begin(), mainLat.end());
        lonPeaks.insert(lonPeaks.end(), mainLon.begin(), mainLon.end());
        for (const double lon0 : mainLon) {
            Tesseroid_MSI_FindPeaksMeridian(peakFun, fai, lon0, searchLat, 1, 1, latPeaks, lonPeaks);
        }
        break;
    }

    case TesseroidMSIPeakPattern::YYXSix: {
        std::vector<double> mainLat, mainLon;
        Tesseroid_MSI_FindPeaksMeridian(peakFun, fai, lamda, searchLat, 1, 1, mainLat, mainLon);
        latPeaks.insert(latPeaks.end(), mainLat.begin(), mainLat.end());
        lonPeaks.insert(lonPeaks.end(), mainLon.begin(), mainLon.end());
        const double pi = 4.0 * std::atan(1.0);
        const double rad = pi / 180.0;
        const double cosE = std::max(std::abs(std::cos(fai * rad)), 1.0e-6);
        for (const double lat0 : mainLat) {
            const double cosAux = std::max(std::abs(std::cos(lat0 * rad)), 1.0e-6);
            const double searchLonAux = searchLon * cosE / cosAux;
            Tesseroid_MSI_FindPeaksParallel(peakFun, lat0, lamda, searchLonAux, 1, 1, latPeaks, lonPeaks);
        }
        break;
    }
    }

    Tesseroid_MSI_RemoveDuplicatePeaks(latPeaks, lonPeaks);
}

inline void Tesseroid_MSI_PeakGroupBreakCandidates(const std::string& componentName,
                                                   const std::vector<double>& latPeaksIn,
                                                   const std::vector<double>& lonPeaksIn, double fai, double lamda,
                                                   std::vector<double>& latCuts, std::vector<double>& lonCuts) {
    latCuts.clear();
    lonCuts.clear();

    std::vector<double> latPeaks;
    std::vector<double> lonPeaks;
    for (std::size_t i = 0; i < latPeaksIn.size() && i < lonPeaksIn.size(); ++i) {
        if (std::isfinite(latPeaksIn[i]) && std::isfinite(lonPeaksIn[i])) {
            latPeaks.push_back(latPeaksIn[i]);
            lonPeaks.push_back(lonPeaksIn[i]);
        }
    }

    const TesseroidMSIPeakPattern pattern = Tesseroid_MSI_PeakPattern(componentName);
    auto minmax = [](const std::vector<double>& v) { return std::minmax_element(v.begin(), v.end()); };

    switch (pattern) {
    case TesseroidMSIPeakPattern::CenterOne:
        latCuts.push_back(fai);
        lonCuts.push_back(lamda);
        break;

    case TesseroidMSIPeakPattern::XTwo:
    case TesseroidMSIPeakPattern::XThree:
    case TesseroidMSIPeakPattern::XFour:
        if (!latPeaks.empty()) {
            latCuts = latPeaks;
            lonCuts.push_back(lamda);
        }
        break;

    case TesseroidMSIPeakPattern::YTwo:
    case TesseroidMSIPeakPattern::YThree:
    case TesseroidMSIPeakPattern::YFour:
        if (!lonPeaks.empty()) {
            latCuts.push_back(fai);
            lonCuts = lonPeaks;
        }
        break;

    case TesseroidMSIPeakPattern::DiagonalFour:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(*lonMM.second);
        } else if (latPeaks.size() == 1 && lonPeaks.size() == 1) {
            latCuts.push_back(latPeaks.front());
            lonCuts.push_back(lonPeaks.front());
        }
        break;

    case TesseroidMSIPeakPattern::XXYSix:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(fai);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(*lonMM.second);
        } else if (!lonPeaks.empty()) {
            latCuts.push_back(fai);
            lonCuts = lonPeaks;
        }
        break;

    case TesseroidMSIPeakPattern::YYXSix:
        if (latPeaks.size() >= 2 && lonPeaks.size() >= 2) {
            auto latMM = minmax(latPeaks);
            auto lonMM = minmax(lonPeaks);
            latCuts.push_back(*latMM.first);
            latCuts.push_back(*latMM.second);
            lonCuts.push_back(*lonMM.first);
            lonCuts.push_back(lamda);
            lonCuts.push_back(*lonMM.second);
        } else if (!latPeaks.empty()) {
            latCuts = latPeaks;
            lonCuts.push_back(lamda);
        }
        break;
    }

    latCuts = Tesseroid_MSI_UniqueFinite(latCuts);
    lonCuts = Tesseroid_MSI_UniqueFinite(lonCuts);
}

inline double Tesseroid_MSI_GroupPeakIntegral(const TesseroidMSIKernelFunction& fun,
                                              const TesseroidMSIPeakFunction& peakFun, const std::string& componentName,
                                              double Fai1, double Fai2, double Lamda1, double Lamda2, double AbsTol,
                                              double RelTol, double fai, double lamda, double r, double R1Peak,
                                              double R2Peak, const std::vector<double>* cachedLatPeaks = nullptr,
                                              const std::vector<double>* cachedLonPeaks = nullptr) {
    if (!(Fai2 > Fai1 && Lamda2 > Lamda1)) {
        return 0.0;
    }

    if (std::abs(fai) == 90.0) {
        return integral2t(fun, Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol);
    }

    const double dFaiBase = std::abs(Fai2 - Fai1);
    const double dLonBase = std::abs(Lamda2 - Lamda1);

    std::vector<double> latPeaks;
    std::vector<double> lonPeaks;
    if (cachedLatPeaks != nullptr && cachedLonPeaks != nullptr) {
        latPeaks = *cachedLatPeaks;
        lonPeaks = *cachedLonPeaks;
    } else {
        Tesseroid_MSI_FindAllKernelPeaks(peakFun, componentName, fai, lamda, dFaiBase, dLonBase, r, R1Peak, R2Peak,
                                         latPeaks, lonPeaks);
    }

    std::vector<double> latCuts;
    std::vector<double> lonCuts;
    Tesseroid_MSI_PeakGroupBreakCandidates(componentName, latPeaks, lonPeaks, fai, lamda, latCuts, lonCuts);

    std::vector<double> latBreaks = {Fai1, Fai2};
    std::vector<double> lonBreaks = {Lamda1, Lamda2};

    const double edgeTolLat = std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(Fai2 - Fai1))));
    const double edgeTolLon = std::max(1.0e-6, std::min(1.0e-4, 1.0e-5 * std::max(1.0, std::abs(Lamda2 - Lamda1))));

    std::vector<double> latCandidates = latCuts;
    latCandidates.insert(latCandidates.end(), latPeaks.begin(), latPeaks.end());
    std::vector<double> lonCandidates = lonCuts;
    lonCandidates.insert(lonCandidates.end(), lonPeaks.begin(), lonPeaks.end());

    Tesseroid_MSI_AddBreaksWithEdgeSnap(latBreaks, latCandidates, Fai1, Fai2, edgeTolLat);
    Tesseroid_MSI_AddBreaksWithEdgeSnap(lonBreaks, lonCandidates, Lamda1, Lamda2, edgeTolLon);

    latBreaks = Tesseroid_MSI_CleanBreaks(latBreaks, Fai1, Fai2);
    lonBreaks = Tesseroid_MSI_CleanBreaks(lonBreaks, Lamda1, Lamda2);

    if (latBreaks.size() == 2 && lonBreaks.size() == 2) {
        return integral2t(fun, Fai1, Fai2, Lamda1, Lamda2, AbsTol, RelTol);
    }

    const std::size_t nSubMax = (latBreaks.size() - 1) * (lonBreaks.size() - 1);
    const double ATloc = AbsTol / std::max<std::size_t>(nSubMax, 1);
    const double RTloc = RelTol;

    std::vector<double> subQ;
    subQ.reserve(nSubMax);

    for (std::size_t i = 0; i + 1 < latBreaks.size(); ++i) {
        const double a = latBreaks[i];
        const double b = latBreaks[i + 1];
        if (!(b > a)) {
            continue;
        }
        for (std::size_t j = 0; j + 1 < lonBreaks.size(); ++j) {
            const double c = lonBreaks[j];
            const double d = lonBreaks[j + 1];
            if (!(d > c)) {
                continue;
            }
            subQ.push_back(integral2t(fun, a, b, c, d, ATloc, RTloc));
        }
    }

    return Tesseroid_MSI_KahanSum(subQ);
}

template <class Func, class PeakFunc>
inline double integral2t_MMSI_Peak(const Func& FUN, const PeakFunc& PEAKFUN, const std::string& componentName,
                                   double LatA, double LatB, double LonA, double LonB, double Lat0s, double Lat0e,
                                   double Lon0s, double Lon0e, double AbsTol, double RelTol, double fai, double lamda,
                                   double r, double R1Peak, double R2Peak, bool horizontalSubsplit = false) {
    if ((Tesseroid_MSI_ActiveComponents & Tesseroid_MSI_ComponentMask(componentName)) == 0u) {
        return 0.0;
    }
    if (!(LatB > LatA && LonB > LonA)) {
        return 0.0;
    }
    std::vector<double> cachedLatPeaks;
    std::vector<double> cachedLonPeaks;
    Tesseroid_MSI_FindAllKernelPeaks(PEAKFUN, componentName, fai, lamda, std::abs(LatB - LatA), std::abs(LonB - LonA),
                                     r, R1Peak, R2Peak, cachedLatPeaks, cachedLonPeaks);

    const double hLat1 = std::max(LatA, Lat0s);
    const double hLat2 = std::min(LatB, Lat0e);

    if (!(hLat2 > hLat1)) {
        return Tesseroid_MSI_GroupPeakIntegral(FUN, PEAKFUN, componentName, LatA, LatB, LonA, LonB, AbsTol, RelTol, fai,
                                               lamda, r, R1Peak, R2Peak, &cachedLatPeaks, &cachedLonPeaks);
    }

    std::vector<std::pair<double, double>> holeLonIntervals;
    if (Lon0s <= Lon0e) {
        holeLonIntervals.push_back({Lon0s, Lon0e});
    } else {

        holeLonIntervals.push_back({LonA, Lon0e});
        holeLonIntervals.push_back({Lon0s, LonB});
    }

    std::vector<std::pair<double, double>> remainLonIntervals;
    remainLonIntervals.push_back({LonA, LonB});

    for (const auto& h0 : holeLonIntervals) {
        const double hLon1 = std::max(LonA, h0.first);
        const double hLon2 = std::min(LonB, h0.second);

        if (!(hLon2 > hLon1)) {
            continue;
        }

        std::vector<std::pair<double, double>> nextIntervals;
        for (const auto& seg : remainLonIntervals) {
            const double a = seg.first;
            const double b = seg.second;

            if (hLon2 <= a || hLon1 >= b) {
                nextIntervals.push_back(seg);
                continue;
            }
            if (hLon1 > a) {
                nextIntervals.push_back({a, hLon1});
            }
            if (hLon2 < b) {
                nextIntervals.push_back({hLon2, b});
            }
        }
        remainLonIntervals.swap(nextIntervals);
    }

    struct InitialRectangle {
        double lat1, lat2, lon1, lon2;
    };
    std::vector<InitialRectangle> baseRectangles = {{LatA, hLat1, LonA, LonB}, {hLat2, LatB, LonA, LonB}};
    for (const auto& seg : remainLonIntervals) {
        baseRectangles.push_back({hLat1, hLat2, seg.first, seg.second});
    }
    std::vector<InitialRectangle> rectangles;
    for (const auto& rect : baseRectangles) {
        if (!(rect.lat2 > rect.lat1 && rect.lon2 > rect.lon1))
            continue;
        if (!horizontalSubsplit) {
            const double mid = 0.5 * (rect.lon1 + rect.lon2);
            rectangles.push_back({rect.lat1, rect.lat2, rect.lon1, mid});
            rectangles.push_back({rect.lat1, rect.lat2, mid, rect.lon2});
        } else {
            const double mid = 0.5 * (rect.lat1 + rect.lat2);
            rectangles.push_back({rect.lat1, mid, rect.lon1, rect.lon2});
            rectangles.push_back({mid, rect.lat2, rect.lon1, rect.lon2});
        }
    }
    const double rad = (4.0 * std::atan(1.0)) / 180.0;
    auto area = [&](const InitialRectangle& rect) {
        return (rect.lon2 - rect.lon1) * rad * (std::sin(rect.lat2 * rad) - std::sin(rect.lat1 * rad));
    };
    double totalArea = 0.0;
    for (const auto& rect : rectangles)
        totalArea += area(rect);
    std::vector<double> pieces;
    pieces.reserve(rectangles.size());
    for (const auto& rect : rectangles) {
        const double localAbsTol = AbsTol * area(rect) / totalArea;
        pieces.push_back(Tesseroid_MSI_GroupPeakIntegral(FUN, PEAKFUN, componentName, rect.lat1, rect.lat2, rect.lon1,
                                                         rect.lon2, localAbsTol, RelTol, fai, lamda, r, R1Peak, R2Peak,
                                                         &cachedLatPeaks, &cachedLonPeaks));
    }
    return Tesseroid_MSI_KahanSum(pieces);
}

inline void Tesseroid_GravityPointEstimate(double Lons, double Lone, double Lats, double Late, double dLon, double dLat,
                                           const std::vector<double>& R2, const std::vector<double>& R1,
                                           const std::vector<double>& rho, double fai, double lamda, double r,
                                           double AbsTol, double RelTol, double* V, double* Vx, double* Vy, double* Vz,
                                           double* Vxx, double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz,
                                           double* Vxxx, double* Vxxy, double* Vxxz, double* Vxyz, double* Vyyx,
                                           double* Vyyy, double* Vyyz, double* Vzzx, double* Vzzy, double* Vzzz,
                                           std::uint32_t componentMask = MSI_All) {

    TesseroidMSIComponentScope componentScope(componentMask);

    double pi, RadianCorrection;
    double VTarget1, VxTarget1, VyTarget1, VzTarget1, VxxTarget1, VxyTarget1, VyyTarget1, VzxTarget1, VzyTarget1,
        VzzTarget1, VxxxTarget1, VxxyTarget1, VxxzTarget1, VxyzTarget1, VyyxTarget1, VyyyTarget1, VyyzTarget1,
        VzzxTarget1, VzzyTarget1, VzzzTarget1;
    double VTarget2, VxTarget2, VyTarget2, VzTarget2, VxxTarget2, VxyTarget2, VyyTarget2, VzxTarget2, VzyTarget2,
        VzzTarget2, VxxxTarget2, VxxyTarget2, VxxzTarget2, VxyzTarget2, VyyxTarget2, VyyyTarget2, VyyzTarget2,
        VzzxTarget2, VzzyTarget2, VzzzTarget2;
    double VSphericalShell, VxSphericalShell, VySphericalShell, VzSphericalShell, VxxSphericalShell, VxySphericalShell,
        VyySphericalShell, VzxSphericalShell, VzySphericalShell, VzzSphericalShell, VxxxSphericalShell,
        VxxySphericalShell, VxxzSphericalShell, VxyzSphericalShell, VyyxSphericalShell, VyyySphericalShell,
        VyyzSphericalShell, VzzxSphericalShell, VzzySphericalShell, VzzzSphericalShell;

    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_V;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vx, func_Vy, func_Vz;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vxx, func_Vxy, func_Vyy, func_Vzx, func_Vzy, func_Vzz;
    std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                const Eigen::Matrix<double, 14, 14>&)>
        func_Vxxx, func_Vxxy, func_Vxxz, func_Vxyz, func_Vyyx, func_Vyyy, func_Vyyz, func_Vzzx, func_Vzzy, func_Vzzz;

    TesseroidMSIPeakFunction peak_func_V;
    TesseroidMSIPeakFunction peak_func_Vx, peak_func_Vy, peak_func_Vz;
    TesseroidMSIPeakFunction peak_func_Vxx, peak_func_Vxy, peak_func_Vyy, peak_func_Vzx, peak_func_Vzy, peak_func_Vzz;
    TesseroidMSIPeakFunction peak_func_Vxxx, peak_func_Vxxy, peak_func_Vxxz, peak_func_Vxyz, peak_func_Vyyx,
        peak_func_Vyyy, peak_func_Vyyz, peak_func_Vzzx, peak_func_Vzzy, peak_func_Vzzz;

    pi = 4.0 * atan(1.0);
    RadianCorrection = (2.0 * pi * pi) / (180.0 * 360.0);

    if (lamda < -180.0) {
        lamda += 360.0;
    } else if (lamda >= 180.0) {
        lamda -= 360.0;
    }

    const double dLonSplit = dLon;
    const double dLatSplit = dLat;

    auto NormalizeLon = [](double lon) -> double {
        while (lon < -180.0)
            lon += 360.0;
        while (lon >= 180.0)
            lon -= 360.0;
        return lon;
    };

    double Lon0s, Lon0e, Lat0s, Lat0e;

    if (std::abs(fai - 90.0) < dLatSplit) {
        Lon0s = -180.0;
        Lon0e = 180.0;
        Lat0s = 90.0 - dLatSplit;
        Lat0e = 90.0;
    } else if (std::abs(fai + 90.0) < dLatSplit) {
        Lon0s = -180.0;
        Lon0e = 180.0;
        Lat0s = -90.0;
        Lat0e = -90.0 + dLatSplit;
    } else {
        Lat0s = fai - 0.5 * dLatSplit;
        Lat0e = fai + 0.5 * dLatSplit;

        if (Lat0s < -90.0) {
            Lat0s = -90.0;
            Lat0e = -90.0 + dLatSplit;
        }
        if (Lat0e > 90.0) {
            Lat0e = 90.0;
            Lat0s = 90.0 - dLatSplit;
        }

        Lon0s = NormalizeLon(lamda - 0.5 * dLonSplit);
        Lon0e = NormalizeLon(lamda + 0.5 * dLonSplit);
    }

    func_V = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelV(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                        Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                         Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                         Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                         Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVyy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                          Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxxx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxxy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxxz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxxz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vxyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVxyz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vyyx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVyyx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vyyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVyyy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vyyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVyyz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzzx(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzzy(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };
    func_Vzzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return Tesseroid_SurfaceKernelVzzz(R2, R1, rho, FaiI, LamdaI, r, fai, lamda, Lons, Lone, Lats, Late, dLon, dLat,
                                           Lon0s, Lon0e, Lat0s, Lat0e);
    };

    const double R2PeakValue = sphinterp::SphBilinearInterpPoint(Lons, Lone, Lats, Late, dLon, dLat, R2, lamda, fai);
    const double R1PeakValue = sphinterp::SphBilinearInterpPoint(Lons, Lone, Lats, Late, dLon, dLat, R1, lamda, fai);

    auto makePeakFun = [&](auto kernel) -> TesseroidMSIPeakFunction {
        return [=](double FaiI, double LamdaI) {
            double Tx, Ty, SinPsi, CosPsi;
            surfacekernel_detail::LocalGeometry(FaiI, LamdaI, fai, lamda, Tx, Ty, SinPsi, CosPsi);
            return std::cos(FaiI * Phithreshold::Deg2Rad) *
                   kernel(R2PeakValue / r, R1PeakValue / r, Tx, Ty, SinPsi, CosPsi);
        };
    };

    peak_func_V = makePeakFun(surfacekernel_detail::KV);
    peak_func_Vx = makePeakFun(surfacekernel_detail::KVx);
    peak_func_Vy = makePeakFun(surfacekernel_detail::KVy);
    peak_func_Vz = makePeakFun(surfacekernel_detail::KVz);
    peak_func_Vxx = makePeakFun(surfacekernel_detail::KVxx);
    peak_func_Vxy = makePeakFun(surfacekernel_detail::KVxy);
    peak_func_Vyy = makePeakFun(surfacekernel_detail::KVyy);
    peak_func_Vzx = makePeakFun(surfacekernel_detail::KVzx);
    peak_func_Vzy = makePeakFun(surfacekernel_detail::KVzy);
    peak_func_Vzz = makePeakFun(surfacekernel_detail::KVzz);
    peak_func_Vxxx = makePeakFun(surfacekernel_detail::KVxxx);
    peak_func_Vxxy = makePeakFun(surfacekernel_detail::KVxxy);
    peak_func_Vxxz = makePeakFun(surfacekernel_detail::KVxxz);
    peak_func_Vxyz = makePeakFun(surfacekernel_detail::KVxyz);
    peak_func_Vyyx = makePeakFun(surfacekernel_detail::KVyyx);
    peak_func_Vyyy = makePeakFun(surfacekernel_detail::KVyyy);
    peak_func_Vyyz = makePeakFun(surfacekernel_detail::KVyyz);
    peak_func_Vzzx = makePeakFun(surfacekernel_detail::KVzzx);
    peak_func_Vzzy = makePeakFun(surfacekernel_detail::KVzzy);
    peak_func_Vzzz = makePeakFun(surfacekernel_detail::KVzzz);

    VTarget1 = integral2t_MMSI_Peak(func_V, peak_func_V, "V", Lats - dLat / 2.0, Late + dLat / 2.0, Lons - dLon / 2.0,
                                    Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r,
                                    R1PeakValue, R2PeakValue);
    VxTarget1 = integral2t_MMSI_Peak(func_Vx, peak_func_Vx, "Vx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                     Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                     fai, lamda, r, R1PeakValue, R2PeakValue);
    VyTarget1 = integral2t_MMSI_Peak(func_Vy, peak_func_Vy, "Vy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                     Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                     fai, lamda, r, R1PeakValue, R2PeakValue);
    VzTarget1 = integral2t_MMSI_Peak(func_Vz, peak_func_Vz, "Vz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                     Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                     fai, lamda, r, R1PeakValue, R2PeakValue);
    VxxTarget1 = integral2t_MMSI_Peak(func_Vxx, peak_func_Vxx, "Vxx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VxyTarget1 = integral2t_MMSI_Peak(func_Vxy, peak_func_Vxy, "Vxy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VyyTarget1 = integral2t_MMSI_Peak(func_Vyy, peak_func_Vyy, "Vyy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VzxTarget1 = integral2t_MMSI_Peak(func_Vzx, peak_func_Vzx, "Vzx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VzyTarget1 = integral2t_MMSI_Peak(func_Vzy, peak_func_Vzy, "Vzy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VzzTarget1 = integral2t_MMSI_Peak(func_Vzz, peak_func_Vzz, "Vzz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                      Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                      fai, lamda, r, R1PeakValue, R2PeakValue);
    VxxxTarget1 = integral2t_MMSI_Peak(func_Vxxx, peak_func_Vxxx, "Vxxx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VxxyTarget1 = integral2t_MMSI_Peak(func_Vxxy, peak_func_Vxxy, "Vxxy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VxxzTarget1 = integral2t_MMSI_Peak(func_Vxxz, peak_func_Vxxz, "Vxxz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VxyzTarget1 = integral2t_MMSI_Peak(func_Vxyz, peak_func_Vxyz, "Vxyz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VyyxTarget1 = integral2t_MMSI_Peak(func_Vyyx, peak_func_Vyyx, "Vyyx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VyyyTarget1 = integral2t_MMSI_Peak(func_Vyyy, peak_func_Vyyy, "Vyyy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VyyzTarget1 = integral2t_MMSI_Peak(func_Vyyz, peak_func_Vyyz, "Vyyz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VzzxTarget1 = integral2t_MMSI_Peak(func_Vzzx, peak_func_Vzzx, "Vzzx", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VzzyTarget1 = integral2t_MMSI_Peak(func_Vzzy, peak_func_Vzzy, "Vzzy", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);
    VzzzTarget1 = integral2t_MMSI_Peak(func_Vzzz, peak_func_Vzzz, "Vzzz", Lats - dLat / 2.0, Late + dLat / 2.0,
                                       Lons - dLon / 2.0, Lone + dLon / 2.0, Lat0s, Lat0e, Lon0s, Lon0e, AbsTol, RelTol,
                                       fai, lamda, r, R1PeakValue, R2PeakValue);

    VTarget1 = VTarget1 * r * r * RadianCorrection;

    VxTarget1 = VxTarget1 * r * RadianCorrection;
    VyTarget1 = VyTarget1 * r * RadianCorrection;
    VzTarget1 = VzTarget1 * r * RadianCorrection;

    VxxTarget1 = VxxTarget1 * RadianCorrection;
    VxyTarget1 = VxyTarget1 * RadianCorrection;
    VyyTarget1 = VyyTarget1 * RadianCorrection;
    VzxTarget1 = VzxTarget1 * RadianCorrection;
    VzyTarget1 = VzyTarget1 * RadianCorrection;
    VzzTarget1 = VzzTarget1 * RadianCorrection;

    VxxxTarget1 = VxxxTarget1 / r * RadianCorrection;
    VxxyTarget1 = VxxyTarget1 / r * RadianCorrection;
    VxxzTarget1 = VxxzTarget1 / r * RadianCorrection;
    VxyzTarget1 = VxyzTarget1 / r * RadianCorrection;
    VyyxTarget1 = VyyxTarget1 / r * RadianCorrection;
    VyyyTarget1 = VyyyTarget1 / r * RadianCorrection;
    VyyzTarget1 = VyyzTarget1 / r * RadianCorrection;
    VzzxTarget1 = VzzxTarget1 / r * RadianCorrection;
    VzzyTarget1 = VzzyTarget1 / r * RadianCorrection;
    VzzzTarget1 = VzzzTarget1 / r * RadianCorrection;

    if (!(lamda >= (Lons - dLon / 2) && lamda <= (Lone + dLon / 2) && fai >= (Lats - dLat / 2) &&
          fai <= (Late + dLat / 2))) {

        *V = VTarget1;
        *Vx = VxTarget1;
        *Vy = VyTarget1;
        *Vz = VzTarget1;
        *Vxx = VxxTarget1;
        *Vxy = VxyTarget1;
        *Vyy = VyyTarget1;
        *Vzx = VzxTarget1;
        *Vzy = VzyTarget1;
        *Vzz = VzzTarget1;
        *Vxxx = VxxxTarget1;
        *Vxxy = VxxyTarget1;
        *Vxxz = VxxzTarget1;
        *Vxyz = VxyzTarget1;
        *Vyyx = VyyxTarget1;
        *Vyyy = VyyyTarget1;
        *Vyyz = VyyzTarget1;
        *Vzzx = VzzxTarget1;
        *Vzzy = VzzyTarget1;
        *Vzzz = VzzzTarget1;

        return;
    }

    const double R2DummyValue = sphinterp::SphBilinearInterpPoint(Lons, Lone, Lats, Late, dLon, dLat, R2, lamda, fai);

    const double R1DummyValue = sphinterp::SphBilinearInterpPoint(Lons, Lone, Lats, Late, dLon, dLat, R1, lamda, fai);

    const double rhoDummyValue = sphinterp::SphBilinearInterpPoint(Lons, Lone, Lats, Late, dLon, dLat, rho, lamda, fai);

    func_V = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KV);
    };
    func_Vx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVx);
    };
    func_Vy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVy);
    };
    func_Vz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVz);
    };
    func_Vxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxx);
    };
    func_Vxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxy);
    };
    func_Vyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVyy);
    };
    func_Vzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzx);
    };
    func_Vzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzy);
    };
    func_Vzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzz);
    };
    func_Vxxx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxxx);
    };
    func_Vxxy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxxy);
    };
    func_Vxxz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxxz);
    };
    func_Vxyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVxyz);
    };
    func_Vyyx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVyyx);
    };
    func_Vyyy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVyyy);
    };
    func_Vyyz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVyyz);
    };
    func_Vzzx = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzzx);
    };
    func_Vzzy = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzzy);
    };
    func_Vzzz = [&](const Eigen::Matrix<double, 14, 14>& FaiI, const Eigen::Matrix<double, 14, 14>& LamdaI) {
        return surfacekernel_detail::EvaluateSurfaceKernelConstant(R2DummyValue, R1DummyValue, rhoDummyValue, FaiI,
                                                                   LamdaI, r, fai, lamda, Lon0s, Lon0e, Lat0s, Lat0e,
                                                                   surfacekernel_detail::KVzzz);
    };

    VTarget2 = integral2t_MMSI_Peak(func_V, peak_func_V, "V", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s, Lon0e,
                                    AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxTarget2 = integral2t_MMSI_Peak(func_Vx, peak_func_Vx, "Vx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                     Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VyTarget2 = integral2t_MMSI_Peak(func_Vy, peak_func_Vy, "Vy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                     Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzTarget2 = integral2t_MMSI_Peak(func_Vz, peak_func_Vz, "Vz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                     Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxxTarget2 = integral2t_MMSI_Peak(func_Vxx, peak_func_Vxx, "Vxx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxyTarget2 = integral2t_MMSI_Peak(func_Vxy, peak_func_Vxy, "Vxy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VyyTarget2 = integral2t_MMSI_Peak(func_Vyy, peak_func_Vyy, "Vyy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzxTarget2 = integral2t_MMSI_Peak(func_Vzx, peak_func_Vzx, "Vzx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzyTarget2 = integral2t_MMSI_Peak(func_Vzy, peak_func_Vzy, "Vzy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzzTarget2 = integral2t_MMSI_Peak(func_Vzz, peak_func_Vzz, "Vzz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e, Lon0s,
                                      Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxxxTarget2 = integral2t_MMSI_Peak(func_Vxxx, peak_func_Vxxx, "Vxxx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxxyTarget2 = integral2t_MMSI_Peak(func_Vxxy, peak_func_Vxxy, "Vxxy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxxzTarget2 = integral2t_MMSI_Peak(func_Vxxz, peak_func_Vxxz, "Vxxz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VxyzTarget2 = integral2t_MMSI_Peak(func_Vxyz, peak_func_Vxyz, "Vxyz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VyyxTarget2 = integral2t_MMSI_Peak(func_Vyyx, peak_func_Vyyx, "Vyyx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VyyyTarget2 = integral2t_MMSI_Peak(func_Vyyy, peak_func_Vyyy, "Vyyy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VyyzTarget2 = integral2t_MMSI_Peak(func_Vyyz, peak_func_Vyyz, "Vyyz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzzxTarget2 = integral2t_MMSI_Peak(func_Vzzx, peak_func_Vzzx, "Vzzx", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzzyTarget2 = integral2t_MMSI_Peak(func_Vzzy, peak_func_Vzzy, "Vzzy", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);
    VzzzTarget2 = integral2t_MMSI_Peak(func_Vzzz, peak_func_Vzzz, "Vzzz", -90.0, 90.0, -180.0, 180.0, Lat0s, Lat0e,
                                       Lon0s, Lon0e, AbsTol, RelTol, fai, lamda, r, R1PeakValue, R2PeakValue, true);

    VTarget2 = VTarget2 * r * r * RadianCorrection;

    VxTarget2 = VxTarget2 * r * RadianCorrection;
    VyTarget2 = VyTarget2 * r * RadianCorrection;
    VzTarget2 = VzTarget2 * r * RadianCorrection;

    VxxTarget2 = VxxTarget2 * RadianCorrection;
    VxyTarget2 = VxyTarget2 * RadianCorrection;
    VyyTarget2 = VyyTarget2 * RadianCorrection;
    VzxTarget2 = VzxTarget2 * RadianCorrection;
    VzyTarget2 = VzyTarget2 * RadianCorrection;
    VzzTarget2 = VzzTarget2 * RadianCorrection;

    VxxxTarget2 = VxxxTarget2 / r * RadianCorrection;
    VxxyTarget2 = VxxyTarget2 / r * RadianCorrection;
    VxxzTarget2 = VxxzTarget2 / r * RadianCorrection;
    VxyzTarget2 = VxyzTarget2 / r * RadianCorrection;
    VyyxTarget2 = VyyxTarget2 / r * RadianCorrection;
    VyyyTarget2 = VyyyTarget2 / r * RadianCorrection;
    VyyzTarget2 = VyyzTarget2 / r * RadianCorrection;
    VzzxTarget2 = VzzxTarget2 / r * RadianCorrection;
    VzzyTarget2 = VzzyTarget2 / r * RadianCorrection;
    VzzzTarget2 = VzzzTarget2 / r * RadianCorrection;

    if (r >= R2DummyValue) {
        const double radialVolume =
            (R2DummyValue - R1DummyValue) *
            (R2DummyValue * R2DummyValue + R2DummyValue * R1DummyValue + R1DummyValue * R1DummyValue);
        double M0 = 4.0 * pi / 3.0 * radialVolume;
        VSphericalShell = M0 / r;
        VzSphericalShell = -M0 / (r * r);
        VxxSphericalShell = -M0 / (r * r * r);
        VyySphericalShell = -M0 / (r * r * r);
        VzzSphericalShell = 2 * M0 / (r * r * r);
        VxxzSphericalShell = 3 * M0 / (r * r * r * r);
        VyyzSphericalShell = 3 * M0 / (r * r * r * r);
        VzzzSphericalShell = -6 * M0 / (r * r * r * r);
    } else if (r <= R1DummyValue) {
        VSphericalShell = 2 * pi * (R2DummyValue - R1DummyValue) * (R2DummyValue + R1DummyValue);
        VzSphericalShell = 0;
        VxxSphericalShell = 0;
        VyySphericalShell = 0;
        VzzSphericalShell = 0;
        VxxzSphericalShell = 0;
        VyyzSphericalShell = 0;
        VzzzSphericalShell = 0;
    } else {
        const double h = r - R1DummyValue;
        const double radialDifference = h * (r * r + r * R1DummyValue + R1DummyValue * R1DummyValue);
        VSphericalShell = 2 * pi *
                          ((R2DummyValue - R1DummyValue) * (R2DummyValue + R1DummyValue) -
                           h * h * (r + 2 * R1DummyValue) / (3.0 * r));
        VzSphericalShell = -4 * pi / 3.0 * radialDifference / (r * r);
        VxxSphericalShell = -4 * pi / 3.0 * radialDifference / (r * r * r);
        VyySphericalShell = VxxSphericalShell;
        VzzSphericalShell = -4 * pi / 3.0 * (1 + 2 * pow(R1DummyValue, 3) / (r * r * r));
        VxxzSphericalShell = -4 * pi * pow(R1DummyValue, 3) / (r * r * r * r);
        VyyzSphericalShell = VxxzSphericalShell;
        VzzzSphericalShell = 8 * pi * pow(R1DummyValue, 3) / (r * r * r * r);
    }

    VSphericalShell *= rhoDummyValue;
    VzSphericalShell *= rhoDummyValue;
    VxxSphericalShell *= rhoDummyValue;
    VyySphericalShell *= rhoDummyValue;
    VzzSphericalShell *= rhoDummyValue;
    VxxzSphericalShell *= rhoDummyValue;
    VyyzSphericalShell *= rhoDummyValue;
    VzzzSphericalShell *= rhoDummyValue;

    VxSphericalShell = 0;
    VySphericalShell = 0;

    VxySphericalShell = 0;
    VzxSphericalShell = 0;
    VzySphericalShell = 0;

    VxxxSphericalShell = 0;
    VxxySphericalShell = 0;
    VxyzSphericalShell = 0;
    VyyxSphericalShell = 0;
    VyyySphericalShell = 0;
    VzzxSphericalShell = 0;
    VzzySphericalShell = 0;

    *V = VTarget1 + VSphericalShell - VTarget2;

    *Vx = VxTarget1 + VxSphericalShell - VxTarget2;
    *Vy = VyTarget1 + VySphericalShell - VyTarget2;
    *Vz = VzTarget1 + VzSphericalShell - VzTarget2;

    *Vxx = VxxTarget1 + VxxSphericalShell - VxxTarget2;
    *Vxy = VxyTarget1 + VxySphericalShell - VxyTarget2;
    *Vyy = VyyTarget1 + VyySphericalShell - VyyTarget2;
    *Vzx = VzxTarget1 + VzxSphericalShell - VzxTarget2;
    *Vzy = VzyTarget1 + VzySphericalShell - VzyTarget2;
    *Vzz = VzzTarget1 + VzzSphericalShell - VzzTarget2;

    *Vxxx = VxxxTarget1 + VxxxSphericalShell - VxxxTarget2;
    *Vxxy = VxxyTarget1 + VxxySphericalShell - VxxyTarget2;
    *Vxxz = VxxzTarget1 + VxxzSphericalShell - VxxzTarget2;
    *Vxyz = VxyzTarget1 + VxyzSphericalShell - VxyzTarget2;
    *Vyyx = VyyxTarget1 + VyyxSphericalShell - VyyxTarget2;
    *Vyyy = VyyyTarget1 + VyyySphericalShell - VyyyTarget2;
    *Vyyz = VyyzTarget1 + VyyzSphericalShell - VyyzTarget2;
    *Vzzx = VzzxTarget1 + VzzxSphericalShell - VzzxTarget2;
    *Vzzy = VzzyTarget1 + VzzySphericalShell - VzzyTarget2;
    *Vzzz = VzzzTarget1 + VzzzSphericalShell - VzzzTarget2;

    return;
}

inline void Tesseroid_MagneticPointEstimate(double Lons, double Lone, double Lats, double Late, double dLon,
                                            double dLat, const std::vector<double>& R2, const std::vector<double>& R1,
                                            const std::vector<double>& Mx, const std::vector<double>& My,
                                            const std::vector<double>& Mz, double fai, double lamda, double r,
                                            double AbsTol, double RelTol, double* V, double* Vx, double* Vy, double* Vz,
                                            double* Vxx, double* Vxy, double* Vyy, double* Vzx, double* Vzy,
                                            double* Vzz) {

    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;
    const long long NumSources = NumLat * NumLon;
    const double pi = 4 * std::atan(1.0);

    std::vector<double> MxLocal(NumSources);
    std::vector<double> MyLocal(NumSources);
    std::vector<double> MzLocal(NumSources);

    const double cosDataLat = std::cos(fai / 180.0 * pi);
    const double sinDataLat = std::sin(fai / 180.0 * pi);

    long long index = 0;
    for (long long i = 0; i < NumLon; ++i) {
        const double sourceLon = Lons + i * dLon;
        const double beta = (sourceLon - lamda) / 180.0 * pi;
        const double cosBeita = std::cos(beta);
        const double sinBeita = std::sin(beta);
        for (long long j = 0; j < NumLat; ++j, ++index) {
            const double sourceLat = Lats + j * dLat;
            const double latRad = sourceLat / 180.0 * pi;
            const double cosLat = std::cos(latRad);
            const double sinLat = std::sin(latRad);

            MxLocal[index] = (cosBeita * sinDataLat * sinLat + cosDataLat * cosLat) * Mx[index] +
                             (sinBeita * sinDataLat) * My[index] -
                             (cosBeita * sinDataLat * cosLat - cosDataLat * sinLat) * Mz[index];

            MyLocal[index] = (-sinBeita * sinLat) * Mx[index] + cosBeita * My[index] + (sinBeita * cosLat) * Mz[index];

            MzLocal[index] = (-(cosBeita * cosDataLat * sinLat - sinDataLat * cosLat)) * Mx[index] -
                             (sinBeita * cosDataLat) * My[index] +
                             (cosBeita * cosDataLat * cosLat + sinDataLat * sinLat) * Mz[index];
        }
    }

    double MxV, MxVx, MxVy, MxVz, MxVxx, MxVxy, MxVyy, MxVzx, MxVzy, MxVzz, MxVxxx, MxVxxy, MxVxxz, MxVxyz, MxVyyx,
        MxVyyy, MxVyyz, MxVzzx, MxVzzy, MxVzzz;
    double MyV, MyVx, MyVy, MyVz, MyVxx, MyVxy, MyVyy, MyVzx, MyVzy, MyVzz, MyVxxx, MyVxxy, MyVxxz, MyVxyz, MyVyyx,
        MyVyyy, MyVyyz, MyVzzx, MyVzzy, MyVzzz;
    double MzV, MzVx, MzVy, MzVz, MzVxx, MzVxy, MzVyy, MzVzx, MzVzy, MzVzz, MzVxxx, MzVxxy, MzVxxz, MzVxyz, MzVyyx,
        MzVyyy, MzVyyz, MzVzzx, MzVzzy, MzVzzz;

    Tesseroid_GravityPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, MxLocal, fai, lamda, r, AbsTol, RelTol,
                                   &MxV, &MxVx, &MxVy, &MxVz, &MxVxx, &MxVxy, &MxVyy, &MxVzx, &MxVzy, &MxVzz, &MxVxxx,
                                   &MxVxxy, &MxVxxz, &MxVxyz, &MxVyyx, &MxVyyy, &MxVyyz, &MxVzzx, &MxVzzy, &MxVzzz,
                                   MSI_Vx | MSI_Vxx | MSI_Vxy | MSI_Vzx | MSI_Vxxx | MSI_Vxxy | MSI_Vyyx | MSI_Vxxz |
                                       MSI_Vxyz | MSI_Vzzx);
    Tesseroid_GravityPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, MyLocal, fai, lamda, r, AbsTol, RelTol,
                                   &MyV, &MyVx, &MyVy, &MyVz, &MyVxx, &MyVxy, &MyVyy, &MyVzx, &MyVzy, &MyVzz, &MyVxxx,
                                   &MyVxxy, &MyVxxz, &MyVxyz, &MyVyyx, &MyVyyy, &MyVyyz, &MyVzzx, &MyVzzy, &MyVzzz,
                                   MSI_Vy | MSI_Vxy | MSI_Vyy | MSI_Vzy | MSI_Vxxy | MSI_Vyyx | MSI_Vyyy | MSI_Vxyz |
                                       MSI_Vyyz | MSI_Vzzy);
    Tesseroid_GravityPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, MzLocal, fai, lamda, r, AbsTol, RelTol,
                                   &MzV, &MzVx, &MzVy, &MzVz, &MzVxx, &MzVxy, &MzVyy, &MzVzx, &MzVzy, &MzVzz, &MzVxxx,
                                   &MzVxxy, &MzVxxz, &MzVxyz, &MzVyyx, &MzVyyy, &MzVyyz, &MzVzzx, &MzVzzy, &MzVzzz,
                                   MSI_Vz | MSI_Vzx | MSI_Vzy | MSI_Vzz | MSI_Vxxz | MSI_Vxyz | MSI_Vyyz | MSI_Vzzx |
                                       MSI_Vzzy | MSI_Vzzz);

    *V = MxVx + MyVy + MzVz;

    *Vx = MxVxx + MyVxy + MzVzx;
    *Vy = MxVxy + MyVyy + MzVzy;
    *Vz = MxVzx + MyVzy + MzVzz;

    *Vxx = MxVxxx + MyVxxy + MzVxxz;
    *Vxy = MxVxxy + MyVyyx + MzVxyz;
    *Vyy = MxVyyx + MyVyyy + MzVyyz;
    *Vzx = MxVxxz + MyVxyz + MzVzzx;
    *Vzy = MxVxyz + MyVyyz + MzVzzy;
    *Vzz = MxVzzx + MyVzzy + MzVzzz;
}

inline void MassShellIntegration(const double Lons, const double Lone, const double Lats, const double Late,
                                 const double dLon, const double dLat, const double* R2In, const double* R1In,
                                 const double* rhoIn, const int NumPoint, const double* Latitude,
                                 const double* Longitude, const double* Radius, const double AbsTol,
                                 const double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                 double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz, double* Vxxx,
                                 double* Vxxy, double* Vxxz, double* Vxyz, double* Vyyx, double* Vyyy, double* Vyyz,
                                 double* Vzzx, double* Vzzy, double* Vzzz) {
    printf("\nEstimating 0-, 1-, 2- and 3- rank gravitational gradient tensor components of the mass shell\n");
    printf("Serial computing mode \n\n");

    if (NumPoint <= 0) {
        printf("\nNo coordinate is included.\n");
        printf("\nCalculation finished: MassShellIntegration.\n\n");
        return;
    }

    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    double Reportbar = 0.05;
    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;

    std::vector<double> R2(R2In, R2In + NumLon * NumLat);
    std::vector<double> R1(R1In, R1In + NumLon * NumLat);
    std::vector<double> rho(rhoIn, rhoIn + NumLon * NumLat);

    TicToc timer;
    timer.tic();

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");
    for (long long i = 0; i < NumPoint; i++) {

        Tesseroid_GravityPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, rho, Latitude[i], Longitude[i],
                                       Radius[i], AbsTol, RelTol, &V[i], &Vx[i], &Vy[i], &Vz[i], &Vxx[i], &Vxy[i],
                                       &Vyy[i], &Vzx[i], &Vzy[i], &Vzz[i], &Vxxx[i], &Vxxy[i], &Vxxz[i], &Vxyz[i],
                                       &Vyyx[i], &Vyyy[i], &Vyyz[i], &Vzzx[i], &Vzzy[i], &Vzzz[i]);

        while ((double)(i + 1) / (double)NumPoint >= Reportbar) {
            printf("|");
            Reportbar += 0.05;
        }
    }

    printf("|");
    std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
    printf("\nCalculation finished: MassShellIntegration.\n\n");
}

inline void MassShellIntegrationOpenMP(const double Lons, const double Lone, const double Lats, const double Late,
                                       const double dLon, const double dLat, const double* R2In, const double* R1In,
                                       const double* rhoIn, const int NumPoint, const double* Latitude,
                                       const double* Longitude, const double* Radius, const double AbsTol,
                                       const double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                       double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz, double* Vxxx,
                                       double* Vxxy, double* Vxxz, double* Vxyz, double* Vyyx, double* Vyyy,
                                       double* Vyyz, double* Vzzx, double* Vzzy, double* Vzzz) {
    printf("\nEstimating 0-, 1-, 2- and 3- rank gravitational gradient tensor components of the mass shell\n");
    printf("OpenMP parallel computing mode \n\n");

    if (NumPoint <= 0) {
        printf("\nNo coordinate is included.\n");
        printf("\nCalculation finished: MassShellIntegrationOpenMP.\n\n");
        return;
    }

    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n", RelTol);
    printf("OpenMP thread number: %i\n\n", omp_get_max_threads());

    double Reportbar = 0.05;
    long long FinishedNum = 0;

    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;

    std::vector<double> R2(R2In, R2In + NumLon * NumLat);
    std::vector<double> R1(R1In, R1In + NumLon * NumLat);
    std::vector<double> rho(rhoIn, rhoIn + NumLon * NumLat);

    TicToc timer;
    timer.tic();

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");

#pragma omp parallel for schedule(dynamic)
    for (long long i = 0; i < NumPoint; i++) {

        Tesseroid_GravityPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, rho, Latitude[i], Longitude[i],
                                       Radius[i], AbsTol, RelTol, &V[i], &Vx[i], &Vy[i], &Vz[i], &Vxx[i], &Vxy[i],
                                       &Vyy[i], &Vzx[i], &Vzy[i], &Vzz[i], &Vxxx[i], &Vxxy[i], &Vxxz[i], &Vxyz[i],
                                       &Vyyx[i], &Vyyy[i], &Vyyz[i], &Vzzx[i], &Vzzy[i], &Vzzz[i]);

#pragma omp atomic
        FinishedNum++;

#pragma omp critical(MassShellIntegrationOpenMPProgress)
        {
            while ((double)FinishedNum / (double)NumPoint >= Reportbar) {
                printf("|");
                Reportbar += 0.05;
            }
        }
    }

    printf("|");
    std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
    printf("\nCalculation finished: MassShellIntegrationOpenMP.\n\n");
}

inline void MassShellIntegrationMPI(const double Lons, const double Lone, const double Lats, const double Late,
                                    const double dLon, const double dLat, const double* R2In, const double* R1In,
                                    const double* rhoIn, const int NumPoint, const double* Latitude,
                                    const double* Longitude, const double* Radius, const double AbsTol,
                                    const double RelTol, double* V, double* Vx, double* Vy, double* Vz, double* Vxx,
                                    double* Vxy, double* Vyy, double* Vzx, double* Vzy, double* Vzz, double* Vxxx,
                                    double* Vxxy, double* Vxxz, double* Vxyz, double* Vyyx, double* Vyyy, double* Vyyz,
                                    double* Vzzx, double* Vzzy, double* Vzzz) {
    int rank, nprocs;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if (rank == 0) {
        printf("\nEstimating 0-, 1-, 2- and 3- rank gravitational gradient tensor components of the mass shell\n");
        printf("MPI parallel computing mode \n\n");
    }

    if (NumPoint <= 0) {
        if (rank == 0) {
            printf("\nNo coordinate is included.\n");
            printf("\nCalculation finished: MassShellIntegrationMPI.\n\n");
        }
        return;
    }

    if (rank == 0) {
        printf("%i coordinate(s) included.\n", NumPoint);
        printf("Absolute tolerance is set to: %e\n", AbsTol);
        printf("Relative tolerance is set to: %e\n", RelTol);
        printf("MPI process number: %i\n\n", nprocs);
    }

    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;
    const long long NumModel = NumLon * NumLat;

    std::vector<double> R2(NumModel);
    std::vector<double> R1(NumModel);
    std::vector<double> rho(NumModel);

    std::vector<double> Lat(NumPoint);
    std::vector<double> Lon(NumPoint);
    std::vector<double> Rad(NumPoint);

    if (rank == 0) {
        for (long long i = 0; i < NumModel; i++) {
            R2[i] = R2In[i];
            R1[i] = R1In[i];
            rho[i] = rhoIn[i];
        }

        for (int i = 0; i < NumPoint; i++) {
            Lat[i] = Latitude[i];
            Lon[i] = Longitude[i];
            Rad[i] = Radius[i];
        }
    }

    MPI_Bcast(R2.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(R1.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(rho.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Bcast(Lat.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Lon.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Rad.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    std::vector<int> DataList(nprocs);
    std::vector<int> VectorShiftList(nprocs);
    MPIDistribute(NumPoint, DataList.data(), VectorShiftList.data());

    const int LocalNumPoint = DataList[rank];
    const int PointShift = VectorShiftList[rank];

    std::vector<double> VLocal(LocalNumPoint);
    std::vector<double> VxLocal(LocalNumPoint), VyLocal(LocalNumPoint), VzLocal(LocalNumPoint);
    std::vector<double> VxxLocal(LocalNumPoint), VxyLocal(LocalNumPoint), VyyLocal(LocalNumPoint),
        VzxLocal(LocalNumPoint), VzyLocal(LocalNumPoint), VzzLocal(LocalNumPoint);
    std::vector<double> VxxxLocal(LocalNumPoint), VxxyLocal(LocalNumPoint), VxxzLocal(LocalNumPoint),
        VxyzLocal(LocalNumPoint), VyyxLocal(LocalNumPoint), VyyyLocal(LocalNumPoint), VyyzLocal(LocalNumPoint),
        VzzxLocal(LocalNumPoint), VzzyLocal(LocalNumPoint), VzzzLocal(LocalNumPoint);

    MPI_Barrier(MPI_COMM_WORLD);

    TicToc timer;
    if (rank == 0) {
        timer.tic();
    }

    for (int i = 0; i < LocalNumPoint; i++) {

        const int GlobalIdx = PointShift + i;

        Tesseroid_GravityPointEstimate(
            Lons, Lone, Lats, Late, dLon, dLat, R2, R1, rho, Lat[GlobalIdx], Lon[GlobalIdx], Rad[GlobalIdx], AbsTol,
            RelTol, &VLocal[i], &VxLocal[i], &VyLocal[i], &VzLocal[i], &VxxLocal[i], &VxyLocal[i], &VyyLocal[i],
            &VzxLocal[i], &VzyLocal[i], &VzzLocal[i], &VxxxLocal[i], &VxxyLocal[i], &VxxzLocal[i], &VxyzLocal[i],
            &VyyxLocal[i], &VyyyLocal[i], &VyyzLocal[i], &VzzxLocal[i], &VzzyLocal[i], &VzzzLocal[i]);
    }

    MPI_Gatherv(VLocal.data(), LocalNumPoint, MPI_DOUBLE, V, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Gatherv(VxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Gatherv(VxxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VxyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VyyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vyy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Gatherv(VxxxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxxx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VxxyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxxy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VxxzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxxz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VxyzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxyz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vyyx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vyyy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VyyzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vyyz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzzx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzzy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);
    MPI_Gatherv(VzzzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzzz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE,
                0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {
        std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
        printf("\nCalculation finished: MassShellIntegrationMPI.\n\n");
    }
}

inline void MagnetizationShellIntegration(const double Lons, const double Lone, const double Lats, const double Late,
                                          const double dLon, const double dLat, const double* R2In, const double* R1In,
                                          const double* MxIn, const double* MyIn, const double* MzIn,
                                          const int NumPoint, const double* Latitude, const double* Longitude,
                                          const double* Radius, const double AbsTol, const double RelTol, double* V,
                                          double* Vx, double* Vy, double* Vz, double* Vxx, double* Vxy, double* Vyy,
                                          double* Vzx, double* Vzy, double* Vzz) {
    printf("\nEstimating 0-, 1- and 2- rank magnetic gradient tensor components of the magnetization shell\n");
    printf("Serial computing mode \n\n");

    if (NumPoint <= 0) {
        printf("\nNo coordinate is included.\n");
        printf("\nCalculation finished: MagnetizationShellIntegration.\n\n");
        return;
    }

    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n\n", RelTol);

    double Reportbar = 0.05;
    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;

    std::vector<double> R2(R2In, R2In + NumLon * NumLat);
    std::vector<double> R1(R1In, R1In + NumLon * NumLat);
    std::vector<double> Mx(MxIn, MxIn + NumLon * NumLat);
    std::vector<double> My(MyIn, MyIn + NumLon * NumLat);
    std::vector<double> Mz(MzIn, MzIn + NumLon * NumLat);

    TicToc timer;
    timer.tic();

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");
    for (long long i = 0; i < NumPoint; i++) {

        Tesseroid_MagneticPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, Mx, My, Mz, Latitude[i],
                                        Longitude[i], Radius[i], AbsTol, RelTol, &V[i], &Vx[i], &Vy[i], &Vz[i], &Vxx[i],
                                        &Vxy[i], &Vyy[i], &Vzx[i], &Vzy[i], &Vzz[i]);

        while ((double)(i + 1) / (double)NumPoint >= Reportbar) {
            printf("|");
            Reportbar += 0.05;
        }
    }

    printf("|");
    std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
    printf("\nCalculation finished: MagnetizationShellIntegration.\n\n");
}

inline void MagnetizationShellIntegrationOpenMP(const double Lons, const double Lone, const double Lats,
                                                const double Late, const double dLon, const double dLat,
                                                const double* R2In, const double* R1In, const double* MxIn,
                                                const double* MyIn, const double* MzIn, const int NumPoint,
                                                const double* Latitude, const double* Longitude, const double* Radius,
                                                const double AbsTol, const double RelTol, double* V, double* Vx,
                                                double* Vy, double* Vz, double* Vxx, double* Vxy, double* Vyy,
                                                double* Vzx, double* Vzy, double* Vzz) {
    printf("\nEstimating 0-, 1- and 2- rank magnetic gradient tensor components of the magnetization shell\n");
    printf("OpenMP parallel computing mode \n\n");

    if (NumPoint <= 0) {
        printf("\nNo coordinate is included.\n");
        printf("\nCalculation finished: MagnetizationShellIntegrationOpenMP.\n\n");
        return;
    }

    printf("%i coordinate(s) included.\n", NumPoint);
    printf("Absolute tolerance is set to: %e\n", AbsTol);
    printf("Relative tolerance is set to: %e\n", RelTol);
    printf("OpenMP thread number: %i\n\n", omp_get_max_threads());

    double Reportbar = 0.05;
    long long FinishedNum = 0;

    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;

    std::vector<double> R2(R2In, R2In + NumLon * NumLat);
    std::vector<double> R1(R1In, R1In + NumLon * NumLat);
    std::vector<double> Mx(MxIn, MxIn + NumLon * NumLat);
    std::vector<double> My(MyIn, MyIn + NumLon * NumLat);
    std::vector<double> Mz(MzIn, MzIn + NumLon * NumLat);

    TicToc timer;
    timer.tic();

    printf("\nTotal progress :   |||||||||||||||||||| \nCurrent progress : ");

#pragma omp parallel for schedule(dynamic)
    for (long long i = 0; i < NumPoint; i++) {

        Tesseroid_MagneticPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, Mx, My, Mz, Latitude[i],
                                        Longitude[i], Radius[i], AbsTol, RelTol, &V[i], &Vx[i], &Vy[i], &Vz[i], &Vxx[i],
                                        &Vxy[i], &Vyy[i], &Vzx[i], &Vzy[i], &Vzz[i]);

#pragma omp atomic
        FinishedNum++;

#pragma omp critical(MagnetizationShellIntegrationOpenMPProgress)
        {
            while ((double)FinishedNum / (double)NumPoint >= Reportbar) {
                printf("|");
                Reportbar += 0.05;
            }
        }
    }

    printf("|");
    std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
    printf("\nCalculation finished: MagnetizationShellIntegrationOpenMP.\n\n");
}

inline void MagnetizationShellIntegrationMPI(const double Lons, const double Lone, const double Lats, const double Late,
                                             const double dLon, const double dLat, const double* R2In,
                                             const double* R1In, const double* MxIn, const double* MyIn,
                                             const double* MzIn, const int NumPoint, const double* Latitude,
                                             const double* Longitude, const double* Radius, const double AbsTol,
                                             const double RelTol, double* V, double* Vx, double* Vy, double* Vz,
                                             double* Vxx, double* Vxy, double* Vyy, double* Vzx, double* Vzy,
                                             double* Vzz) {
    int rank, nprocs;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if (rank == 0) {
        printf("\nEstimating 0-, 1- and 2- rank magnetic gradient tensor components of the magnetization shell\n");
        printf("MPI parallel computing mode \n\n");
    }

    if (NumPoint <= 0) {
        if (rank == 0) {
            printf("\nNo coordinate is included.\n");
            printf("\nCalculation finished: MagnetizationShellIntegrationMPI.\n\n");
        }
        return;
    }

    if (rank == 0) {
        printf("%i coordinate(s) included.\n", NumPoint);
        printf("Absolute tolerance is set to: %e\n", AbsTol);
        printf("Relative tolerance is set to: %e\n", RelTol);
        printf("MPI process number: %i\n\n", nprocs);
    }

    const long long NumLat = static_cast<long long>(std::llround((Late - Lats) / dLat)) + 1;
    const long long NumLon = static_cast<long long>(std::llround((Lone - Lons) / dLon)) + 1;
    const long long NumModel = NumLon * NumLat;

    std::vector<double> R2(NumModel);
    std::vector<double> R1(NumModel);
    std::vector<double> Mx(NumModel);
    std::vector<double> My(NumModel);
    std::vector<double> Mz(NumModel);

    std::vector<double> Lat(NumPoint);
    std::vector<double> Lon(NumPoint);
    std::vector<double> Rad(NumPoint);

    if (rank == 0) {
        for (long long i = 0; i < NumModel; i++) {
            R2[i] = R2In[i];
            R1[i] = R1In[i];
            Mx[i] = MxIn[i];
            My[i] = MyIn[i];
            Mz[i] = MzIn[i];
        }

        for (int i = 0; i < NumPoint; i++) {
            Lat[i] = Latitude[i];
            Lon[i] = Longitude[i];
            Rad[i] = Radius[i];
        }
    }

    MPI_Bcast(R2.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(R1.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Mx.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(My.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Mz.data(), static_cast<int>(NumModel), MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Bcast(Lat.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Lon.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(Rad.data(), NumPoint, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    std::vector<int> DataList(nprocs);
    std::vector<int> VectorShiftList(nprocs);
    MPIDistribute(NumPoint, DataList.data(), VectorShiftList.data());

    const int LocalNumPoint = DataList[rank];
    const int PointShift = VectorShiftList[rank];

    std::vector<double> VLocal(LocalNumPoint);
    std::vector<double> VxLocal(LocalNumPoint), VyLocal(LocalNumPoint), VzLocal(LocalNumPoint);
    std::vector<double> VxxLocal(LocalNumPoint), VxyLocal(LocalNumPoint), VyyLocal(LocalNumPoint),
        VzxLocal(LocalNumPoint), VzyLocal(LocalNumPoint), VzzLocal(LocalNumPoint);

    MPI_Barrier(MPI_COMM_WORLD);

    TicToc timer;
    if (rank == 0) {
        timer.tic();
    }

    for (int i = 0; i < LocalNumPoint; i++) {

        const int GlobalIdx = PointShift + i;

        Tesseroid_MagneticPointEstimate(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, Mx, My, Mz, Lat[GlobalIdx],
                                        Lon[GlobalIdx], Rad[GlobalIdx], AbsTol, RelTol, &VLocal[i], &VxLocal[i],
                                        &VyLocal[i], &VzLocal[i], &VxxLocal[i], &VxyLocal[i], &VyyLocal[i],
                                        &VzxLocal[i], &VzyLocal[i], &VzzLocal[i]);
    }

    MPI_Gatherv(VLocal.data(), LocalNumPoint, MPI_DOUBLE, V, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Gatherv(VxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Gatherv(VxxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VxyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vxy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VyyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vyy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzxLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzx, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzyLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzy, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);
    MPI_Gatherv(VzzLocal.data(), LocalNumPoint, MPI_DOUBLE, Vzz, DataList.data(), VectorShiftList.data(), MPI_DOUBLE, 0,
                MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {
        std::cout << "\nElapsed time: " << timer.toc() << " (seconds)\n";
        printf("\nCalculation finished: MagnetizationShellIntegrationMPI.\n\n");
    }
}

}
