﻿// Run Work1 mass-shell integration with OpenMP.

#include "_tesseroid_MSI.h"

int main(int argc, char** argv) {
    int NumLon, NumLat, NumCoordinates;
    long long NumModel;

    double AbsTol, RelTol;
    double Lons, Lone, Lats, Late, dLon, dLat;

    double *R1, *R2, *rho;
    double *Longitude, *Latitude, *Radius;
    double *V, *Vx, *Vy, *Vz, *Vxx, *Vxy, *Vyy, *Vzx, *Vzy, *Vzz, *Vxxx, *Vxxy, *Vxxz, *Vxyz, *Vyyx, *Vyyy, *Vyyz,
        *Vzzx, *Vzzy, *Vzzz;

    char ParametersFile[1024] = "MSIG.ForPar";
    char ResultsFile[1024] = "ResultG.dat";

    FILE* fp_Parameters;
    FILE* fp_Results;

    fp_Parameters = fopen(ParametersFile, "rb");

    if (fp_Parameters == NULL) {
        printf("\nError: failed to open parameter file.\n");
        printf("Calculation aborted.\n");
        return 0;
    }

    if (fread(&AbsTol, 8, 1, fp_Parameters) != 1 || fread(&RelTol, 8, 1, fp_Parameters) != 1 ||
        fread(&Lons, 8, 1, fp_Parameters) != 1 || fread(&Lone, 8, 1, fp_Parameters) != 1 ||
        fread(&Lats, 8, 1, fp_Parameters) != 1 || fread(&Late, 8, 1, fp_Parameters) != 1 ||
        fread(&dLon, 8, 1, fp_Parameters) != 1 || fread(&dLat, 8, 1, fp_Parameters) != 1 ||
        fread(&NumLon, 4, 1, fp_Parameters) != 1 || fread(&NumLat, 4, 1, fp_Parameters) != 1) {
        printf("\nError: failed to read parameter file header.\n");
        fclose(fp_Parameters);
        return 0;
    }

    NumModel = static_cast<long long>(NumLon) * static_cast<long long>(NumLat);

    R1 = (double*)malloc(sizeof(double) * NumModel);
    R2 = (double*)malloc(sizeof(double) * NumModel);
    rho = (double*)malloc(sizeof(double) * NumModel);

    if (R1 == NULL || R2 == NULL || rho == NULL) {
        printf("\nError: failed to allocate model memory.\n");
        fclose(fp_Parameters);
        free(R1);
        free(R2);
        free(rho);
        return 0;
    }

    if (fread(R2, 8, NumModel, fp_Parameters) != (size_t)NumModel ||
        fread(R1, 8, NumModel, fp_Parameters) != (size_t)NumModel ||
        fread(rho, 8, NumModel, fp_Parameters) != (size_t)NumModel ||
        fread(&NumCoordinates, 4, 1, fp_Parameters) != 1) {
        printf("\nError: failed to read model data.\n");
        fclose(fp_Parameters);
        free(R1);
        free(R2);
        free(rho);
        return 0;
    }

    Longitude = (double*)malloc(sizeof(double) * NumCoordinates);
    Latitude = (double*)malloc(sizeof(double) * NumCoordinates);
    Radius = (double*)malloc(sizeof(double) * NumCoordinates);

    if (Longitude == NULL || Latitude == NULL || Radius == NULL) {
        printf("\nError: failed to allocate coordinate memory.\n");
        fclose(fp_Parameters);
        free(R1);
        free(R2);
        free(rho);
        free(Longitude);
        free(Latitude);
        free(Radius);
        return 0;
    }

    if (fread(Longitude, 8, NumCoordinates, fp_Parameters) != (size_t)NumCoordinates ||
        fread(Latitude, 8, NumCoordinates, fp_Parameters) != (size_t)NumCoordinates ||
        fread(Radius, 8, NumCoordinates, fp_Parameters) != (size_t)NumCoordinates) {
        printf("\nError: failed to read coordinate data.\n");
        fclose(fp_Parameters);
        free(R1);
        free(R2);
        free(rho);
        free(Longitude);
        free(Latitude);
        free(Radius);
        return 0;
    }

    fclose(fp_Parameters);

    V = (double*)malloc(sizeof(double) * NumCoordinates);

    Vx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vz = (double*)malloc(sizeof(double) * NumCoordinates);

    Vxx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vxy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vyy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzz = (double*)malloc(sizeof(double) * NumCoordinates);

    Vxxx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vxxy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vxxz = (double*)malloc(sizeof(double) * NumCoordinates);
    Vxyz = (double*)malloc(sizeof(double) * NumCoordinates);
    Vyyx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vyyy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vyyz = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzzx = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzzy = (double*)malloc(sizeof(double) * NumCoordinates);
    Vzzz = (double*)malloc(sizeof(double) * NumCoordinates);

    if (V == NULL || Vx == NULL || Vy == NULL || Vz == NULL || Vxx == NULL || Vxy == NULL || Vyy == NULL ||
        Vzx == NULL || Vzy == NULL || Vzz == NULL || Vxxx == NULL || Vxxy == NULL || Vxxz == NULL || Vxyz == NULL ||
        Vyyx == NULL || Vyyy == NULL || Vyyz == NULL || Vzzx == NULL || Vzzy == NULL || Vzzz == NULL) {
        printf("\nError: failed to allocate result memory.\n");
        free(R1);
        free(R2);
        free(rho);
        free(Longitude);
        free(Latitude);
        free(Radius);
        free(V);
        free(Vx);
        free(Vy);
        free(Vz);
        free(Vxx);
        free(Vxy);
        free(Vyy);
        free(Vzx);
        free(Vzy);
        free(Vzz);
        free(Vxxx);
        free(Vxxy);
        free(Vxxz);
        free(Vxyz);
        free(Vyyx);
        free(Vyyy);
        free(Vyyz);
        free(Vzzx);
        free(Vzzy);
        free(Vzzz);
        return 0;
    }

    Tesseroid::MassShellIntegrationOpenMP(Lons, Lone, Lats, Late, dLon, dLat, R2, R1, rho, NumCoordinates, Latitude,
                                          Longitude, Radius, AbsTol, RelTol, V, Vx, Vy, Vz, Vxx, Vxy, Vyy, Vzx, Vzy,
                                          Vzz, Vxxx, Vxxy, Vxxz, Vxyz, Vyyx, Vyyy, Vyyz, Vzzx, Vzzy, Vzzz);

    fp_Results = fopen(ResultsFile, "wb");

    if (fp_Results == NULL) {
        printf("\nError: failed to open result file.\n");
        free(R1);
        free(R2);
        free(rho);
        free(Longitude);
        free(Latitude);
        free(Radius);
        free(V);
        free(Vx);
        free(Vy);
        free(Vz);
        free(Vxx);
        free(Vxy);
        free(Vyy);
        free(Vzx);
        free(Vzy);
        free(Vzz);
        free(Vxxx);
        free(Vxxy);
        free(Vxxz);
        free(Vxyz);
        free(Vyyx);
        free(Vyyy);
        free(Vyyz);
        free(Vzzx);
        free(Vzzy);
        free(Vzzz);
        return 0;
    }

    if (fwrite(&NumCoordinates, 4, 1, fp_Results) != 1 ||
        fwrite(Longitude, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Latitude, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Radius, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(V, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vyy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxxx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxxy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxxz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vxyz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vyyx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vyyy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vyyz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzzx, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzzy, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates ||
        fwrite(Vzzz, 8, NumCoordinates, fp_Results) != (size_t)NumCoordinates) {
        printf("\nError: failed to write result file.\n");
        fclose(fp_Results);
        free(R1);
        free(R2);
        free(rho);
        free(Longitude);
        free(Latitude);
        free(Radius);
        free(V);
        free(Vx);
        free(Vy);
        free(Vz);
        free(Vxx);
        free(Vxy);
        free(Vyy);
        free(Vzx);
        free(Vzy);
        free(Vzz);
        free(Vxxx);
        free(Vxxy);
        free(Vxxz);
        free(Vxyz);
        free(Vyyx);
        free(Vyyy);
        free(Vyyz);
        free(Vzzx);
        free(Vzzy);
        free(Vzzz);
        return 0;
    }

    fclose(fp_Results);

    free(R1);
    free(R2);
    free(rho);

    free(Longitude);
    free(Latitude);
    free(Radius);

    free(V);
    free(Vx);
    free(Vy);
    free(Vz);
    free(Vxx);
    free(Vxy);
    free(Vyy);
    free(Vzx);
    free(Vzy);
    free(Vzz);
    free(Vxxx);
    free(Vxxy);
    free(Vxxz);
    free(Vxyz);
    free(Vyyx);
    free(Vyyy);
    free(Vyyz);
    free(Vzzx);
    free(Vzzy);
    free(Vzzz);

    return 0;
}
