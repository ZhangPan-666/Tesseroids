% Read magnetization-shell integration results.

clear; clc;

inFile = 'ResultM.dat';

fid = fopen(inFile, 'r', 'ieee-le');
assert(fid ~= -1, 'Failed to open result file: %s', inFile);
cleaner = onCleanup(@() fclose(fid));

M = struct();
M.NumCoordinates = fread(fid, 1, 'int32');
assert(~isempty(M.NumCoordinates), 'Failed to read NumCoordinates.');

n = double(M.NumCoordinates);
M.Longitude = fread(fid, n, 'double');
M.Latitude  = fread(fid, n, 'double');
M.Radius    = fread(fid, n, 'double');

M.V   = fread(fid, n, 'double');
M.Vx  = fread(fid, n, 'double');
M.Vy  = fread(fid, n, 'double');
M.Vz  = fread(fid, n, 'double');
M.Vxx = fread(fid, n, 'double');
M.Vxy = fread(fid, n, 'double');
M.Vyy = fread(fid, n, 'double');
M.Vzx = fread(fid, n, 'double');
M.Vzy = fread(fid, n, 'double');
M.Vzz = fread(fid, n, 'double');

assignin('base', 'M', M);

disp('ResultM.dat has been read into struct M.');
disp(M);

writematrix([M.Longitude,M.Latitude,M.Radius,...
    M.V,M.Vx,M.Vy,M.Vz,M.Vxx,M.Vxy,M.Vyy,M.Vzx,M.Vzy,M.Vzz],...
    'ForwardResults_MSIM.dat')
