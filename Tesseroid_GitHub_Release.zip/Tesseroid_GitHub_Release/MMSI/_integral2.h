#pragma once

#include <Eigen/Dense>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <limits>
#include <queue>

namespace Tesseroid {

struct Gauss3Kronrod7Const {
    Gauss3Kronrod7Const() {}

    const Eigen::Matrix<double, 1, 7> LowWeights =
        (Eigen::Matrix<double, 1, 7>() << 0.0, 5.0 / 9.0, 0.0, 8.0 / 9.0, 0.0, 5.0 / 9.0, 0.0).finished();

    const Eigen::Matrix<double, 1, 7> HighWeights =
        (Eigen::Matrix<double, 1, 7>() << 0.1046562260264672, 0.2684880898683334, 0.4013974147759622,
         0.4509165386584744, 0.4013974147759622, 0.2684880898683334, 0.1046562260264672)
            .finished();

    const Eigen::Array<double, 14, 1> NArray =
        (Eigen::Array<double, 14, 1>() << 0.009877182822994962, 0.05635083268962915, 0.14143906266329936, 0.25,
         0.35856093733670064, 0.44364916731037085, 0.490122817177005, 0.509877182822995, 0.5563508326896291,
         0.6414390626632993, 0.75, 0.8585609373367007, 0.9436491673103709, 0.990122817177005)
            .finished();
};

struct SubRectangle {
    double q = 0.0;
    double e = 0.0;
    double L = 0.0;
    double R = 0.0;
    double B = 0.0;
    double T = 0.0;
    double adjer = 0.0;
};

struct Integral2Info {
    double errbnd = 0.0;
    bool minRectWarn = false;
    bool maxNFEWarn = false;
    int NFE = 0;
};

template <std::size_t N = 14> struct TensorEvalResult {
    bool subdivided = true;
    Eigen::Matrix<double, 1, 4> Qsub = Eigen::Matrix<double, 1, 4>::Zero();
    Eigen::Matrix<double, 1, 4> esub = Eigen::Matrix<double, 1, 4>::Zero();
};

class RectangleQueue {
  private:
    struct Compare {
        bool operator()(const SubRectangle& a, const SubRectangle& b) const { return a.adjer < b.adjer; }
    };

    std::priority_queue<SubRectangle, std::vector<SubRectangle>, Compare> queue_;
    double err_ok_ = 0.0;
    double sum_adjer_ = 0.0;

  private:
    void pushRect(double q, double e, double L, double R, double B, double T, double adjer) {
        queue_.push(SubRectangle{q, e, L, R, B, T, adjer});
        sum_adjer_ += adjer;
    }

  public:
    bool empty() const { return queue_.empty(); }

    double errBnd() const { return err_ok_ + sum_adjer_; }

    void addErrOk(double value) { err_ok_ += value; }

    SubRectangle pop() {
        const SubRectangle rect = queue_.top();
        queue_.pop();
        sum_adjer_ -= rect.adjer;
        return rect;
    }

    void saveRectInfo(const Eigen::Matrix<double, 1, 4>& Qsub, const Eigen::Matrix<double, 1, 4>& esub, double thetaL,
                      double thetaR, double phiB, double phiT, double TOL, double AREA, double EPS100, double ADJUST) {
        const double thetaM = 0.5 * (thetaL + thetaR);
        const double phiM = 0.5 * (phiB + phiT);
        const double subArea = 0.25 * (thetaR - thetaL) * (phiT - phiB);

        double localtol = TOL * subArea / AREA;
        localtol = std::max(std::abs(localtol), EPS100 * std::abs(Qsub.sum()));

        auto handleOne = [&](int i, double L, double R, double B, double T) {
            const double adjer = ADJUST * esub(i);
            if (adjer > localtol) {
                pushRect(Qsub(i), esub(i), L, R, B, T, adjer);
            } else {
                err_ok_ += adjer;
            }
        };

        handleOne(0, thetaL, thetaM, phiB, phiM);
        handleOne(1, thetaM, thetaR, phiB, phiM);
        handleOne(2, thetaL, thetaM, phiM, phiT);
        handleOne(3, thetaM, thetaR, phiM, phiT);
    }
};

template <std::size_t N = 14, class KernelT = Gauss3Kronrod7Const, class Func>
inline TensorEvalResult<N> PartitionIntegralQuad(double thetaL, double thetaR, double phiB, double phiT,
                                                 bool& firstFunEval, int& NFE, double XMIN, double XMAX, double YMIN,
                                                 double YMAX, const Func& FUN) {
    TensorEvalResult<N> result;

    constexpr double Tiny = 100.0 * std::numeric_limits<double>::epsilon();
    if (std::abs(thetaR - thetaL) <= Tiny || std::abs(phiT - phiB) <= Tiny || std::abs(XMAX - XMIN) <= Tiny ||
        std::abs(YMAX - YMIN) <= Tiny) {
        result.subdivided = false;
        return result;
    }

    const KernelT g3k7{};
    const auto& WT3 = g3k7.LowWeights;
    const auto& WT7 = g3k7.HighWeights;
    const auto& NARRAY = g3k7.NArray;

    const double dtheta = thetaR - thetaL;
    const double dphi = phiT - phiB;
    const double dydt = YMAX - YMIN;

    const Eigen::Array<double, N, 1> theta = thetaL + NARRAY * dtheta;
    const Eigen::Array<double, N, 1> phi = phiB + NARRAY * dphi;

    const Eigen::Array<double, N, 1> x = 0.5 * (XMAX + XMIN) + 0.5 * (XMAX - XMIN) * theta.cos();

    const Eigen::Array<double, N, 1> y = YMIN + (0.5 + 0.5 * phi.cos()) * dydt;

    const Eigen::Matrix<double, N, N> X = x.matrix().transpose().replicate(N, 1);

    const Eigen::Matrix<double, N, N> Y = y.matrix().replicate(1, N);

    Eigen::Matrix<double, N, N> Z = FUN(X, Y);
    ++NFE;
    firstFunEval = false;

    const Eigen::Matrix<double, N, N> jacobian =
        0.25 * (XMAX - XMIN) * phi.sin().matrix() * (dydt * theta.sin()).matrix().transpose();

    Z = Z.cwiseProduct(jacobian);

    Eigen::Matrix<double, N / 2, 2 * N> Zpart;
    Zpart.block(0, 0, N / 2, N) = Z.topRows(N / 2);
    Zpart.block(0, N, N / 2, N) = Z.bottomRows(N / 2);

    const double scale = 0.0625 * dtheta * dphi;

    const Eigen::Matrix<double, 1, 2 * N> tmp7 = WT7 * Zpart;
    const Eigen::Map<const Eigen::Matrix<double, N / 2, 4>> tmp7map(tmp7.data());
    result.Qsub = (WT7 * tmp7map) * scale;

    const Eigen::Matrix<double, 1, 2 * N> tmp3 = WT3 * Zpart;
    const Eigen::Map<const Eigen::Matrix<double, N / 2, 4>> tmp3map(tmp3.data());
    result.esub = ((WT3 * tmp3map) * scale - result.Qsub).cwiseAbs();

    return result;
}

template <class Func>
inline double integral2t(const Func& FUN, double XMIN, double XMAX, double YMIN, double YMAX, double ATOL = 1e-10,
                         double RTOL = 1e-6, int maxFunEvals = 1000, Integral2Info* info = nullptr) {
    constexpr double PI = 3.141592653589793238462643383279502884;

    bool firstFunEval = true;
    int NFE = 0;

    const double thetaL = 0.0;
    const double thetaR = PI;
    const double phiB = 0.0;
    const double phiT = PI;
    const double AREA = (thetaR - thetaL) * (phiT - phiB);

    auto first = PartitionIntegralQuad<14, Gauss3Kronrod7Const>(thetaL, thetaR, phiB, phiT, firstFunEval, NFE, XMIN,
                                                                XMAX, YMIN, YMAX, FUN);

    double Q = first.Qsub.sum();

    const double EPS100 = 100.0 * std::numeric_limits<double>::epsilon();
    RTOL = std::max(RTOL, EPS100);

    const double rtold8 = std::max(RTOL / 8.0, EPS100);
    const double atold8 = ATOL / 8.0;

    double TOL = std::max(atold8, rtold8 * std::abs(Q));
    double ADJUST = 1.0;

    RectangleQueue manager;
    manager.saveRectInfo(first.Qsub, first.esub, thetaL, thetaR, phiB, phiT, TOL, AREA, EPS100, ADJUST);

    bool minRectWarn = false;
    bool maxNFEWarn = false;

    while (!manager.empty() && manager.errBnd() > TOL) {
        const SubRectangle rect = manager.pop();

        auto next = PartitionIntegralQuad<14, Gauss3Kronrod7Const>(rect.L, rect.R, rect.B, rect.T, firstFunEval, NFE,
                                                                   XMIN, XMAX, YMIN, YMAX, FUN);

        if (!next.subdivided) {
            minRectWarn = true;
            manager.addErrOk(rect.adjer);
        } else {
            const double newQ = next.Qsub.sum();

            ADJUST = (rect.e > 0.0) ? std::min(1.0, std::abs(rect.q - newQ) / rect.e) : 1.0;

            Q += (newQ - rect.q);
            TOL = std::max(atold8, rtold8 * std::abs(Q));

            manager.saveRectInfo(next.Qsub, next.esub, rect.L, rect.R, rect.B, rect.T, TOL, AREA, EPS100, ADJUST);

            if (NFE >= maxFunEvals) {
                maxNFEWarn = true;
                break;
            }
        }
    }

    if (info != nullptr) {
        info->errbnd = manager.errBnd();
        info->minRectWarn = minRectWarn;
        info->maxNFEWarn = maxNFEWarn;
        info->NFE = NFE;
    }

    return Q;
}

}
