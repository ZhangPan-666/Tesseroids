# Mass and Magnetization Shell Integration

MMSI evaluates gridded mass or magnetization models as continuous spherical-shell surfaces rather than explicitly accumulating independent tesseroids. This directory contains the complete-field Work1 serial, OpenMP, and MPI drivers for mass and magnetization shells.

## Requirements

- C++17 compiler
- Eigen 3.4 or a compatible Eigen 3.x release
- MPI implementation
- OpenMP implementation
- MATLAB (optional, for generating parameter files and reading results)

## Entry points

| Source file | Purpose |
|---|---|
| `Work1_MassShellIntegration.cpp` | Serial calculation of all 20 gravitational quantities |
| `Work1_MassShellIntegrationOpenMP.cpp` | OpenMP calculation of all 20 gravitational quantities |
| `Work1_MassShellIntegrationMPI.cpp` | MPI calculation of all 20 gravitational quantities |
| `Work1_MagnetizationShellIntegration.cpp` | Serial calculation of all 10 magnetic quantities |
| `Work1_MagnetizationShellIntegrationOpenMP.cpp` | OpenMP calculation of all 10 magnetic quantities |
| `Work1_MagnetizationShellIntegrationMPI.cpp` | MPI calculation of all 10 magnetic quantities |

## Input and output

- `Work1_SetMSIGParameters.m` creates `MSIG.ForPar` for a mass shell.
- `Work1_SetMSIMParameters.m` creates `MSIM.ForPar` for a magnetization shell.
- The full mass and magnetization calculations write `ResultG.dat` and `ResultM.dat`.
- `Work2_ReadMSIGResults.m` and `Work2_ReadMSIMResults.m` read the binary outputs.

The large parameter files, output files, ETOPO1 grids, and lithospheric magnetization model used for the production benchmarks are not stored in the repository. They are generated or obtained separately from the data sources cited in the manuscript. Before running `Work1_SetMSIMParameters.m`, set `vimModelFile` to a local model file with the columns expected by that script.

Compile the selected entry point with the user's preferred C++17, Eigen, MPI, and OpenMP toolchain, then run it from the directory containing its `.ForPar` input file. The parameter-generation scripts document the binary layout and provide editable examples. The two `Work2_Read*Results.m` files only read the complete Work1 outputs; they are not reduced-component forward solvers.
