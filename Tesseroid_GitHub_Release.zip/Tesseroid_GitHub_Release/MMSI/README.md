# Mass and Magnetization Shell Integration

These files match the current Tesseroid_C++/MMSI production sources. MMSI evaluates interpolated mass or magnetization shells using radially reduced kernels.

## Entry points

- Work1_MassShellIntegration.cpp, Work1_MassShellIntegrationOpenMP.cpp and Work1_MassShellIntegrationMPI.cpp: all 20 gravitational quantities.
- Work1_MagnetizationShellIntegration.cpp, Work1_MagnetizationShellIntegrationOpenMP.cpp and Work1_MagnetizationShellIntegrationMPI.cpp: magnetic potential, vector and gradient tensor.
- Work2_MassShellIntegrationVzMPI.cpp: Vz only.
- Work2_MagnetizationShellIntegrationVectorMPI.cpp: magnetic vector only.

The dedicated Work2 solvers preserve the full result layout and fill uncomputed fields with NaN. The MATLAB Work2_Read*Results.m files read existing results.

Use C++17, Eigen, MPI and OpenMP. Work1_SetMSIGParameters.m creates MSIG.ForPar; Work1_SetMSIMParameters.m creates MSIM.ForPar. Edit model/data paths first, particularly the magnetization-model path in the latter. Results are written to ResultG.dat and ResultM.dat.

Cluster-specific MPI copies and build/submission scripts are in ../MMSI_Cluster/. See the supplementary document for binary layouts and unit conversion.
