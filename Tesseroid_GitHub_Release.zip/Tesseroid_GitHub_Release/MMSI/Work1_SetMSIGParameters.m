% Create MSIG.ForPar for mass-shell integration.

clear; clc;

outFile = 'MSIG.ForPar';
AbsTol  = 1e-16;
RelTol  = 1e-16;

Lons = -180;
Lone =  180;
Lats = -90;
Late =  90;
dLon =  0.05;
dLat =  0.05;

Lons=Lons+dLon/2;
Lone=Lone-dLon/2;
Lats=Lats+dLat/2;
Late=Late-dLat/2;

NumLon = round((Lone - Lons) / dLon) + 1;
NumLat = round((Late - Lats) / dLat) + 1;

R2  = 6371.2 * ones(NumLat, NumLon);
R1  = R2 - 30;
rho = 1 * ones(NumLat, NumLon);

Latitude  = (30:0.1:40)';
Longitude = 70.*ones(size(Latitude));
Radius    = (6371.2+1).*ones(size(Longitude));

assert(all(size(R1)  == [NumLat, NumLon]), 'R1 must be NumLat-by-NumLon.');
assert(all(size(R2)  == [NumLat, NumLon]), 'R2 must be NumLat-by-NumLon.');
assert(all(size(rho) == [NumLat, NumLon]), 'rho must be NumLat-by-NumLon.');

Longitude = Longitude(:);
Latitude  = Latitude(:);
Radius    = Radius(:);
NumCoordinates = numel(Longitude);
assert(numel(Latitude) == NumCoordinates && numel(Radius) == NumCoordinates, ...
    'Longitude, Latitude, Radius must have the same length.');

fid = fopen(outFile, 'w', 'ieee-le');
assert(fid ~= -1, 'Failed to open output file: %s', outFile);
cleaner = onCleanup(@() fclose(fid));

fwrite(fid, double(AbsTol), 'double');
fwrite(fid, double(RelTol), 'double');

fwrite(fid, double(Lons), 'double');
fwrite(fid, double(Lone), 'double');
fwrite(fid, double(Lats), 'double');
fwrite(fid, double(Late), 'double');
fwrite(fid, double(dLon), 'double');
fwrite(fid, double(dLat), 'double');

fwrite(fid, int32(NumLon), 'int32');
fwrite(fid, int32(NumLat), 'int32');

fwrite(fid, double(R2(:)),  'double');
fwrite(fid, double(R1(:)),  'double');
fwrite(fid, double(rho(:)), 'double');

fwrite(fid, int32(NumCoordinates), 'int32');
fwrite(fid, double(Longitude), 'double');
fwrite(fid, double(Latitude),  'double');
fwrite(fid, double(Radius),    'double');

disp(['Mass-shell parameter file written: ', outFile]);
