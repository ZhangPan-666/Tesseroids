﻿// Run Work2 mass-shell integration for Vz with MPI.
// The result file keeps the Work1 mass-result binary layout.

#include "_tesseroid_MSI.h"

#include <mpi.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>

namespace Work2MassVz {
using KernelFunction = std::function<Eigen::Matrix<double, 14, 14>(const Eigen::Matrix<double, 14, 14>&,
                                                                   const Eigen::Matrix<double, 14, 14>&)>;

class Work2MassVzTimer {
  public:
    void start() { start_ = Clock::now(); }
    double seconds() const { return std::chrono::duration<double>(Clock::now() - start_).count(); }

  private:
    using Clock = std::chrono::high_resolution_clock;
    std::chrono::time_point<Clock> start_;
};

inline void Work2MassVzDistribute(int count, std::vector<int>& counts, std::vector<int>& displacements) {
    int nprocs = 1;
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    counts.assign(nprocs, count / nprocs);
    for (int i = 0; i < count % nprocs; ++i) {
        ++counts[i];
    }

    displacements.assign(nprocs, 0);
    for (int i = 1; i < nprocs; ++i) {
        displacements[i] = displacements[i - 1] + counts[i - 1];
    }
}

inline double Work2MassVzNormalizeLongitude(double longitude) {
    longitude = std::fmod(longitude + 180.0, 360.0);
    if (longitude < 0.0)
        longitude += 360.0;
    return longitude - 180.0;
}

inline double Work2MassVzKahanSum(const std::vector<double>& values) {
    double sum = 0.0;
    double correction = 0.0;
    for (double value : values) {
        const double adjusted = value - correction;
        const double next = sum + adjusted;
        correction = (next - sum) - adjusted;
        sum = next;
    }
    return sum;
}

inline double Work2MassVzIntegrateCenterSplit(const KernelFunction& function, double lat1, double lat2, double lon1,
                                              double lon2, double observationLatitude, double observationLongitude,
                                              double absoluteTolerance, double relativeTolerance) {
    if (!(lat2 > lat1 && lon2 > lon1))
        return 0.0;

    if (std::abs(observationLatitude) == 90.0) {
        return Tesseroid::integral2t(function, lat1, lat2, lon1, lon2, absoluteTolerance, relativeTolerance);
    }

    std::vector<double> latitudeBreaks{lat1, lat2};
    std::vector<double> longitudeBreaks{lon1, lon2};

    const double epsLat = 1.0e-12 * std::max(1.0, std::abs(lat2 - lat1));
    const double epsLon = 1.0e-12 * std::max(1.0, std::abs(lon2 - lon1));
    if (observationLatitude > lat1 + epsLat && observationLatitude < lat2 - epsLat) {
        latitudeBreaks.push_back(observationLatitude);
    }
    if (observationLongitude > lon1 + epsLon && observationLongitude < lon2 - epsLon) {
        longitudeBreaks.push_back(observationLongitude);
    }

    std::sort(latitudeBreaks.begin(), latitudeBreaks.end());
    std::sort(longitudeBreaks.begin(), longitudeBreaks.end());

    const std::size_t subdomainCount = (latitudeBreaks.size() - 1) * (longitudeBreaks.size() - 1);
    const double localAbsoluteTolerance = absoluteTolerance / std::max<std::size_t>(subdomainCount, 1);

    std::vector<double> pieces;
    pieces.reserve(subdomainCount);
    for (std::size_t i = 0; i + 1 < latitudeBreaks.size(); ++i) {
        for (std::size_t j = 0; j + 1 < longitudeBreaks.size(); ++j) {
            pieces.push_back(Tesseroid::integral2t(function, latitudeBreaks[i], latitudeBreaks[i + 1],
                                                   longitudeBreaks[j], longitudeBreaks[j + 1], localAbsoluteTolerance,
                                                   relativeTolerance));
        }
    }
    return Work2MassVzKahanSum(pieces);
}

inline double Work2MassVzIntegrateOutsideHole(const KernelFunction& function, double latA, double latB, double lonA,
                                              double lonB, double holeLat1, double holeLat2, double holeLon1,
                                              double holeLon2, double absoluteTolerance, double relativeTolerance,
                                              double observationLatitude, double observationLongitude) {
    auto integrate = [&](double lat1, double lat2, double lon1, double lon2) {
        return Work2MassVzIntegrateCenterSplit(function, lat1, lat2, lon1, lon2, observationLatitude,
                                               observationLongitude, absoluteTolerance, relativeTolerance);
    };

    if (!(latB > latA && lonB > lonA))
        return 0.0;

    const double middleLat1 = std::max(latA, holeLat1);
    const double middleLat2 = std::min(latB, holeLat2);
    if (!(middleLat2 > middleLat1)) {
        return integrate(latA, latB, lonA, lonB);
    }

    std::vector<std::pair<double, double>> holeLongitudeIntervals;
    if (holeLon1 <= holeLon2) {
        holeLongitudeIntervals.push_back({holeLon1, holeLon2});
    } else {
        holeLongitudeIntervals.push_back({lonA, holeLon2});
        holeLongitudeIntervals.push_back({holeLon1, lonB});
    }

    std::vector<std::pair<double, double>> remaining{{lonA, lonB}};
    for (const auto& hole : holeLongitudeIntervals) {
        const double clipped1 = std::max(lonA, hole.first);
        const double clipped2 = std::min(lonB, hole.second);
        if (!(clipped2 > clipped1))
            continue;

        std::vector<std::pair<double, double>> next;
        for (const auto& segment : remaining) {
            if (clipped2 <= segment.first || clipped1 >= segment.second) {
                next.push_back(segment);
                continue;
            }
            if (clipped1 > segment.first)
                next.push_back({segment.first, clipped1});
            if (clipped2 < segment.second)
                next.push_back({clipped2, segment.second});
        }
        remaining.swap(next);
    }

    std::vector<double> pieces;
    pieces.reserve(2 + remaining.size());
    pieces.push_back(integrate(latA, middleLat1, lonA, lonB));
    pieces.push_back(integrate(middleLat2, latB, lonA, lonB));
    for (const auto& segment : remaining) {
        pieces.push_back(integrate(middleLat1, middleLat2, segment.first, segment.second));
    }
    return Work2MassVzKahanSum(pieces);
}

inline void Work2MassVzPointEstimate(double lons, double lone, double lats, double late, double dLon, double dLat,
                                     const std::vector<double>& outerRadius, const std::vector<double>& innerRadius,
                                     const std::vector<double>& density, double latitude, double longitude,
                                     double radius, double absoluteTolerance, double relativeTolerance, double* vz) {
    const double pi = 4.0 * std::atan(1.0);
    const double degreeAreaCorrection = pi * pi / (180.0 * 180.0);

    longitude = Work2MassVzNormalizeLongitude(longitude);

    double holeLon1 = 0.0;
    double holeLon2 = 0.0;
    double holeLat1 = 0.0;
    double holeLat2 = 0.0;

    if (std::abs(latitude - 90.0) < dLat) {
        holeLon1 = -180.0;
        holeLon2 = 180.0;
        holeLat1 = 90.0 - dLat;
        holeLat2 = 90.0;
    } else if (std::abs(latitude + 90.0) < dLat) {
        holeLon1 = -180.0;
        holeLon2 = 180.0;
        holeLat1 = -90.0;
        holeLat2 = -90.0 + dLat;
    } else {
        holeLat1 = latitude - 0.5 * dLat;
        holeLat2 = latitude + 0.5 * dLat;
        if (holeLat1 < -90.0) {
            holeLat1 = -90.0;
            holeLat2 = -90.0 + dLat;
        }
        if (holeLat2 > 90.0) {
            holeLat2 = 90.0;
            holeLat1 = 90.0 - dLat;
        }
        holeLon1 = Work2MassVzNormalizeLongitude(longitude - 0.5 * dLon);
        holeLon2 = Work2MassVzNormalizeLongitude(longitude + 0.5 * dLon);
    }

    KernelFunction actualKernel = [&](const Eigen::Matrix<double, 14, 14>& sourceLatitudes,
                                      const Eigen::Matrix<double, 14, 14>& sourceLongitudes) {
        return Tesseroid::Tesseroid_SurfaceKernelVz(outerRadius, innerRadius, density, sourceLatitudes,
                                                    sourceLongitudes, radius, latitude, longitude, lons, lone, lats,
                                                    late, dLon, dLat, holeLon1, holeLon2, holeLat1, holeLat2);
    };

    double target1 = Work2MassVzIntegrateOutsideHole(
        actualKernel, lats - 0.5 * dLat, late + 0.5 * dLat, lons - 0.5 * dLon, lone + 0.5 * dLon, holeLat1, holeLat2,
        holeLon1, holeLon2, absoluteTolerance, relativeTolerance, latitude, longitude);
    target1 *= radius * degreeAreaCorrection;

    const bool insideAngularModel = longitude >= lons - 0.5 * dLon && longitude <= lone + 0.5 * dLon &&
                                    latitude >= lats - 0.5 * dLat && latitude <= late + 0.5 * dLat;
    if (!insideAngularModel) {
        *vz = target1;
        return;
    }

    const double localOuterRadius =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, outerRadius, longitude, latitude);
    const double localInnerRadius =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, innerRadius, longitude, latitude);
    const double localDensity =
        sphinterp::SphBilinearInterpPoint(lons, lone, lats, late, dLon, dLat, density, longitude, latitude);

    KernelFunction dummyKernel = [&](const Eigen::Matrix<double, 14, 14>& sourceLatitudes,
                                     const Eigen::Matrix<double, 14, 14>& sourceLongitudes) {
        return Tesseroid::surfacekernel_detail::EvaluateSurfaceKernelConstant(
            localOuterRadius, localInnerRadius, localDensity, sourceLatitudes, sourceLongitudes, radius, latitude,
            longitude, holeLon1, holeLon2, holeLat1, holeLat2, Tesseroid::surfacekernel_detail::KVz);
    };

    double target2 =
        Work2MassVzIntegrateOutsideHole(dummyKernel, -90.0, 90.0, -180.0, 180.0, holeLat1, holeLat2, holeLon1, holeLon2,
                                        absoluteTolerance, relativeTolerance, latitude, longitude);
    target2 *= radius * degreeAreaCorrection;

    double shellVz = 0.0;
    if (radius >= localOuterRadius) {
        const double massFactor = 4.0 * pi / 3.0 * (std::pow(localOuterRadius, 3) - std::pow(localInnerRadius, 3));
        shellVz = -massFactor / (radius * radius);
    } else if (radius > localInnerRadius) {
        shellVz = -4.0 * pi / 3.0 * (radius - std::pow(localInnerRadius, 3) / (radius * radius));
    }
    shellVz *= localDensity;

    *vz = target1 + shellVz - target2;
}

inline void Work2MassVzComputeMPI(double lons, double lone, double lats, double late, double dLon, double dLat,
                                  std::vector<double>& outerRadius, std::vector<double>& innerRadius,
                                  std::vector<double>& density, std::vector<double>& latitude,
                                  std::vector<double>& longitude, std::vector<double>& radius, double absoluteTolerance,
                                  double relativeTolerance, std::vector<double>& vz) {
    int rank = 0;
    int nprocs = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    const int pointCount = static_cast<int>(latitude.size());
    const long long modelCount = static_cast<long long>(outerRadius.size());
    if (modelCount > std::numeric_limits<int>::max()) {
        if (rank == 0)
            std::cerr << "Error: model is too large for a single MPI_Bcast count.\n";
        MPI_Abort(MPI_COMM_WORLD, 20);
    }

    MPI_Bcast(outerRadius.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(innerRadius.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(density.data(), static_cast<int>(modelCount), MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(latitude.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(longitude.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(radius.data(), pointCount, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    std::vector<int> counts;
    std::vector<int> displacements;
    Work2MassVzDistribute(pointCount, counts, displacements);

    const int localCount = counts[rank];
    const int offset = displacements[rank];
    std::vector<double> localVz(localCount);

    Work2MassVzTimer timer;
    if (rank == 0)
        timer.start();

    for (int i = 0; i < localCount; ++i) {
        const int globalIndex = offset + i;
        Work2MassVzPointEstimate(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, density,
                                 latitude[globalIndex], longitude[globalIndex], radius[globalIndex], absoluteTolerance,
                                 relativeTolerance, &localVz[i]);
    }

    if (rank == 0)
        vz.resize(pointCount);
    MPI_Gatherv(localVz.data(), localCount, MPI_DOUBLE, rank == 0 ? vz.data() : nullptr, counts.data(),
                displacements.data(), MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        std::cout << "Work2 gravity Vz elapsed time: " << timer.seconds() << " seconds\n";
    }
}
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank = 0;
    int nprocs = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    const char* parameterFile = "MSIG.ForPar";
    const char* resultFile = "ResultG.dat";

    double absoluteTolerance = 0.0;
    double relativeTolerance = 0.0;
    double lons = 0.0;
    double lone = 0.0;
    double lats = 0.0;
    double late = 0.0;
    double dLon = 0.0;
    double dLat = 0.0;
    int numLon = 0;
    int numLat = 0;
    int pointCount = 0;
    int readOK = 1;

    std::vector<double> outerRadius;
    std::vector<double> innerRadius;
    std::vector<double> density;
    std::vector<double> longitude;
    std::vector<double> latitude;
    std::vector<double> radius;

    if (rank == 0) {
        FILE* file = std::fopen(parameterFile, "rb");
        if (file == nullptr) {
            std::cerr << "Error: failed to open " << parameterFile << "\n";
            readOK = 0;
        }

        if (readOK) {
            readOK =
                std::fread(&absoluteTolerance, sizeof(double), 1, file) == 1 &&
                std::fread(&relativeTolerance, sizeof(double), 1, file) == 1 &&
                std::fread(&lons, sizeof(double), 1, file) == 1 && std::fread(&lone, sizeof(double), 1, file) == 1 &&
                std::fread(&lats, sizeof(double), 1, file) == 1 && std::fread(&late, sizeof(double), 1, file) == 1 &&
                std::fread(&dLon, sizeof(double), 1, file) == 1 && std::fread(&dLat, sizeof(double), 1, file) == 1 &&
                std::fread(&numLon, sizeof(int), 1, file) == 1 && std::fread(&numLat, sizeof(int), 1, file) == 1;
        }

        if (readOK && (numLon < 2 || numLat < 2 || dLon <= 0.0 || dLat <= 0.0)) {
            std::cerr << "Error: invalid model dimensions or grid spacing.\n";
            readOK = 0;
        }

        if (readOK) {
            const std::size_t modelCount = static_cast<std::size_t>(numLon) * static_cast<std::size_t>(numLat);
            outerRadius.resize(modelCount);
            innerRadius.resize(modelCount);
            density.resize(modelCount);
            readOK = std::fread(outerRadius.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(innerRadius.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(density.data(), sizeof(double), modelCount, file) == modelCount &&
                     std::fread(&pointCount, sizeof(int), 1, file) == 1;
        }

        if (readOK && pointCount > 0) {
            longitude.resize(pointCount);
            latitude.resize(pointCount);
            radius.resize(pointCount);
            readOK =
                std::fread(longitude.data(), sizeof(double), pointCount, file) ==
                    static_cast<std::size_t>(pointCount) &&
                std::fread(latitude.data(), sizeof(double), pointCount, file) == static_cast<std::size_t>(pointCount) &&
                std::fread(radius.data(), sizeof(double), pointCount, file) == static_cast<std::size_t>(pointCount);
        } else if (readOK) {
            std::cerr << "Error: no observation points were supplied.\n";
            readOK = 0;
        }

        if (file != nullptr)
            std::fclose(file);
    }

    if (rank == 0 && readOK) {
        const auto outer = std::minmax_element(outerRadius.begin(), outerRadius.end());
        const auto inner = std::minmax_element(innerRadius.begin(), innerRadius.end());
        const auto rho = std::minmax_element(density.begin(), density.end());
        const auto obsLon = std::minmax_element(longitude.begin(), longitude.end());
        const auto obsLat = std::minmax_element(latitude.begin(), latitude.end());
        const auto obsRad = std::minmax_element(radius.begin(), radius.end());
        std::cout << "\n========== Work2 mass-shell parameters ==========\n"
                  << "Files: " << parameterFile << " -> " << resultFile << " | MPI processes: " << nprocs << '\n'
                  << "Grid: lon [" << lons << ", " << lone << "], step " << dLon << " deg; lat [" << lats << ", "
                  << late << "], step " << dLat << " deg\n"
                  << "Grid size: " << numLon << " x " << numLat << " = " << outerRadius.size() << " nodes\n"
                  << "Outer radius: [" << *outer.first << ", " << *outer.second << "]; inner radius: [" << *inner.first
                  << ", " << *inner.second << "]\n"
                  << "Density range: [" << *rho.first << ", " << *rho.second << "]\n"
                  << "Observations: " << pointCount << "; lon [" << *obsLon.first << ", " << *obsLon.second
                  << "] deg; lat [" << *obsLat.first << ", " << *obsLat.second << "] deg; radius [" << *obsRad.first
                  << ", " << *obsRad.second << "]\n"
                  << "Tolerance: abs " << absoluteTolerance << ", rel " << relativeTolerance << '\n'
                  << "Components: Vz only; other Work1-layout fields are NaN\n"
                  << "=================================================\n\n"
                  << std::flush;
        std::cout << "Starting Work2 mass-shell Vz integration...\n\n";
    }

    MPI_Bcast(&readOK, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (!readOK) {
        MPI_Finalize();
        return EXIT_FAILURE;
    }

    MPI_Bcast(&absoluteTolerance, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&relativeTolerance, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lons, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lone, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&lats, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&late, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dLon, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&dLat, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numLon, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&numLat, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&pointCount, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank != 0) {
        const std::size_t modelCount = static_cast<std::size_t>(numLon) * static_cast<std::size_t>(numLat);
        outerRadius.resize(modelCount);
        innerRadius.resize(modelCount);
        density.resize(modelCount);
        longitude.resize(pointCount);
        latitude.resize(pointCount);
        radius.resize(pointCount);
    }

    std::vector<double> vz;
    Work2MassVz::Work2MassVzComputeMPI(lons, lone, lats, late, dLon, dLat, outerRadius, innerRadius, density, latitude,
                                       longitude, radius, absoluteTolerance, relativeTolerance, vz);

    int writeOK = 1;
    if (rank == 0) {
        const std::vector<double> notComputed(pointCount, std::numeric_limits<double>::quiet_NaN());
        auto writeArray = [](FILE* file, const std::vector<double>& values, int count) {
            return std::fwrite(values.data(), sizeof(double), count, file) == static_cast<std::size_t>(count);
        };

        FILE* file = std::fopen(resultFile, "wb");
        if (file == nullptr) {
            std::cerr << "Error: failed to open " << resultFile << "\n";
            writeOK = 0;
        }
        if (writeOK) {
            writeOK = std::fwrite(&pointCount, sizeof(int), 1, file) == 1 && writeArray(file, longitude, pointCount) &&
                      writeArray(file, latitude, pointCount) && writeArray(file, radius, pointCount) &&

                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, vz, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount) &&
                      writeArray(file, notComputed, pointCount) && writeArray(file, notComputed, pointCount);
        }
        if (file != nullptr)
            std::fclose(file);
    }

    MPI_Bcast(&writeOK, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Finalize();
    return writeOK ? EXIT_SUCCESS : EXIT_FAILURE;
}
