% Read mass-shell integration results.

clear; clc;

inFile = 'ResultG.dat';

fid = fopen(inFile, 'r', 'ieee-le');
assert(fid ~= -1, 'Failed to open result file: %s', inFile);
cleaner = onCleanup(@() fclose(fid));

G = struct();
G.NumCoordinates = fread(fid, 1, 'int32');
assert(~isempty(G.NumCoordinates), 'Failed to read NumCoordinates.');

n = double(G.NumCoordinates);
G.Longitude = fread(fid, n, 'double');
G.Latitude  = fread(fid, n, 'double');
G.Radius    = fread(fid, n, 'double');

G.V    = fread(fid, n, 'double');
G.Vx   = fread(fid, n, 'double');
G.Vy   = fread(fid, n, 'double');
G.Vz   = fread(fid, n, 'double');
G.Vxx  = fread(fid, n, 'double');
G.Vxy  = fread(fid, n, 'double');
G.Vyy  = fread(fid, n, 'double');
G.Vzx  = fread(fid, n, 'double');
G.Vzy  = fread(fid, n, 'double');
G.Vzz  = fread(fid, n, 'double');
G.Vxxx = fread(fid, n, 'double');
G.Vxxy = fread(fid, n, 'double');
G.Vxxz = fread(fid, n, 'double');
G.Vxyz = fread(fid, n, 'double');
G.Vyyx = fread(fid, n, 'double');
G.Vyyy = fread(fid, n, 'double');
G.Vyyz = fread(fid, n, 'double');
G.Vzzx = fread(fid, n, 'double');
G.Vzzy = fread(fid, n, 'double');
G.Vzzz = fread(fid, n, 'double');

fclose(fid);

assignin('base', 'G', G);

disp('ResultG.dat has been read into struct G.');
disp(G);

writematrix([G.Longitude,G.Latitude,G.Radius,...
    G.V,...
    G.Vx,G.Vy,G.Vz,...
    G.Vxx,G.Vxy,G.Vyy,G.Vzx,G.Vzy,G.Vzz,...
    G.Vxxx,G.Vxxy,G.Vxxz,G.Vxyz,G.Vyyx,...
    G.Vyyy,G.Vyyz,G.Vzzx,G.Vzzy,G.Vzzz],...
    'ForwardResults_MSIG.dat')
