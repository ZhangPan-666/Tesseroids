# MMSI cluster programs

These sources match Tesseroid_C++/MMSI_Cluster and include complete-field and dedicated Vz/magnetic-vector MPI programs, headers, Makefile and submission script.

Configure EIGEN_ROOT, the compiler/MPI environment and WORKDIR. WORK_SELECTION=1,2,3,4 selects full gravity, full magnetism, Vz, or magnetic vector. Prepare MSIG.ForPar or MSIM.ForPar and submit using sbatch run.pbs. The script uses Slurm directives despite its .pbs extension. Adjust resources for the destination cluster.

MATLAB interfaces are in ../MMSI/. Dedicated Work2 programs preserve the complete result layout and fill uncomputed fields with NaN.
