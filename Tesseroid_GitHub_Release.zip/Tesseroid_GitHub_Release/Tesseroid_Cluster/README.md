# Individual-prism cluster programs

These sources match Tesseroid_C++/Tesseroid_Cluster and provide MPI gravity and magnetic drivers, required headers, Makefile and submission script.

Configure EIGEN_ROOT, the Intel compiler/MPI environment and WORKDIR. Select gravity or magnetism with RUN_CHOICE in run.pbs, prepare TFG.ForPar or TFM.ForPar, and submit using sbatch run.pbs. The script uses Slurm directives despite its .pbs extension. Adjust resources for the destination cluster.

MATLAB interfaces are in ../Tesseroid/. Keep these MPI copies separate from the desktop variants.
