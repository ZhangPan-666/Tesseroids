# Tesseroid forward-modelling code

This release accompanies the manuscript **Accurate and Stable Computation of Gravitational Potential and Its Derivatives up to Third Order for Spherical Prisms**.

## Contents

- `Tesseroid/`: direct forward modelling of individual spherical prisms, including gravitational quantities through third order and magnetic quantities through second order.
- `MMSI/`: Mass and Magnetization Shell Integration for gridded spherical-shell models.
- `(Compressed) Supplementary Information.pdf`: compressed Supplementary Information suitable for ordinary GitHub upload.

Generated binary parameter files, numerical results, build products, IDE caches, and large source-model data are intentionally excluded. See the README in each code directory for dependencies and data interfaces. Compiler- and platform-specific build files are not prescribed because users may integrate the source files into their preferred toolchain.
