# Tesseroid forward-modelling code

This release accompanies **Accurate and Stable Computation of Gravitational Potential and Its Derivatives up to Third Order for Spherical Prisms**.

## Contents

- Tesseroid/: current individual-prism headers, OpenMP/MPI gravity drivers, serial/OpenMP/MPI magnetic drivers, and MATLAB interfaces.
- MMSI/: current shell headers, serial/OpenMP/MPI complete-field drivers, dedicated MPI Vz and magnetic-vector drivers, and MATLAB interfaces.
- Tesseroid_Cluster/ and MMSI_Cluster/: corresponding cluster source variants, Makefiles and submission scripts.
- Supplementary Information.pdf: current compiled supplementary document.
- SOURCE_MANIFEST.json: SHA-256 hashes of all copied production source files.

Production source files are copied byte for byte from the corresponding active directories in Tesseroid_C++. The variants are kept in separate directories because some desktop and cluster MPI drivers differ.

## Requirements and use

Use a C++17 compiler, Eigen 3.4 (or compatible Eigen 3.x), MPI and OpenMP. Even serial drivers include headers that depend on MPI and OpenMP. Compile each Work*.cpp as a separate executable.

Edit the model/data paths in the MATLAB Work1_Set*Parameters.m scripts and generate the .ForPar input files. Run the selected executable in the directory containing its input. Work2_Read*Results.m scripts read the binary outputs. See the supplementary document for layouts and physical-unit conversion.

For cluster builds, configure EIGEN_ROOT in the Makefile and the working directory, compiler environment and resource settings in run.pbs. Despite its filename, run.pbs contains **Slurm** directives and is submitted with sbatch. These scripts retain the source project's site-specific defaults.

The archive contains source and documentation. Historical versions, local diagnostic tests, Visual Studio state, binaries, generated parameter/result files and large input models are excluded.
