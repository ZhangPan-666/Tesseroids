#pragma once

#define _USE_MATH_DEFINES
#include "internal/_integral2.h"
#include "internal/_tesseroid_integralkernel.h"
#include "internal/_tesseroid_estimate.h"
#undef _USE_MATH_DEFINES